# Studio

Protótipo navegável (mobile ou web), histórico de commits e Pull Requests, wiki do design system, inspetor, comentários por clique e chat com o agente, para qualquer projeto. O Studio é um motor: ele não traz conteúdo próprio, se adapta ao que o projeto entrega e usa uma base visual neutra enquanto o projeto não definir a dele.

## Começar um projeto novo

O caminho mais curto é pedir ao Claude Code, numa pasta vazia: “quero começar um projeto com o Studio”. A skill `studio-init` (em `skills/studio-init`) cria o repositório no GitHub, instala o motor, escreve a configuração e as primeiras telas. Quem nunca usou GitHub ou terminal encontra o passo a passo, com o lugar de cada ação, no próprio Studio: estado vazio do Protótipo e Wiki, em “Como usar”.

Instalação manual, na pasta do projeto. O motor pode vir de um arquivo (gerado com `npm pack` dentro deste pacote) ou de um repositório do GitHub:

```bash
npm i -D ./studio-engine-<versão>.tgz react react-dom        # a partir do arquivo
npm i -D github:<usuario>/<repositorio-do-motor> react react-dom   # ou do GitHub
npx studio dev     # http://localhost:5173, com recarga automática e o agente
```

Precisa de Node 18 ou mais novo.

## Comandos

| Comando | O que faz |
| --- | --- |
| `studio dev` | Servidor local com recarga automática, comentários e chat com o agente |
| `studio build` | Gera `dist/index.html`, um arquivo único |
| `studio check` | Falha se o build quebrar |
| `studio history` | Gera `data/history.json` a partir do git |

## O que o projeto entrega ao motor

Na raiz do projeto, tudo opcional menos a ponte:

- `studio.config.json`: `name`, `platform` (`mobile` ou `desktop`) e caminhos.
- `studio.project.js`: a ponte, com `HISTORY`, `TOKENS`, `DESIGN`, `SCREENS`, `STUBS`, `DOCS`, `FIGMA_FILE`, `TabBar`, `PortalContainer` e, opcional, `WIKI_PAGES`.
- `studio.project.css`: CSS das telas do projeto, isolado dos tokens do Studio.
- `studio.i18n.json`: tradução do conteúdo do projeto para o modo EN.

Sem esses arquivos o motor usa o projeto de exemplo em `default/`.

## Estrutura

- `src/`: interface do Studio (React). `theme.css` guarda a paleta própria do Studio, separada da do projeto.
- `scripts/`: build (esbuild), servidor de desenvolvimento e geração do histórico.
- `default/`: projeto padrão, usado quando a pasta ainda não tem um.
- `skills/studio-init/`: skill que cria um projeto novo do zero.
- `bin/studio.mjs`: o comando `studio`.

## Limites conhecidos

- O inspetor (Modo dev) lê a árvore do React. Telas de outra stack ainda não têm inspetor.
- O agente e os comentários por clique só funcionam com `studio dev`, na máquina de quem roda. Num artefato publicado, o chat só mostra um aviso.
