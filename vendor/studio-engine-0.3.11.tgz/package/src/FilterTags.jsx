// Filtro por categoria em tags (o Chip do design system), igual no Protótipo, na Wiki e no Histórico.
// `items`: [{ id, label }]. Clicar numa tag chama onChange(id); quem usa decide o que filtrar.
import { Chip } from './ui/kit.jsx';

export function FilterTags({ label, items, value, onChange }) {
  return (
    <div className="ftags" role="group" aria-label={label}>
      {items.map((it) => (
        <Chip key={it.id} state={it.id === value ? 'active' : 'default'} onClick={() => onChange(it.id)}>
          {it.label}
        </Chip>
      ))}
    </div>
  );
}
