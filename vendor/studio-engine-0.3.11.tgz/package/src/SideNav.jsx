// Navegação única do Studio: lista lateral com grupos e itens (Wiki, Histórico e telas do Protótipo).
// Em tela estreita a lista não cabe ao lado: o mesmo conteúdo vira o Select do design system, agrupado igual.
// groups: [{ id, label?, items: [{ id, label, meta? }] }]. Grupo sem label não mostra cabeçalho.
// Navegação sem contadores, em todo o Studio: os totais ficam na Visão geral da Wiki.
// Quem abre e fecha é a seção-mãe (ver Wiki), não os grupos daqui.
import { Fragment, useEffect, useId, useRef } from 'react';
import { t } from './i18n.js';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectGroup, SelectLabel } from './ui/kit.jsx';

export function NavItem({ active, onClick, label, meta }) {
  return (
    <button type="button" className="snav-item" aria-current={active} onClick={onClick}>
      <span className="snav-label">{label}</span>
      {meta && <span className="snav-meta mono muted">{meta}</span>}
    </button>
  );
}

export function SideNav({ label, groups, value, onPick }) {
  const ref = useRef(null);
  const selectId = useId();
  const ids = groups.flatMap((g) => g.items.map((i) => i.id));
  useEffect(() => { ref.current?.querySelector('[aria-current=true]')?.scrollIntoView({ block: 'nearest' }); }, [value]);
  // ↑ ↓ percorrem a lista inteira, atravessando os grupos
  const onKeyDown = (e) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    const next = ids[ids.indexOf(value) + (e.key === 'ArrowDown' ? 1 : -1)];
    if (next == null) return;
    e.preventDefault(); onPick(next);
    requestAnimationFrame(() => ref.current?.querySelector('[aria-current=true]')?.focus());
  };
  return (
    <>
      <div className="snav" ref={ref} onKeyDown={onKeyDown}>
        {groups.map((g) => (
          <div className="snav-group" role="group" aria-label={g.label || t(label)} key={g.id}>
            {g.label && <span className="snav-head st-label-md muted"><span>{t(g.label).toUpperCase()}</span></span>}
            {g.items.map((i) => <NavItem key={i.id} active={i.id === value} onClick={() => onPick(i.id)} label={t(i.label)} meta={i.meta} />)}
          </div>
        ))}
      </div>
      <div className="snav-select">
        <label className="st-label-md muted" htmlFor={selectId}>{t(label).toUpperCase()}</label>
        <Select value={value} onValueChange={onPick}>
          <SelectTrigger id={selectId}><SelectValue /></SelectTrigger>
          <SelectContent>
            {groups.map((g) => {
              const opts = g.items.map((i) => <SelectItem key={i.id} value={i.id}>{t(i.label)}</SelectItem>);
              return g.label ? <SelectGroup key={g.id}><SelectLabel>{t(g.label)}</SelectLabel>{opts}</SelectGroup> : <Fragment key={g.id}>{opts}</Fragment>;
            })}
          </SelectContent>
        </Select>
      </div>
    </>
  );
}
