// Passo a passo "do zero ao primeiro projeto" para quem nunca usou GitHub nem terminal. É só dado: o componente (Guide.jsx) desenha,
// então dá para reordenar, remover ou acrescentar passos sem mexer na tela. Nada aqui é específico de um projeto.
//
// Cada passo diz ONDE fazer a ação (`where`), porque para um leigo o maior bloqueio é não saber se aquilo vai no terminal, no
// site do GitHub ou no Claude.
//   where:  'terminal' | 'browser' | 'claude'
//   site:   endereço a abrir (só quando where = 'browser')
//   cmds:   comandos para copiar e colar no terminal; o que estiver entre < > é o que você troca pelo seu
//   check:  como saber que deu certo
// Os textos são chaves de tradução (t() na hora de desenhar). Os comandos não são traduzidos.

export const WHERE = {
  terminal: { label: 'NO TERMINAL', hint: 'A janela de texto do seu computador. Cole o comando e aperte Enter.', hintSemComando: 'A janela de texto do seu computador. Neste passo não há comando para colar.' },
  browser: { label: 'NO NAVEGADOR', hint: 'Abra o endereço indicado no Chrome, Safari ou outro.' },
  claude: { label: 'NO CLAUDE', hint: 'No app do Claude ou no Claude Code, fora deste Studio. Escreva o pedido e envie.' },
};

export const GUIDE_STEPS = [
  {
    id: 'terminal',
    where: 'terminal',
    title: 'Abrir o Terminal',
    why: 'É a janela de texto onde você roda comandos. Ela já vem no computador, e usá-la não estraga nada.',
    how: ['No Mac: aperte Cmd + Espaço, digite “Terminal” e aperte Enter.', 'No Windows: abra o menu Iniciar, digite “PowerShell” e aperte Enter.'],
    check: 'Aparece uma janela com uma linha de texto e um cursor piscando.',
  },
  {
    id: 'node',
    where: 'browser',
    site: 'https://nodejs.org',
    title: 'Instalar o Node.js',
    why: 'O Studio é um programa que roda sobre o Node.js. Sem ele, o Studio não abre no seu computador.',
    how: ['Baixe a versão marcada como LTS e instale com “Avançar” até o fim.', 'Depois volte ao Terminal e rode o comando abaixo.'],
    cmds: ['node -v'],
    check: 'O Terminal mostra um número de versão, como v20.11.0. Serve qualquer número a partir de 18.',
  },
  {
    id: 'git',
    where: 'terminal',
    title: 'Conferir o Git e dizer quem é você',
    why: 'O Git guarda o histórico do projeto. Cada gravação leva o seu nome, para a equipe saber quem mudou o quê.',
    how: ['Rode o primeiro comando. Se o Mac oferecer instalar ferramentas de desenvolvedor, aceite. No Windows, instale o Git em git-scm.com.', 'Depois rode os dois seguintes trocando pelo seu nome e pelo e-mail da sua conta do GitHub.'],
    cmds: ['git --version', 'git config --global user.name "<Seu Nome>"', 'git config --global user.email "<seu@email.com>"'],
    check: 'O primeiro comando mostra uma versão e os outros dois não respondem nada, o que é o normal.',
  },
  {
    id: 'conta',
    where: 'browser',
    site: 'https://github.com/signup',
    title: 'Criar sua conta no GitHub',
    why: 'O GitHub guarda o projeto na internet, com cópia de segurança, histórico e a revisão das mudanças. É grátis.',
    how: ['Crie a conta com o mesmo e-mail que você usou no passo anterior.', 'Se já tem conta, entre nela e pule este passo.'],
    check: 'Você vê a página inicial do GitHub, já logado.',
  },
  {
    id: 'repo',
    where: 'browser',
    site: 'https://github.com/new',
    title: 'Criar o repositório vazio',
    why: 'O repositório é a pasta do seu projeto no GitHub. Criá-lo vazio evita conflito quando você enviar o que já tem no computador.',
    how: ['Dê um nome ao projeto, escolha Private para só você ver e deixe todas as opções de arquivos iniciais desmarcadas (README, .gitignore, licença).', 'Clique em Create repository e copie o endereço que termina em .git.'],
    check: 'A página nova mostra instruções e um endereço como https://github.com/seu-usuario/seu-projeto.git.',
  },
  {
    id: 'conectar',
    where: 'terminal',
    title: 'Conectar a pasta ao repositório',
    why: 'Isso liga a pasta do seu computador ao repositório do GitHub. É feito uma vez só por projeto.',
    how: ['Entre na pasta do projeto. Você pode arrastar a pasta para dentro do Terminal para colar o caminho.', 'Rode os comandos, trocando pelo endereço copiado no passo anterior.'],
    cmds: ['cd <caminho da pasta>', 'git init -b main', 'git remote add origin <endereço do repositório>'],
    check: 'Nenhum dos comandos mostra erro. O comando “git remote -v” lista o endereço do GitHub.',
  },
  {
    id: 'envio',
    where: 'terminal',
    title: 'Fazer o primeiro envio',
    why: 'Grava uma foto do projeto (commit) e envia (push) ao GitHub. A partir daqui o histórico existe e o Studio passa a mostrá-lo.',
    how: ['Rode os três comandos em ordem.', 'Na primeira vez o GitHub pede que você entre pelo navegador. Isso é normal: faça o login e volte ao Terminal.'],
    cmds: ['git add -A', 'git commit -m "primeiro commit"', 'git push -u origin main'],
    check: 'Ao atualizar a página do repositório no GitHub, os arquivos do projeto aparecem lá.',
  },
  {
    id: 'comecar',
    where: 'claude',
    title: 'Pedir ao Claude para começar o projeto',
    why: 'A partir daqui você deixa o terminal de lado. O Claude cria as telas, grava as mudanças e abre os pedidos de revisão (PR).',
    how: ['Abra o Claude (app ou Claude Code) na pasta do projeto e escreva, com as suas palavras, o que quer construir. Por exemplo: “quero começar um projeto com o Studio”.', 'Ele pergunta o nome, se é mobile ou web e o que o produto faz. Depois de responder, acompanhe o Protótipo e o Histórico aqui no Studio.'],
    check: 'As primeiras telas aparecem no Protótipo e o primeiro commit aparece no Histórico.',
  },
];
