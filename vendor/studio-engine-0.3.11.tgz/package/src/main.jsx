import { createRoot } from 'react-dom/client';
import './theme.css'; // paleta do chrome do Studio (claro e escuro), independente do projeto
import './studio.css';
import { App } from './App.jsx';

createRoot(document.getElementById('root')).render(<App />);
