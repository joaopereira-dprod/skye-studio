// Chat com o agente, sem sair do Studio: botão flutuante no canto inferior direito que abre uma barra na largura da tela, na base.
// Atalho: Ctrl/Cmd + K abre e foca; Esc fecha; Enter envia; Shift + Enter quebra a linha.
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Button } from './ui/kit.jsx';
import { CarbonIcon } from './ui/kit.jsx';
import { sendToAgent, probeAgent } from './agent.js';
import { t } from './i18n.js';

export function ChatBar({ context }) {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([]);
  const [agent, setAgent] = useState({ ready: false, mode: null }); // o servidor local diz se há agente (npm run dev)
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const barRef = useRef(null);
  const inputRef = useRef(null);
  const logRef = useRef(null);
  const abort = useRef(null);

  useEffect(() => { probeAgent().then(setAgent); }, []);
  // Os estados vazios (e qualquer parte do Studio) pedem a barra por aqui: ela abre com o rascunho pronto, e quem envia é a pessoa
  useEffect(() => {
    const on = (e) => { setOpen(true); if (e.detail?.draft) setDraft(e.detail.draft); setTimeout(() => inputRef.current?.focus(), 0); };
    window.addEventListener('studio:chat', on);
    return () => window.removeEventListener('studio:chat', on);
  }, []);
  useEffect(() => {
    const on = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setOpen(true); setTimeout(() => inputRef.current?.focus(), 0); }
      if (e.key === 'Escape') setOpen((o) => (o ? false : o));
    };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, []);

  // A barra empurra o conteúdo para cima em vez de cobri-lo: a altura vira a variável --chat-h
  useLayoutEffect(() => {
    const root = document.documentElement;
    if (!open || !barRef.current) { root.style.removeProperty('--chat-h'); return undefined; }
    const el = barRef.current;
    // A barra flutua acima da borda: o espaço reservado inclui a distância até a borda e um respiro
    const sync = () => root.style.setProperty('--chat-h', `${el.offsetHeight + parseFloat(getComputedStyle(el).bottom) + 16}px`);
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(el);
    return () => { ro.disconnect(); root.style.removeProperty('--chat-h'); };
  }, [open]);

  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [msgs]);
  useEffect(() => { if (open) inputRef.current?.focus(); }, [open]);

  // Segue o teclado virtual: o visualViewport é a parte da tela que o teclado deixa visível. A diferença para a janela inteira é a altura do
  // teclado, e a barra sobe essa altura (--kb). Fechou o teclado, a diferença volta a zero e a barra desce sozinha ao fim da tela.
  // É uma única regra contínua, sem modos nem temporizadores. Zoom de pinça também reduz o visualViewport: nesse caso não conta como teclado.
  useEffect(() => {
    const vv = window.visualViewport;
    if (!open || !vv) return undefined;
    const root = document.documentElement;
    const apply = () => {
      const zoomed = vv.scale > 1.01;
      const gap = Math.round(window.innerHeight - vv.height - vv.offsetTop);
      const kb = zoomed || gap < 80 ? 0 : gap; // diferenças pequenas são barra do navegador, não teclado
      root.style.setProperty('--kb', `${kb}px`);
      root.style.setProperty('--vvh', `${zoomed ? window.innerHeight : vv.height}px`);
    };
    apply();
    vv.addEventListener('resize', apply);
    vv.addEventListener('scroll', apply);
    return () => {
      vv.removeEventListener('resize', apply);
      vv.removeEventListener('scroll', apply);
      root.style.removeProperty('--kb');
      root.style.removeProperty('--vvh');
    };
  }, [open]);

  // Cresce com o texto, até um teto
  useLayoutEffect(() => {
    const t = inputRef.current;
    if (!t) return;
    t.style.height = 'auto';
    t.style.height = `${Math.min(t.scrollHeight, 160)}px`;
  }, [draft, open]);

  const send = async () => {
    const prompt = draft.trim();
    if (!prompt || busy) return;
    setDraft('');
    setBusy(true);
    const ctl = new AbortController();
    abort.current = ctl;
    setMsgs((m) => [...m, { role: 'user', text: prompt }, { role: 'agent', text: '', tools: [], cost: null }]);
    const put = (patch) => setMsgs((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, ...patch } : x)));
    try {
      await sendToAgent(prompt, { context, signal: ctl.signal, onUpdate: put });
    } catch (e) {
      if (e.name !== 'AbortError') put({ text: t('Não consegui falar com o agente: {erro}.', { erro: e.message || t('erro desconhecido') }) });
    } finally {
      setBusy(false);
      abort.current = null;
    }
  };
  const stop = () => abort.current?.abort();
  const onKey = (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } };

  if (!open) {
    return (
      <button type="button" className="chat-fab" aria-label={t('Abrir chat com o agente (Ctrl ou Cmd + K)')} onClick={() => setOpen(true)}>
        <CarbonIcon name="chat" size={24} />
      </button>
    );
  }
  return (
    <section className="chat-bar" ref={barRef} aria-label={t('Chat com o agente')}>
      <header className="chat-head st-alt-caps-12">
        <span>{t('AGENTE')}{context ? ` · ${context.toUpperCase()}` : ''}</span>
        <span className="chat-status muted"><i className="chat-dot" data-on={agent.ready} aria-hidden="true" />{agent.ready ? `${t('AGENTE LOCAL')} · ${agent.mode === 'read' ? t('SÓ LEITURA') : t('EDITA ARQUIVOS')}` : t('SEM AGENTE: RESPOSTAS DE EXEMPLO')}</span>
        <Button variant="ghost" size="icon" className="chat-close rounded-full" onClick={() => setOpen(false)} aria-label={t('Fechar chat')}><CarbonIcon name="close" size={20} /></Button>
      </header>
      {msgs.length > 0 && (
        <div className="chat-log" ref={logRef} role="log" aria-live="polite">
          {msgs.map((m, i) => (
            <div key={i} className={`chat-msg chat-msg--${m.role}`}>
              <span className="st-alt-caps-12 muted">{m.role === 'user' ? t('VOCÊ') : t('AGENTE')}</span>
              {m.tools?.length > 0 && <ul className="chat-tools st-alt-caps-12 muted">{m.tools.map((tool, k) => <li key={k}>{tool}</li>)}</ul>}
              <p className="st-alt-caps-medium">{m.text || '…'}</p>
              {m.cost != null && <span className="st-alt-caps-12 muted">{t('CUSTO US$')} {m.cost.toFixed(2).replace('.', t(',') )}</span>}
            </div>
          ))}
        </div>
      )}
      <div className="chat-row">
        <textarea ref={inputRef} className="chat-input st-alt-caps-medium" rows={1} value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={onKey} placeholder={t('Peça algo: “ajusta o espaço do card”…')} aria-label={t('Comando para o agente')} />
        {busy
          ? <Button variant="outline" className="rounded-full h-12 px-6" onClick={stop}><span className="st-alt-ibm-12 uppercase">{t('Parar')}</span></Button>
          : <Button className="rounded-full h-12 px-6 gap-2" onClick={send} disabled={!draft.trim()}><span className="st-alt-ibm-12 uppercase">{t('Enviar')}</span><CarbonIcon name="arrowUp" size={16} /></Button>}
      </div>
      <p className="chat-hint st-alt-caps-12 muted">{t('ENTER ENVIA · SHIFT + ENTER QUEBRA A LINHA · ESC FECHA')}</p>
    </section>
  );
}
