// Ligação entre a barra de chat e o agente. A barra só conhece estas funções.
//   - `npm run dev`: o servidor local embute { token, mode } em window.__STUDIO_AGENT__ e expõe /__agent, que roda o Claude Code
//     desta máquina dentro do repositório (veja scripts/dev.mjs e a seção "Agente local" do CONTRIBUTING.md);
//   - artefato publicado ou página sem o servidor: não há agente, e a barra responde com um aviso.
// Contrato: sendToAgent(prompt, { context, signal, onUpdate }) resolve { text, cost, error }.
// onUpdate recebe o estado inteiro até agora: { text, tools: ['EDIT src/x.jsx', ...], cost, error }.

import { t } from './i18n.js';

const getCfg = () => (typeof window !== 'undefined' ? window.__STUDIO_AGENT__ : null); // o servidor local embute { token } no início da página
const session = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : null; // uma conversa por página aberta
let started = false; // a primeira mensagem cria a sessão; as seguintes a retomam

const headers = () => ({ 'Content-Type': 'application/json', 'x-studio-token': getCfg().token });

/** Pergunta ao servidor local se há agente. Resolve { ready, mode }. */
export async function probeAgent() {
  if (!getCfg()?.token || !session) return { ready: false, mode: null };
  try {
    const r = await fetch('/__agent/status', { headers: headers() });
    if (!r.ok) return { ready: false, mode: null };
    const j = await r.json();
    return { ready: true, mode: j.mode };
  } catch { return { ready: false, mode: null }; }
}

const SEM_AGENTE = () => t('Ainda não há um agente ligado a esta página. Rode `npm run dev` no terminal: o servidor local liga esta barra ao Claude Code da sua máquina.');
const SEM_LOGIN = () => t('O Claude Code desta máquina não está logado. No terminal, rode `claude`, use /login e tente de novo.');
const friendly = (text) => (/authenticat|oauth|401/i.test(text) ? SEM_LOGIN() : text);

async function demo(prompt, { context, signal, onUpdate }) {
  const text = `${SEM_AGENTE()}\n\n${t('Comando recebido')}: “${prompt}”${context ? `\n${t('Contexto')}: ${context}.` : ''}`;
  for (let i = 0; i < text.length; i += 12) {
    if (signal?.aborted) throw new DOMException('Cancelado', 'AbortError');
    onUpdate?.({ text: text.slice(0, i + 12), tools: [] });
    await new Promise((r) => setTimeout(r, 12));
  }
  return { text, cost: null, error: false };
}

export async function sendToAgent(prompt, opts = {}) {
  const { context, signal, onUpdate } = opts;
  if (!getCfg()?.token || !session) return demo(prompt, opts);
  const st = { text: '', tools: [], cost: null, error: false };
  const push = () => onUpdate?.({ ...st, tools: [...st.tools] });
  let res;
  try {
    res = await fetch('/__agent', { method: 'POST', headers: headers(), body: JSON.stringify({ prompt, session, first: !started, context }), signal });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new Error(t('o servidor local não respondeu. Ele ainda está rodando (npm run dev)?'));
  }
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new Error(j.error || t('o servidor local respondeu {n}', { n: res.status }));
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      if (!line.trim()) continue;
      let ev;
      try { ev = JSON.parse(line); } catch { continue; }
      if (ev.t === 'delta') st.text += ev.text;
      else if (ev.t === 'tool') st.tools.push(`${ev.name.toUpperCase()}${ev.detail ? ` ${ev.detail}` : ''}`);
      else if (ev.t === 'done') {
        st.cost = ev.cost;
        st.error = !!ev.error;
        if (ev.error) st.text = friendly(ev.text || st.text);
        else if (!st.text) st.text = ev.text;
        if (!ev.error) started = true; // com erro a sessão pode não ter sido criada: a próxima tenta criá-la de novo
      }
      push();
    }
  }
  return { text: st.text, cost: st.cost, error: st.error };
}
