// Descobre qual componente do design system desenhou um elemento do DOM, lendo a árvore interna do React.
// Assim o atoms.jsx (gerado pelo Figma) não precisa de nenhum atributo extra para o inspetor funcionar.
// Depende de `keepNames: true` no esbuild, para os nomes das funções sobreviverem à minificação.
import { DOCS } from 'studio-project';

const BY_MATCH = new Map();
DOCS.forEach((d) => (d.match || []).forEach((m) => BY_MATCH.set(m, d.name)));

// forwardRef(function Nome) guarda o nome em type.render.name (sem displayName), por isso o último fallback
const nameOf = (type) => type && (type.displayName || type.render?.displayName || type.name || type.render?.name);

/** Nomes (do design system) que contêm o elemento, do mais interno para o mais externo. */
export function dsNamesFor(el) {
  const key = el && Object.keys(el).find((k) => k.startsWith('__reactFiber$'));
  const out = [];
  for (let f = key ? el[key] : null; f; f = f.return) {
    const doc = BY_MATCH.get(nameOf(f.type));
    if (doc && !out.includes(doc)) out.push(doc);
  }
  // Plano B: alguns componentes do Radix perdem o displayName; o papel ARIA identifica o componente
  DOCS.forEach((d) => { if (d.selector && el.closest?.(d.selector) && !out.includes(d.name)) out.push(d.name); });
  return out;
}

const hostOf = (fiber) => { for (let f = fiber; f; f = f.child) if (f.stateNode instanceof Element) return f.stateNode; return null; };
// Só o que dá para escrever no JSX: texto, número e booleano. Funções, filhos, estilo e ref ficam de fora
const SKIP = new Set(['children', 'className', 'style', 'ref', 'key']);
const plain = (props) => Object.fromEntries(Object.entries(props || {}).filter(([k, v]) => !SKIP.has(k) && !/^on[A-Z]/.test(k) && ['string', 'number', 'boolean'].includes(typeof v)));

/** Componentes do design system que contêm o elemento (do mais interno ao mais externo), com as props usadas e o elemento raiz de cada um. */
export function dsInfoFor(el) {
  const key = el && Object.keys(el).find((k) => k.startsWith('__reactFiber$'));
  const out = [];
  for (let f = key ? el[key] : null; f; f = f.return) {
    const name = BY_MATCH.get(nameOf(f.type));
    const kids = f.memoizedProps?.children;
    if (name && !out.some((o) => o.name === name)) out.push({ name, props: plain(f.memoizedProps), text: typeof kids === 'string' ? kids : null, node: hostOf(f) });
  }
  return out;
}
