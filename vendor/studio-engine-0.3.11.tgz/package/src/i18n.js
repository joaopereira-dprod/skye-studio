// Idioma da interface do Studio (PT | EN). A chave é o próprio texto em português: t('Salvar') devolve "Save" em inglês.
// Texto sem tradução cai no português (nunca quebra a tela). {nome} é substituído pelos valores de t(texto, { nome }).
// Só o chrome do Studio é traduzido. O conteúdo do projeto (nomes de telas, descrições de componentes, mensagens de commit) fica como
// o projeto o escreveu. O padrão é português; a escolha fica no navegador.
import { useSyncExternalStore } from 'react';
import { EN } from './i18n.en.js';

const KEY = 'studio-lang';
const read = () => { try { return localStorage.getItem(KEY) === 'en' ? 'en' : 'pt'; } catch { return 'pt'; } };
const PROJECT_EN = typeof __STUDIO_I18N_EN__ !== 'undefined' ? __STUDIO_I18N_EN__ : {}; // studio.i18n.json do projeto: conteúdo dele em inglês
const DICT = { ...EN, ...PROJECT_EN }; // o projeto pode sobrescrever o dicionário do Studio
let lang = read();
const subs = new Set();
if (typeof document !== 'undefined') document.documentElement.lang = lang === 'en' ? 'en' : 'pt-BR';

export const getLang = () => lang;
export function setLang(next) {
  if (next === lang) return;
  lang = next;
  try { localStorage.setItem(KEY, next); } catch { /* armazenamento bloqueado */ }
  document.documentElement.lang = next === 'en' ? 'en' : 'pt-BR';
  subs.forEach((f) => f());
}
/** Faz o componente que chama (o App) renderizar de novo quando o idioma muda; os filhos acompanham. */
export const useLang = () => useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, getLang);

export function t(pt, vars) {
  const s = lang === 'en' ? (DICT[pt] ?? pt) : pt;
  return vars ? s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? '')) : s;
}
export const locale = () => (lang === 'en' ? 'en-US' : 'pt-BR');
