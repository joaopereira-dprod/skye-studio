// Dados da skill design-replicate no Studio (gerados por scripts/gen-design.mjs): saúde do código,
// mapas tela → componente → token, verificações e imagens de referência do Figma.
import { DESIGN } from 'studio-project';
import { SCREENS } from 'studio-project';

export const screenData = (figmaId) => DESIGN.screens?.[figmaId] || null;
const section = (doc, re) => doc?.sections.find((s) => re.test(s.title));
const table = (doc, re) => section(doc, re)?.tables[0] || null;
const col = (t, name) => t?.head.indexOf(name) ?? -1;

/** Tabela de mapeamento de uma tela e contagem de status (exact, component-missing...). */
export function mapOf(figmaId) {
  const doc = screenData(figmaId)?.map;
  const t = table(doc, /^Mapeamento/);
  if (!t) return null;
  const si = col(t, 'Status');
  const counts = {};
  t.rows.forEach((r) => { counts[r[si]] = (counts[r[si]] || 0) + 1; });
  return { doc, table: t, counts, total: t.rows.length };
}
export const gapsOf = (figmaId) => table(screenData(figmaId)?.map, /rf[aã]os|Lacunas/i);
export const verifyOf = (figmaId) => screenData(figmaId)?.verify || null;
export const deviationsOf = (figmaId) => table(verifyOf(figmaId), /^Desvios/);

/** Números do painel de saúde (Governança). */
export function health() {
  const a = DESIGN.audit;
  const mapped = SCREENS.filter((s) => mapOf(s.figma));
  let exact = 0, rows = 0, open = 0, deviations = 0;
  mapped.forEach((s) => {
    const m = mapOf(s.figma);
    exact += m.counts.exact || 0; rows += m.total;
    const g = gapsOf(s.figma);
    const di = col(g, 'Decisão');
    if (g) open += g.rows.filter((r) => !r[di]).length;
    const d = deviationsOf(s.figma);
    if (d) { const ci = col(d, 'Decisão'); deviations += d.rows.filter((r) => !r[ci]).length; }
  });
  return { audit: a, screens: SCREENS.length, mapped: mapped.length, exact, rows, open, deviations, verified: SCREENS.filter((s) => verifyOf(s.figma)).length };
}

export default DESIGN;
