import { useEffect, useRef, useState } from 'react';
import { HISTORY, TOKENS, SCREENS, DOCS } from 'studio-project';
import { Prototype } from './Prototype.jsx';
import { History } from './History.jsx';
import { Wiki } from './Wiki.jsx';
import { ChatBar } from './ChatBar.jsx';
import { Empty } from './Empty.jsx';
import { Button, CarbonIcon } from './ui/kit.jsx';
import { t, setLang, useLang } from './i18n.js';

const MODES = [['prototipo', 'Protótipo'], ['historico', 'Histórico'], ['wiki', 'Wiki']]; // o segundo item é a chave de tradução
// Sem telas, sem commits ou sem design system, a aba mostra o estado vazio em vez de uma tela quebrada
const EMPTY = {
  prototipo: !SCREENS.length,
  historico: !HISTORY.commits.length,
  wiki: !SCREENS.length && !DOCS.length && !Object.keys(TOKENS.color).length,
};
// Nome do projeto vem do studio.config.json; sem nome (padrão "studio") mostra só "studio".
const Logo = () => <div className="logo">{__STUDIO_NAME__}{__STUDIO_NAME__ !== 'studio' && <> <span>studio</span></>}</div>;
const slug = (k) => k.replace(/\//g, '-');

export function App() {
  const lang = useLang(); // renderiza tudo de novo ao trocar o idioma
  const initial = (() => { try { const h = location.hash.slice(1); return MODES.some(([m]) => m === h) ? h : 'prototipo'; } catch { return 'prototipo'; } })();
  const [mode, setMode] = useState(initial);
  const [version, setVersion] = useState(null);
  const [tool, setTool] = useState(null); // ferramenta do Protótipo: 'inspect' (Modo dev), 'comment' (pinos) ou null; uma por vez
  const pick = (t) => setTool((cur) => (cur === t ? null : t));
  const [wikiTarget, setWikiTarget] = useState({ page: 'visao', comp: 'Button' });

  // O header é fixo: as listas laterais (também fixas) descem a altura dele. Ela muda quando o header quebra de linha em tela estreita.
  const topRef = useRef(null);
  useEffect(() => {
    const el = topRef.current;
    const sync = () => document.documentElement.style.setProperty('--top-h', el.offsetHeight + 'px');
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const change = (m) => { setMode(m); try { history.replaceState(null, '', '#' + m); } catch { /* sem histórico */ } window.scrollTo(0, 0); };
  useEffect(() => {
    const on = () => { const h = location.hash.slice(1); if (MODES.some(([m]) => m === h)) setMode(h); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);

  // Aplicar uma versão sobrescreve as variáveis de cor com o snapshot do commit
  // A versão vale só para o conteúdo do projeto (moldura e exemplos): o chrome do Studio tem paleta própria e não muda com o commit.
  useEffect(() => {
    let tag = document.getElementById('studio-snapshot');
    if (!tag) { tag = document.createElement('style'); tag.id = 'studio-snapshot'; document.head.appendChild(tag); }
    const c = HISTORY.commits.find((x) => x.sha === version);
    tag.textContent = c?.snapshot ? `${__STUDIO_PROJECT_SCOPE__}{${Object.entries(c.snapshot.color).map(([k, v]) => `--c-${slug(k)}:${v.value}`).join(';')}}` : '';
  }, [version]);

  // Tema do chrome: claro é o padrão; a escolha fica neste navegador (o shell.html aplica antes de pintar, sem piscar)
  const [theme, setTheme] = useState(() => (document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light'));
  const flip = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('studio-theme', next); } catch { /* armazenamento bloqueado */ }
  };

  const real = HISTORY.commits.filter((c) => c.status !== 'working');
  const pending = HISTORY.commits.length - real.length;
  const openComp = (name) => { setWikiTarget({ page: 'componentes', comp: name }); change('wiki'); };

  return (
    <div className="shell">
      <header className="top" ref={topRef}>
        <Logo />
        <span className="pill mono"><span className="dot" /><span className="pill-txt" title={`${HISTORY.branch}${real[0] ? ` · ${real[0].short}` : ''}${pending ? ` · ${t('+{n} não commitado', { n: pending })}` : ''}`}>{HISTORY.branch}{real[0] ? ` · ${real[0].short}` : ''}{pending ? ` · ${t('+{n} não commitado', { n: pending })}` : ''}</span></span>
        <div className="modes" role="tablist" aria-label={t('Modo de visualização')}>
          {MODES.map(([m, l]) => <button key={m} role="tab" aria-selected={mode === m} onClick={() => change(m)}>{t(l)}</button>)}
        </div>
        {mode === 'prototipo' && !EMPTY.prototipo && (
          <div className="tools" role="group" aria-label={t('Ferramentas do protótipo')}>
            <Button variant="ghost" size="icon" className="tool-btn" aria-pressed={tool === 'inspect'} aria-label={t('Modo dev (inspecionar)')} title={t('Modo dev: mostra código, medidas e tokens')} onClick={() => pick('inspect')}><CarbonIcon name="code" size={20} /></Button>
            <Button variant="ghost" size="icon" className="tool-btn" aria-pressed={tool === 'comment'} aria-label={t('Comentar (pinos)')} title={t('Comentar: põe um pino na tela')} onClick={() => pick('comment')}><CarbonIcon name="addComment" size={20} /></Button>
          </div>
        )}
        <button type="button" className="pill theme-btn" onClick={flip} aria-pressed={theme === 'dark'} aria-label={t('Tema escuro')}>{theme === 'dark' ? t('Escuro') : t('Claro')}</button>
        <div className="langs" role="group" aria-label={t('Idioma')}>
          {[['pt', 'PT'], ['en', 'EN']].map(([id, l]) => <button key={id} type="button" className="pill theme-btn lang-btn" aria-pressed={lang === id} lang={id} onClick={() => setLang(id)}>{l}</button>)}
        </div>
      </header>
      <main>
        {EMPTY[mode] && <Empty area={mode} />}
        {!EMPTY[mode] && mode === 'prototipo' && <Prototype tool={tool} version={version} resetVersion={() => setVersion(null)} openComp={openComp} />}
        {!EMPTY[mode] && mode === 'historico' && <History onApply={(sha) => { setVersion(sha); change('prototipo'); }} />}
        {!EMPTY[mode] && mode === 'wiki' && <Wiki target={wikiTarget} setTarget={setWikiTarget} />}
      </main>
      <ChatBar context={t(MODES.find(([m]) => m === mode)?.[1] || '')} />
    </div>
  );
}
