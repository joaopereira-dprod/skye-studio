// Comportamento de iPhone para o protótipo: moldura (Dynamic Island, barra de status, indicador de início) e a pilha de
// navegação do UINavigationController (push, pop, gesto de voltar pela borda esquerda). Só o Studio usa isto: não é design system.
import { useCallback, useLayoutEffect, useRef, useState } from 'react';
import cellular from '../assets/ios/cellular.svg';
import wifi from '../assets/ios/wifi.svg';
import batteryCap from '../assets/ios/battery-cap.svg';

export const PHONE_W = 393;
const EASE = 'cubic-bezier(.32,.72,0,1)'; // a curva do push do UINavigationController
const PUSH_MS = 380;
const PARALLAX = 0.3; // a tela de baixo recua 30% da largura
const DIM = 0.12;     // e escurece um pouco
const EDGE = 22;      // faixa da borda esquerda que inicia o gesto de voltar, em pt
const reduced = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
const ms = (n) => (reduced() ? 0 : n);

/** iPhone 15/16 (393×852). Geometria da barra de status vem do header-auth do Figma; a ilha é a do aparelho (126×37). */
export function IOSChrome() {
  return (
    <div className="ios-chrome" aria-hidden="true">
      <div className="ios-island" />
      <span className="ios-time">9:41</span>
      <div className="ios-indicators">
        <img src={cellular} width="17" height="10.667" alt="" />
        <img src={wifi} width="15.333" height="11" alt="" />
        <span className="ios-battery"><i /><img src={batteryCap} width="1.328" height="4" alt="" /></span>
      </div>
      <div className="ios-home" />
    </div>
  );
}

/** Barra do navegador da moldura desktop: três pontos e o endereço da tela atual. Só desenho, não navega. */
export function DesktopChrome({ path }) {
  return (
    <div className="dsk-chrome" aria-hidden="true">
      <span className="dsk-dots"><i /><i /><i /></span>
      <span className="dsk-url mono">{path}</span>
    </div>
  );
}

/**
 * Pilha de telas. Todas as telas da pilha continuam montadas (como no UINavigationController), então o que o usuário digitou
 * sobrevive ao voltar. `reset(id, 'tab')` troca a raiz sem animação (aba); 'fade' faz uma dissolução (entrar no app).
 */
export function useNavStack(initialId, scale, { instant = false } = {}) {  // instant: sem animação nem gesto (moldura de navegador)
  const [stack, setStack] = useState([{ key: 1, id: initialId }]);
  const [phase, setPhase] = useState('idle'); // idle | push | pop | fade | drag
  const ref = useRef({ busy: false, key: 1, pending: null, drag: null, els: new Map() });
  const R = ref.current;
  R.stack = stack;
  R.scale = scale;
  R.instant = instant;

  const el = (key) => R.els.get(key);
  const dimOf = (layer) => layer && layer.querySelector(':scope > .nav-dim');
  const cancelAnims = (n) => n && n.getAnimations().forEach((a) => a.cancel());
  const clear = (...layers) => layers.forEach((l) => {
    if (!l) return;
    cancelAnims(l); l.style.transform = '';
    const d = dimOf(l); if (d) { cancelAnims(d); d.style.opacity = ''; }
  });
  const run = (n, frames, dur, easing = EASE) => n.animate(frames, { duration: dur, easing, fill: 'both' }).finished;
  const done = () => { R.busy = false; setPhase('idle'); };
  const register = (key) => (n) => { if (n) R.els.set(key, n); else R.els.delete(key); };

  // Anima logo depois que a nova camada entrou no DOM (push e dissolução)
  useLayoutEffect(() => {
    const p = R.pending; if (!p) return;
    R.pending = null;
    const next = el(p.key); const prev = el(p.prevKey);
    if (!next) { done(); return; }
    if (p.type === 'push') {
      const d = ms(PUSH_MS);
      Promise.all([
        run(next, [{ transform: 'translateX(100%)' }, { transform: 'translateX(0)' }], d),
        run(prev, [{ transform: 'translateX(0)' }, { transform: `translateX(-${PARALLAX * 100}%)` }], d),
        run(dimOf(prev), [{ opacity: 0 }, { opacity: DIM }], d),
      ]).catch(() => {}).finally(() => { clear(next, prev); done(); });
    } else {
      run(next, [{ opacity: 0 }, { opacity: 1 }], ms(240), 'ease-out').catch(() => {}).finally(() => {
        setStack([{ key: p.key, id: p.id }]); done();
      });
    }
  }, [stack]);

  const push = useCallback((id) => {
    const s = R.stack; const top = s[s.length - 1];
    if (R.busy || top.id === id) return;
    R.busy = true;
    const e = { key: ++R.key, id };
    if (R.instant) { setStack([...s, e]); R.busy = false; return; }
    R.pending = { type: 'push', key: e.key, prevKey: top.key };
    setPhase('push'); setStack([...s, e]);
  }, []);

  const pop = useCallback(() => {
    const s = R.stack;
    if (R.busy || s.length < 2) return false;
    if (R.instant) { setStack(s.slice(0, -1)); return true; }
    R.busy = true; setPhase('pop');
    const top = el(s[s.length - 1].key); const prev = el(s[s.length - 2].key); const d = ms(PUSH_MS);
    Promise.all([
      run(top, [{ transform: 'translateX(0)' }, { transform: 'translateX(100%)' }], d),
      run(prev, [{ transform: `translateX(-${PARALLAX * 100}%)` }, { transform: 'translateX(0)' }], d),
      run(dimOf(prev), [{ opacity: DIM }, { opacity: 0 }], d),
    ]).catch(() => {}).finally(() => { clear(prev); setStack(s.slice(0, -1)); done(); }); // a camada de cima fica no fim da animação até sair
    return true;
  }, []);

  const reset = useCallback((id, mode = 'fade') => {
    const s = R.stack;
    if (R.busy || (s.length === 1 && s[0].id === id)) return;
    const e = { key: ++R.key, id };
    if (mode === 'tab' || reduced() || R.instant) { setStack([e]); return; }
    R.busy = true;
    R.pending = { type: 'fade', key: e.key, id, prevKey: s[s.length - 1].key };
    setPhase('fade'); setStack([...s, e]);
  }, []);

  /** Volta uma tela; sem histórico (ex.: abriu pela lista do Studio), cai na tela de `fallbackId`. */
  const back = useCallback((fallbackId) => { if (!pop() && fallbackId) reset(fallbackId, 'tab'); }, [pop, reset]);

  // Gesto de voltar: arrastar a partir da borda esquerda
  const onPointerDown = (e) => {
    if (R.busy || R.stack.length < 2 || e.button > 0) return;
    const r = e.currentTarget.getBoundingClientRect();
    if ((e.clientX - r.left) / R.scale > EDGE) return;
    R.drag = { id: e.pointerId, x0: e.clientX, dx: 0, v: 0, t: performance.now() };
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* ponteiro sintético: segue sem captura */ }
    R.busy = true; setPhase('drag');
  };
  const onPointerMove = (e) => {
    const d = R.drag; if (!d || d.id !== e.pointerId) return;
    const dx = Math.min(PHONE_W, Math.max(0, (e.clientX - d.x0) / R.scale)); const now = performance.now();
    d.v = (dx - d.dx) / Math.max(1, now - d.t); d.dx = dx; d.t = now;
    const s = R.stack; const top = el(s[s.length - 1].key); const prev = el(s[s.length - 2].key); const p = dx / PHONE_W;
    top.style.transform = `translateX(${dx}px)`;
    prev.style.transform = `translateX(${-PARALLAX * PHONE_W * (1 - p)}px)`;
    dimOf(prev).style.opacity = DIM * (1 - p);
  };
  const finish = (e) => {
    const d = R.drag; if (!d || d.id !== e.pointerId) return;
    R.drag = null;
    const s = R.stack; const top = el(s[s.length - 1].key); const prev = el(s[s.length - 2].key);
    const p = d.dx / PHONE_W; const commit = p > 0.35 || d.v > 0.5; const to = commit ? 1 : 0;
    const dur = ms(commit ? 260 * (1 - p) + 90 : 220);
    Promise.all([
      run(top, [{ transform: `translateX(${d.dx}px)` }, { transform: `translateX(${to * PHONE_W}px)` }], dur),
      run(prev, [{ transform: `translateX(${-PARALLAX * PHONE_W * (1 - p)}px)` }, { transform: `translateX(${-PARALLAX * PHONE_W * (1 - to)}px)` }], dur),
      run(dimOf(prev), [{ opacity: DIM * (1 - p) }, { opacity: DIM * (1 - to) }], dur),
    ]).catch(() => {}).finally(() => {
      if (commit) { clear(prev); setStack(s.slice(0, -1)); } else { clear(top, prev); }
      done();
    });
  };

  return { stack, phase, register, push, pop, reset, back, gesture: { onPointerDown, onPointerMove, onPointerUp: finish, onPointerCancel: finish } };
}
