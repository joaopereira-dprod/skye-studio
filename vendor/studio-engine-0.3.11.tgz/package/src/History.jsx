import { useMemo, useState } from 'react';
import { HISTORY } from 'studio-project';
import { Button, Chip } from './ui/kit.jsx';
import { SideNav } from './SideNav.jsx';
import DESIGN from './design.js';
import { t, locale, getLang } from './i18n.js';

const fmt = (d) => { try { return new Date(d).toLocaleDateString(locale(), { day: '2-digit', month: 'short', year: 'numeric' }); } catch { return d; } };
// Cada commit entra em todas as áreas cujos arquivos ele tocou
const AREAS = [
  ['tokens', 'Tokens', (p) => p.startsWith('tokens/')],
  ['componentes', 'Componentes', (p) => p.startsWith('src/components/')],
  ['telas', 'Telas', (p) => p.startsWith('src/screens/')],
  ['studio', 'Studio e build', (p) => p.startsWith('src/studio/') || p.startsWith('scripts/') || p.startsWith('.github/') || /\.md$/.test(p) || p === 'package.json'],
];
const touches = (c, id) => (c.files || []).some((f) => AREAS.find((a) => a[0] === id)[2](f.p));
const Sw = ({ v }) => (/^#/.test(v || '') ? <span className="sw2" style={{ background: v }} title={v} /> : <span />);

const when = (d) => { try { return new Date(d).toLocaleString(locale(), { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch { return d; } };
const TYPE = { feat: 'Novo', fix: 'Correção', refactor: 'Refatoração', merge: 'Merge', chore: 'Manutenção', docs: 'Docs', style: 'Estilo', test: 'Teste', perf: 'Desempenho', ci: 'CI', build: 'Build', wip: 'Em andamento', outro: 'Outro' };
// Badges = Chip do design system (Figma: badge 127:1117), outlined/sm; o tipo vai no texto
const TypeBadge = ({ t: type }) => <Chip chipStyle="outlined" size="sm">{t(TYPE[type] || TYPE.outro)}</Chip>;
const Lines = ({ c }) => <span className="lines mono"><span className="plus">+{c.add ?? 0}</span><span className="minus">−{c.del ?? 0}</span></span>;
const month = (d) => { try { return new Date(d).toLocaleDateString(locale(), { month: 'long', year: 'numeric' }); } catch { return t('Sem data'); } };

export function History({ onApply }) {
  const all = HISTORY.commits;
  const [sel, setSel] = useState(all[0]?.sha || 'wt');
  // Mesma lista lateral da Wiki: commits agrupados por mês; as áreas tocadas (tokens, componentes...) vão na linha de apoio
  const groups = useMemo(() => {
    const out = [];
    all.forEach((x) => {
      const label = x.status === 'working' ? t('Em andamento') : month(x.date);
      let g = out.find((o) => o.id === label);
      if (!g) out.push(g = { id: label, label, items: [] });
      g.items.push({ id: x.sha || 'wt', label: x.msg, meta: (
        <span className="hmeta">
          <span className="hmeta-row"><TypeBadge t={x.type} /><Lines c={x} /></span>
          <span>{x.status === 'working' ? t('não commitado') : when(x.date)} · {x.author}</span>
        </span>
      ) });
    });
    return out;
  }, [all, getLang()]); // o idioma entra nas dependências: nomes de mês e rótulos mudam com ele
  if (!all.length) return <p className="muted">{t('Nenhum commit encontrado. Rode')} <span className="mono">npm run history</span>.</p>;
  const c = all.find((x) => (x.sha || 'wt') === sel) || all[0];
  const tk = c.tokens || { added: [], changed: [], removed: [] };
  const added = (c.components && c.components.added) || [];
  return (
    <div className="hist">
      <div className="hist-rail">
        <span className="st-label-md muted">{t('BRANCH')} {HISTORY.branch.toUpperCase()}</span>
        <SideNav label="Commit" groups={groups} value={c.sha || 'wt'} onPick={setSel} />
      </div>
      <div className="detail">
        <div className="dhead">
          <div className="st-label-md muted">{c.status === 'working' ? t('WORKING TREE (AINDA NÃO COMMITADO)') : `COMMIT ${c.short}`}</div>
          <h2 className="st-headline-bold-40">{c.msg}</h2>
          <div className="row">
            <TypeBadge t={c.type} />
            {AREAS.filter(([id]) => touches(c, id)).map(([id, label]) => <Chip key={id} chipStyle="outlined" size="sm">{t(label)}</Chip>)}
          </div>
          <div className="row mono muted">
            <span>{c.author}</span><span>{when(c.date)}</span><Lines c={c} /><span>{c.files.length} {c.files.length === 1 ? t('arquivo') : t('arquivos')}</span>
            {c.sha && HISTORY.repo && <a href={`${HISTORY.repo}/commit/${c.sha}`} target="_blank" rel="noreferrer">{t('Ver no GitHub ↗')}</a>}
          </div>
        </div>
        {c.status === 'working' && DESIGN.audit && (
          <div className="row">
            <Chip chipStyle="outlined" size="sm">{t('Auditoria')} {DESIGN.audit.ok ? t('sem violações novas') : t('{n} violação(ões) nova(s)', { n: DESIGN.audit.newViolations })}</Chip>
            <span className="st-body-sm muted">{(DESIGN.audit.adoption * 100).toFixed(1).replace('.', t(','))}{t('% dos valores vêm de token. Os commits antigos não guardam auditoria.')}</span>
          </div>
        )}
        <div className="row">
          <Button disabled={!c.snapshot} onClick={() => onApply(c.sha)}>{t('Abrir protótipo nesta versão')}</Button>
          {!c.snapshot && <span className="st-body-sm muted">{t('Este commit não guarda tokens.')}</span>}
        </div>
        <section className="card pad">
          <h3 className="st-label-lg" style={{ margin: '0 0 12px' }}>{t('Arquivos')} ({c.files.length})</h3>
          <ul className="files">{c.files.map((f) => <li key={f.p}><span className={`st ${f.s}`}>{f.s}</span>{f.p}</li>)}</ul>
        </section>
        <section className="card pad">
          <h3 className="st-label-lg" style={{ margin: '0 0 4px' }}>{t('Design system neste commit')}</h3>
          <p className="st-body-sm muted" style={{ margin: '0 0 12px' }}>{t('{a} tokens novos · {c} alterados · {r} removidos', { a: tk.added.length, c: tk.changed.length, r: tk.removed.length })}{added.length ? ` · ${t('componentes novos')}: ${added.join(', ')}` : ''}</p>
          {[...tk.added.map((x) => ['+', x.name, null, x.to]), ...tk.changed.map((x) => ['~', x.name, x.from, x.to]), ...tk.removed.map((x) => ['−', x.name, x.from, null])].map(([s, name, from, to]) => (
            <div className="diffrow" key={s + name}>
              <span><span className={s === '+' ? 'plus' : s === '−' ? 'minus' : ''}>{s}</span> {name}</span>
              <Sw v={from} /><span className="muted">{from && to ? '→' : from ? t('removido') : t('novo')}</span><span style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Sw v={to} />{to}</span>
            </div>
          ))}
          {!tk.added.length && !tk.changed.length && !tk.removed.length && <p className="muted" style={{ margin: 0 }}>{t('Sem mudanças em tokens.')}</p>}
        </section>
      </div>
    </div>
  );
}
