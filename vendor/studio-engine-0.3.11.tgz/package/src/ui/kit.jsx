/**
 * Kit de interface do Studio: os átomos que o próprio Studio usa (Button, Chip, Select, Checkbox, Toast) e os ícones Carbon.
 *
 * Por que existe: a interface do Studio não pode mudar de cara nem quebrar conforme o projeto aberto. Este kit é pequeno de propósito e
 * pertence ao Studio, não ao projeto. Ele lê as variáveis de tokens do chrome (--primary, --neutral-*, --c-*), definidas em src/theme.css
 * (claro e escuro), e por isso não muda com os tokens do projeto.
 */
import * as React from "react"
import { cva } from "class-variance-authority"
import { clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { Slot } from "@radix-ui/react-slot"
import * as SelectPrimitive from "@radix-ui/react-select"
import * as CheckboxPrimitive from "@radix-ui/react-checkbox"

export function cn(...inputs) {
  return twMerge(clsx(inputs))
}

/* ─── 1. Button ──────────────────────────────────────────────────────────── */
/*
 * Figma: 01. Components > Atomic > button (127:1714) e as instâncias das telas do wireframe
 * (68:1404 primário, 129:2176 outline, header de auth). Raio 8 (radius/md), padding 16×8, Inter Medium 14/24 (body-medium).
 * Type:    primary | destructive | outline ("Cancel") | subtle | ghost | link
 * Size:    default (40) | icon (32×32) | iconLg (40×40, "just icon circle")
 * State:   default | hover | loading (isLoading) | disabled
 * Com ícone: passe o ícone (16px) antes do texto como filho; o gap de 8 já vem do botão.
 */

const buttonVariants = cva(
  [
    "inline-flex items-center justify-center gap-2",
    "font-sans text-[14px] font-medium leading-6", // body-medium
    "rounded-md border border-transparent",
    "transition-colors duration-150",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2",
    "disabled:pointer-events-none disabled:opacity-50",
    "select-none",
  ].join(" "),
  {
    variants: {
      variant: {
        /** Primary — brand/black; hover neutral/800. Main CTA. */
        primary: "bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:bg-[var(--c-neutral-800)]",
        /** Destructive — red/500; hover red/600 (4,8:1). Irreversible actions. Em repouso o branco sobre #EF4444 dá 3,8:1. */
        destructive: "bg-[hsl(var(--destructive))] text-[hsl(var(--destructive-foreground))] hover:bg-[var(--c-red-600)]",
        /** Outline ("Cancel") — surface with a neutral/400 border. */
        outline: "bg-[hsl(var(--card))] border-[hsl(var(--neutral-400))] text-[hsl(var(--foreground))] hover:bg-[hsl(var(--neutral-100))]",
        /** Subtle — neutral/100 fill; hover neutral/200. */
        subtle: "bg-[hsl(var(--neutral-100))] text-[hsl(var(--foreground))] hover:bg-[hsl(var(--neutral-200))]",
        /** Ghost — no fill; hover neutral/100. */
        ghost: "bg-transparent text-[hsl(var(--foreground))] hover:bg-[hsl(var(--neutral-100))]",
        /** Link — underlined IBM Plex Mono 12 caps, no box ("Recuperar senha"). */
        link: "bg-transparent text-[hsl(var(--primary))] font-mono text-[12px] font-semibold leading-[18px] uppercase tracking-[0.01em] underline underline-offset-2 rounded-none",
        /** Link grande — IBM Plex Mono 14 semibold em neutral/700 ("VER MAIS →", "VER NO MAPA →"; Figma 949:17059). */
        linkLg: "bg-transparent text-[var(--c-neutral-700)] font-mono text-[14px] font-semibold leading-5 uppercase tracking-[0.01em] underline underline-offset-2 rounded-none",
      },
      size: {
        default: "h-10 px-4 py-2",
        icon:    "h-8 w-8 p-2",
        iconLg:  "h-10 w-10 p-2",
      },
    },
    compoundVariants: [
      /* O link não tem caixa nem borda: o size vem depois da variante no cva e venceria o h-auto p-0. */
      { variant: ["link", "linkLg"], className: "h-auto w-auto border-0 p-0" },
      /* "Just icon" do Figma: superfície branca com borda neutral/200, hover neutral/100. */
      { size: ["icon", "iconLg"], variant: "outline", className: "border-[hsl(var(--neutral-200))]" },
    ],
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
)

const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, isLoading = false, children, disabled, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        ref={ref}
        className={cn(
          buttonVariants({ variant, size }),
          // Loading do Figma: neutral/900 a 50% com o texto branco (o slate/900 do kit não é token)
          isLoading && "bg-[color-mix(in_srgb,var(--c-neutral-900)_50%,transparent)] text-[hsl(var(--primary-foreground))] disabled:opacity-100",
          className
        )}
        disabled={disabled || isLoading}
        aria-disabled={disabled || isLoading}
        aria-busy={isLoading}
        {...props}
      >
        {isLoading ? (
          <>
            <svg
              className="animate-spin h-4 w-4 shrink-0"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
            <span className="sr-only">Carregando…</span>
            {children}
          </>
        ) : (
          children
        )}
      </Comp>
    )
  }
)
Button.displayName = "Button"

/* ─── 3. Select ──────────────────────────────────────────────────────────── */
/*
 * Figma variants: State (Default | Open | Filled | Disabled)
 * Uses Radix Select primitive; same visual as Input.
 */

const Select        = SelectPrimitive.Root
const SelectGroup   = SelectPrimitive.Group
const SelectValue   = SelectPrimitive.Value

const SelectTrigger = React.forwardRef(({ className, children, state = "default", ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex w-full items-center justify-between gap-2",
      "h-10 rounded-md bg-[hsl(var(--card))] px-3 py-2",
      "font-headline text-[14px] tracking-[0.01em] text-[hsl(var(--foreground))]",
      "border border-[hsl(var(--neutral-400))] transition-colors duration-150",
      "focus:outline-none focus:border-[hsl(var(--ring))] focus:ring-1 focus:ring-[hsl(var(--ring))]",
      state === "error" && "border-[hsl(var(--destructive))] focus:ring-[hsl(var(--destructive))]",
      "[&_[data-placeholder]]:text-[hsl(var(--muted-foreground))]",
      "disabled:pointer-events-none disabled:opacity-40",
      className
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <svg className="h-4 w-4 shrink-0 text-[hsl(var(--muted-foreground))]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
        <path d="m6 9 6 6 6-6" />
      </svg>
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
))
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName

const SelectContent = React.forwardRef(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 min-w-[8rem] overflow-hidden",
        "rounded-sm bg-[hsl(var(--card))] border border-[hsl(var(--border))] shadow-[var(--shadow-elevation-2)]",
        "data-[state=open]:animate-fade-in data-[state=closed]:animate-fade-out",
        position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=top]:-translate-y-1",
        className
      )}
      position={position}
      {...props}
    >
      <SelectPrimitive.Viewport className={cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]")}>
        {children}
      </SelectPrimitive.Viewport>
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
))
SelectContent.displayName = SelectPrimitive.Content.displayName

const SelectItem = React.forwardRef(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center",
      "rounded-[2px] px-2 py-2 pr-8",
      "font-sans text-[14px] font-medium text-[hsl(var(--foreground))]",
      "outline-none focus:bg-[hsl(var(--neutral-100))]",
      "data-[disabled]:pointer-events-none data-[disabled]:opacity-40",
      className
    )}
    {...props}
  >
    <span className="absolute right-2 flex h-4 w-4 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="m5 12 5 5L20 7" />
        </svg>
      </SelectPrimitive.ItemIndicator>
    </span>
    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
))
SelectItem.displayName = SelectPrimitive.Item.displayName

const SelectLabel = React.forwardRef(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("font-mono text-[10px] font-semibold uppercase tracking-[0.06em] text-[hsl(var(--muted-foreground))] px-2 py-1.5", className)}
    {...props}
  />
))
SelectLabel.displayName = SelectPrimitive.Label.displayName

const SelectSeparator = React.forwardRef(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator ref={ref} className={cn("-mx-1 my-1 h-px bg-[hsl(var(--border))]", className)} {...props} />
))
SelectSeparator.displayName = SelectPrimitive.Separator.displayName

/* ─── 5. Checkbox ────────────────────────────────────────────────────────── */
/*
 * Figma: 01. Components > Atomic > checkbox (127:2068). Caixa de 14×14, raio 2, borda neutral/400, marcada = brand/black.
 * Estados: Unchecked | Checked | Indeterminate | Disabled. Rótulo Helvetica Medium 14/14; descrição mono 14/20.
 * O Tailwind deste projeto roda sem preflight: o <button> do Radix traria 6px de padding e a caixa ficaria sem área
 * para o ícone (0px de largura). Por isso o p-0.
 */

const Checkbox = React.forwardRef(({ className, indeterminate, checked, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    className={cn(
      "peer h-3.5 w-3.5 shrink-0 p-0 rounded-[2px] border border-[hsl(var(--neutral-400))] bg-[hsl(var(--card))]",
      "data-[state=checked]:bg-[hsl(var(--primary))] data-[state=checked]:border-[hsl(var(--primary))] data-[state=checked]:text-[hsl(var(--primary-foreground))]",
      "data-[state=indeterminate]:bg-[hsl(var(--primary))] data-[state=indeterminate]:border-[hsl(var(--primary))] data-[state=indeterminate]:text-[hsl(var(--primary-foreground))]",
      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2",
      "disabled:cursor-not-allowed disabled:opacity-40",
      "transition-colors duration-150",
      className
    )}
    checked={indeterminate ? "indeterminate" : checked}
    {...props}
  >
    <CheckboxPrimitive.Indicator className="flex items-center justify-center text-current">
      {indeterminate ? (
        <svg className="h-2.5 w-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
          <path d="M5 12h14" />
        </svg>
      ) : (
        <svg className="h-2.5 w-2.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
          <path d="m5 12 5 5L20 7" />
        </svg>
      )}
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))
Checkbox.displayName = CheckboxPrimitive.Root.displayName

function CheckboxField({ id, label, description, checked, indeterminate, onCheckedChange, disabled, className }) {
  const fieldId = id ?? React.useId()
  return (
    <div className={cn("flex items-start gap-2", className)}>
      <Checkbox
        id={fieldId}
        checked={checked}
        indeterminate={indeterminate}
        onCheckedChange={(v) => onCheckedChange?.(v === true)}
        disabled={disabled}
      />
      <div className="flex flex-col gap-1.5">
        <label
          htmlFor={fieldId}
          className={cn(
            "font-headline text-[14px] font-medium leading-[14px] tracking-[0.01em] text-[hsl(var(--foreground))] cursor-pointer", // label: Helvetica Medium 14/14
            disabled && "opacity-40 cursor-not-allowed"
          )}
        >
          {label}
        </label>
        {description && (
          <p className="font-mono text-[14px] leading-5 text-[hsl(var(--muted-foreground))]">{description}</p> /* Figma: mono 14/20 em #ADB5BD (2,1:1); usamos neutral/600 */
        )}
      </div>
    </div>
  )
}

/* ─── 11. Toast ───────────────────────────────────────────────────────────
/*
 * Figma: alter dialog (913:15698). Um só visual para todos os tipos: vidro neutral/100 a 90%, borda neutral/100,
 * raio 8, padding 16/16/20. Título em IBM Plex Mono SemiBold 16 caixa alta + fechar (16), e abaixo uma frase de
 * destaque (Helvetica Bold 14, neutral/900) e o texto (Helvetica 14, neutral/700).
 * O tipo não muda a cor: ele só decide o papel ARIA (error e warning interrompem o leitor de tela).
 */

const Toast = React.forwardRef(({ className, type = "info", title, lead, description, onClose, ...props }, ref) => (
  <div
    ref={ref}
    data-type={type}
    role={type === "error" || type === "warning" ? "alert" : "status"}
    className={cn(
      "flex w-full flex-col gap-3 rounded-md border border-[var(--c-neutral-100)] px-4 pb-5 pt-4",
      "bg-[color-mix(in_srgb,var(--c-neutral-100)_90%,transparent)] backdrop-blur-[24px] backdrop-saturate-150",
      "shadow-[inset_0_1px_0_rgba(255,255,255,0.6)]",
      className
    )}
    {...props}
  >
    <div className="flex items-center gap-4">
      <p className="m-0 min-w-0 flex-1 font-mono text-[16px] font-semibold uppercase leading-[21px] text-[var(--c-brand-black)]">{title}</p>
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar"
          className="relative flex h-4 w-4 shrink-0 items-center justify-center border-0 bg-transparent p-0 before:absolute before:-inset-3 before:content-[''] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2"
        >
          <CarbonIcon name="close" size={16} />
        </button>
      )}
    </div>
    {(lead || description) && (
      <div className="flex flex-col gap-1">
        {lead && <p className="m-0 font-headline text-[14px] font-bold leading-[17px] tracking-[0.01em] text-[hsl(var(--neutral-900))]">{lead}</p>}
        {description && <p className="m-0 font-headline text-[14px] leading-[17px] tracking-[0.01em] text-[hsl(var(--neutral-700))]">{description}</p>}
      </div>
    )}
  </div>
))
Toast.displayName = "Toast"

/* ─── 12. Chip / Tag ─────────────────────────────────────────────────────── */
/*
 * Figma: 01. Components > Custom components > badge (127:1117) e filters-tab (904:15794), onboarding (848:27363).
 * Style:  Filled (neutral/200 + borda 0,5 neutral/300) | Outlined (borda neutral/200)
 * State:  Default | Active (brand/black a 80%, texto branco)
 * Size:   md = IBM Plex Mono SemiBold 12 (filtros) | sm = SemiBold 10 (interesses). Os dois com 32 de altura e 12 de padding.
 * Slots:  iconLeft / iconRight (16px)
 */

const chipVariants = cva(
  [
    "inline-flex h-8 items-center justify-center gap-2 px-3",
    "font-mono font-semibold uppercase tracking-[0.01em]",
    "rounded-full border",
    "transition-colors duration-150",
    "select-none cursor-default",
  ].join(" "),
  {
    variants: {
      chipStyle: {
        filled:   "",
        outlined: "",
      },
      state: {
        default: "",
        active:  "",
      },
      size: {
        md: "text-[12px] leading-[18px]",
        sm: "text-[10px]",
      },
    },
    compoundVariants: [
      /* Filled / Default — neutral/200 com borda de 0,5px neutral/300 */
      {
        chipStyle: "filled",
        state: "default",
        className: "bg-[hsl(var(--neutral-200))] border-[0.5px] border-[hsl(var(--neutral-300))] text-[hsl(var(--foreground))]",
      },
      /* Filled / Active — brand/black a 80%, borda neutral/00, texto branco */
      {
        chipStyle: "filled",
        state: "active",
        className: "bg-[color-mix(in_srgb,var(--c-brand-black)_80%,transparent)] border-[0.5px] border-[var(--c-neutral-00)] text-[hsl(var(--primary-foreground))]",
      },
      /* Outlined / Default — sem fundo, borda neutral/200 */
      {
        chipStyle: "outlined",
        state: "default",
        className: "bg-transparent border-[hsl(var(--neutral-200))] text-[hsl(var(--foreground))]",
      },
      /* Outlined / Active — [ASSUMPTION] o kit não desenha: borda brand/black */
      {
        chipStyle: "outlined",
        state: "active",
        className: "bg-transparent border-[hsl(var(--primary))] text-[hsl(var(--foreground))]",
      },
    ],
    defaultVariants: {
      chipStyle: "filled",
      state: "default",
      size: "md",
    },
  }
)

/* Com onClick vira <button aria-pressed>: state="active" é "selecionado". Sem onClick segue um <div> só de leitura.
   O grupo `group` deixa o ícone reagir ao estado (ex.: group-aria-pressed:invert). */
const Chip = React.forwardRef(
  ({ className, chipStyle, state, size, iconLeft, iconRight, children, onClick, ...props }, ref) => {
    const Comp = onClick ? "button" : "div"
    return (
      <Comp
        ref={ref}
        {...(onClick ? { type: "button", onClick, "aria-pressed": state === "active" } : {})}
        className={cn(
          "group",
          chipVariants({ chipStyle, state, size }),
          onClick && "cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] focus-visible:ring-offset-2",
          className
        )}
        {...props}
      >
        {iconLeft && <span className="shrink-0" aria-hidden="true">{iconLeft}</span>}
        {children}
        {iconRight && <span className="shrink-0" aria-hidden="true">{iconRight}</span>}
      </Comp>
    )
  }
)
Chip.displayName = "Chip"

/* ─── Ícones ─────────────────────────────────────────────────────────────── */
// IBM Carbon Icons (o conjunto do Figma: página 01. Components > IBM Icons). Preenchidos (fill), grade de 32, cor = currentColor.
// Caminhos copiados de @carbon/icons 11 (svg/32). Para um ícone novo: copie o <path> do mesmo pacote e adicione aqui.
const CARBON = {
  add: 'M17 15L17 8 15 8 15 15 8 15 8 17 15 17 15 24 17 24 17 17 24 17 24 15z',
  bookmark: 'M24,4V26.75l-7.1-3.59-.9-.45-.9.45L8,26.75V4H24m0-2H8A2,2,0,0,0,6,4V30L16,25,26,30V4A2,2,0,0,0,24,2Z',
  settings: 'M27,16.76c0-.25,0-.5,0-.76s0-.51,0-.77l1.92-1.68A2,2,0,0,0,29.3,11L26.94,7a2,2,0,0,0-1.73-1,2,2,0,0,0-.64.1l-2.43.82a11.35,11.35,0,0,0-1.31-.75l-.51-2.52a2,2,0,0,0-2-1.61H13.64a2,2,0,0,0-2,1.61l-.51,2.52a11.48,11.48,0,0,0-1.32.75L7.43,6.06A2,2,0,0,0,6.79,6,2,2,0,0,0,5.06,7L2.7,11a2,2,0,0,0,.41,2.51L5,15.24c0,.25,0,.5,0,.76s0,.51,0,.77L3.11,18.45A2,2,0,0,0,2.7,21L5.06,25a2,2,0,0,0,1.73,1,2,2,0,0,0,.64-.1l2.43-.82a11.35,11.35,0,0,0,1.31.75l.51,2.52a2,2,0,0,0,2,1.61h4.72a2,2,0,0,0,2-1.61l.51-2.52a11.48,11.48,0,0,0,1.32-.75l2.42.82a2,2,0,0,0,.64.1,2,2,0,0,0,1.73-1L29.3,21a2,2,0,0,0-.41-2.51ZM25.21,24l-3.43-1.16a8.86,8.86,0,0,1-2.71,1.57L18.36,28H13.64l-.71-3.55a9.36,9.36,0,0,1-2.7-1.57L6.79,24,4.43,20l2.72-2.4a8.9,8.9,0,0,1,0-3.13L4.43,12,6.79,8l3.43,1.16a8.86,8.86,0,0,1,2.71-1.57L13.64,4h4.72l.71,3.55a9.36,9.36,0,0,1,2.7,1.57L25.21,8,27.57,12l-2.72,2.4a8.9,8.9,0,0,1,0,3.13L27.57,20Z M16,22a6,6,0,1,1,6-6A5.94,5.94,0,0,1,16,22Zm0-10a3.91,3.91,0,0,0-4,4,3.91,3.91,0,0,0,4,4,3.91,3.91,0,0,0,4-4A3.91,3.91,0,0,0,16,12Z',
  draggable: 'M10 6H14V10H10zM18 6H22V10H18zM10 14H14V18H10zM18 14H22V18H18zM10 22H14V26H10zM18 22H22V26H18z',
  locationFilled: 'M16,2A11.0134,11.0134,0,0,0,5,13a10.8885,10.8885,0,0,0,2.2163,6.6s.3.3945.3482.4517L16,30l8.439-9.9526c.0444-.0533.3447-.4478.3447-.4478l.0015-.0024A10.8846,10.8846,0,0,0,27,13,11.0134,11.0134,0,0,0,16,2Zm0,15a4,4,0,1,1,4-4A4.0045,4.0045,0,0,1,16,17Z',
  chevronDown: 'M16 22L6 12 7.4 10.6 16 19.2 24.6 10.6 26 12z',
  arrowLeft: 'M14 26L15.41 24.59 7.83 17 28 17 28 15 7.83 15 15.41 7.41 14 6 4 16 14 26z',
  radioButton: 'M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,26A12,12,0,1,1,28,16,12,12,0,0,1,16,28Z',
  circleFilled: 'M2,16a14,14,0,1,0,28,0a14,14,0,1,0,-28,0Z',
  overflowHorizontal: 'M6,16a2,2,0,1,0,4,0a2,2,0,1,0,-4,0ZM14,16a2,2,0,1,0,4,0a2,2,0,1,0,-4,0ZM22,16a2,2,0,1,0,4,0a2,2,0,1,0,-4,0Z',
  bookmarkFilled: 'M24,2H8A2,2,0,0,0,6,4V30l10-5.0538L26,30V4A2,2,0,0,0,24,2Z',
  chat: 'M17.74,30,16,29l4-7h6a2,2,0,0,0,2-2V8a2,2,0,0,0-2-2H6A2,2,0,0,0,4,8V20a2,2,0,0,0,2,2h9v2H6a4,4,0,0,1-4-4V8A4,4,0,0,1,6,4H26a4,4,0,0,1,4,4V20a4,4,0,0,1-4,4H21.16ZM8,10H24v2H8ZM8,16H16v2H8Z',
  arrowUp: 'M16 4L6 14 7.41 15.41 15 7.83 15 28 17 28 17 7.83 24.59 15.41 26 14z',
  // code tem um segundo traço girado: [caminho, transform]
  code: ['M31 16L24 23 22.59 21.59 28.17 16 22.59 10.41 24 9 31 16zM1 16L8 9 9.41 10.41 3.83 16 9.41 21.59 8 23 1 16z', ['M5.91 15H26.08V17H5.91z', 'rotate(-75 15.996 16)']],
  addComment: ['M17.74,30,16,29l4-7h6a2,2,0,0,0,2-2V8a2,2,0,0,0-2-2H6A2,2,0,0,0,4,8V20a2,2,0,0,0,2,2h9v2H6a4,4,0,0,1-4-4V8A4,4,0,0,1,6,4H26a4,4,0,0,1,4,4V20a4,4,0,0,1-4,4H21.16Z', 'M17 9L15 9 15 13 11 13 11 15 15 15 15 19 17 19 17 15 21 15 21 13 17 13 17 9z'],
  close: 'M24 9.4L22.6 8 16 14.6 9.4 8 8 9.4 14.6 16 8 22.6 9.4 24 16 17.4 22.6 24 24 22.6 17.4 16z',
};

export function CarbonIcon({ name, size = 24, ...rest }) {
  return (
    <svg className="bl-icon" width={size} height={size} viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" {...rest}>
      {[].concat(CARBON[name]).map((p, i) => (Array.isArray(p) ? <path key={i} d={p[0]} transform={p[1]} /> : <path key={i} d={p} />))}
    </svg>
  );
}
export const CARBON_ICON_NAMES = Object.keys(CARBON);

export { Button, Select, SelectGroup, SelectValue, SelectTrigger, SelectContent, SelectItem, SelectLabel, SelectSeparator, Checkbox, CheckboxField, Toast, Chip }
