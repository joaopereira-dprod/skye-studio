// Copiar texto para a área de transferência. Num artefato publicado (iframe) ou no tablet o navegador pode bloquear o acesso direto,
// então há dois caminhos de reserva: o comando antigo de copiar e, se nada funcionar, selecionar o texto na tela para a pessoa copiar na mão.
// Devolve true se copiou, false se só conseguiu selecionar (o chamador avisa).
export async function copyText(text, el) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch { /* sem permissão: tenta o caminho de reserva */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
    document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    if (ok) return true;
  } catch { /* segue para a seleção */ }
  if (el) { // deixa o texto selecionado: é só tocar em Copiar do sistema
    if (el.select) { el.focus(); el.select(); } else { const r = document.createRange(); r.selectNodeContents(el); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); }
  }
  return false;
}
