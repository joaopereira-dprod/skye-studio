import { Fragment, useEffect, useRef, useState } from 'react';
import { HISTORY } from 'studio-project';
import { PortalContainer } from 'studio-project';
import { Toast, Button, CheckboxField } from './ui/kit.jsx';
import { dsInfoFor } from './fiber.js';
import { Inspector, describe } from './Inspector.jsx';
import { SCREENS, STUBS } from 'studio-project';
import { TabBar } from 'studio-project';
import { IOSChrome, DesktopChrome, useNavStack } from './ios.jsx';
import { FilterTags } from './FilterTags.jsx';
import { NavItem } from './SideNav.jsx';
import { screenData } from './design.js';
import { loadComments, saveComments, newId } from './comments.js';
import { t } from './i18n.js';

// A moldura vem de platform no studio.config.json: celular (iPhone 393 × 852) ou navegador (1280 × 800)
const DESKTOP = __STUDIO_PLATFORM__ === 'desktop';
const W = DESKTOP ? 1280 : 393, H = DESKTOP ? 800 : 852;
const CATS = [...new Set(SCREENS.map((s) => s.group))];
const catOf = (id) => SCREENS.find((s) => s.id === id)?.group;

// tool vem do cabeçalho: 'inspect' (Modo dev), 'comment' (pinos) ou null. Só uma por vez.
export function Prototype({ version, resetVersion, openComp, tool }) {
  const inspect = tool === 'inspect';
  const comment = tool === 'comment';
  const [comments, setComments] = useState([]);
  const [disk, setDisk] = useState(false); // true quando a lista vive em .studio/comments.json (npm run dev)
  const [draft, setDraft] = useState(null); // pino novo, ainda sem texto: { x, y, target }
  const [draftText, setDraftText] = useState('');
  const [openId, setOpenId] = useState(null); // pino aberto
  const [toast, setToast] = useState(null);
  const [ctx, setCtx] = useState({}); // o que atravessa telas: fluxo (cadastro ou recuperar), email, perfil escolhido
  const [phoneEl, setPhoneEl] = useState(null); // dialogs são montados aqui dentro, não no body
  const [k, setK] = useState(1);
  const [compare, setCompare] = useState(false); // sobrepõe a imagem do Figma à tela atual
  const [cmpMode, setCmpMode] = useState('sobrepor');
  const [cmpOpacity, setCmpOpacity] = useState(50);
  const timer = useRef();
  useEffect(() => { let on = true; loadComments().then((r) => { if (on) { setComments(r.comments); setDisk(r.disk); } }); return () => { on = false; }; }, []);
  const nav = useNavStack(SCREENS[0].id, k, { instant: DESKTOP }); // abre na primeira tela, qualquer que seja o id

  // O zoom cabe a moldura na coluna do palco (a largura real, que já desconta a lista de telas e o painel do inspetor) e na altura da janela
  const stageRef = useRef(null);
  useEffect(() => {
    const fit = () => {
      // largura da área do protótipo; com o painel do Modo dev ao lado (320px + 16px de vão), ele sai da conta. Em tela estreita o painel desce.
      const side = inspect && window.innerWidth > 860 ? 320 + 16 : 0;
      const w = (stageRef.current?.clientWidth || window.innerWidth - 32) - side;
      setK(Math.max(DESKTOP ? 0.25 : 0.5, Math.min(1, (window.innerHeight - 190) / H, w / W)));
    };
    fit();
    window.addEventListener('resize', fit);
    const ro = new ResizeObserver(fit);
    if (stageRef.current) ro.observe(stageRef.current);
    return () => { window.removeEventListener('resize', fit); ro.disconnect(); };
  }, [inspect]); // o painel de detalhes tira largura do celular

  const notify = (type, title, description, lead) => {
    setToast({ type, title, description, lead });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 2800);
  };
  /** go(id): empurra uma tela (push). opts.root = 'tab' troca a raiz sem animação; true, com dissolução. */
  const go = (id, patch, opts = {}) => {
    if (patch) setCtx((c) => ({ ...c, ...patch }));
    if (STUBS.includes(id)) return notify('info', t('Tela não desenhada'), t('Este destino ainda não existe no wireframe do Figma.'));
    if (opts.root) nav.reset(id, opts.root === 'tab' ? 'tab' : 'fade');
    else nav.push(id);
  };
  const top = nav.stack[nav.stack.length - 1];
  const cur = SCREENS.find((s) => s.id === top.id);
  const [cat, setCat] = useState(cur.group);
  // clicar numa categoria abre a primeira tela do fluxo (as tags acompanham a tela em que o protótipo está)
  // pais recolhíveis, como na Wiki: a categoria da tela atual abre sozinha; o chevron abre e fecha sem navegar
  const [open, setOpen] = useState(() => new Set([cur.group]));
  const toggle = (c) => setOpen((o) => { const n = new Set(o); n.has(c) ? n.delete(c) : n.add(c); return n; });
  const pickCat = (c) => { setOpen((o) => new Set(o).add(c)); setCat(c); nav.reset(SCREENS.find((s) => s.group === c).id, 'tab'); };
  useEffect(() => { setCat(catOf(top.id)); setOpen((o) => (o.has(catOf(top.id)) ? o : new Set(o).add(catOf(top.id)))); }, [top.id]); // as tags acompanham a tela em que o protótipo está
  const ref = screenData(cur.figma)?.ref; // só as telas com design/ref/<tela>.jpg têm comparação
  const mine = comments.filter((c) => c.screen === top.id);
  const openC = mine.find((c) => c.id === openId);
  const pop = draft ? { ...draft, at: draft } : openC ? { ...openC, at: openC } : null;
  const save = () => {
    if (!draftText.trim()) return;
    const c = { id: newId(), screen: top.id, x: draft.x, y: draft.y, target: draft.target, text: draftText.trim(), created: new Date().toISOString(), resolved: false };
    persist([...comments, c]); setDraft(null); setDraftText(''); setOpenId(c.id);
  };
  const v = version && HISTORY.commits.find((c) => c.sha === version);

  // Inspetor (estilo Dev Mode): com o modo ligado, clicar não navega; o elemento vai para o painel à direita.
  // Se o clique cai dentro de um componente do design system, o alvo é a raiz desse componente.
  const hit = useRef(null);
  const sel = useRef(null);
  const [details, setDetails] = useState(null);
  const mark = (ref, cls, el) => { ref.current?.classList.remove(cls); ref.current = el; el?.classList.add(cls); };
  const persist = (next) => {
    setComments(next);
    saveComments(next, disk).then((ok) => { if (!ok) notify('error', t('Não gravei os comentários'), t('O servidor local recusou a gravação em .studio/comments.json. Eles ficam só neste navegador por enquanto.')); });
  };
  const onClickCapture = (e) => {
    if (comment) {
      e.preventDefault(); e.stopPropagation();
      const r = phoneEl.getBoundingClientRect();
      const el = dsInfoFor(e.target)[0];
      const label = el ? el.name : `<${e.target.tagName.toLowerCase()}>${(e.target.textContent || '').trim().slice(0, 24)}`;
      setOpenId(null); setDraftText('');
      setDraft({ x: Math.round((e.clientX - r.left) / k), y: Math.round((e.clientY - r.top) / k), target: label });
      return;
    }
    if (!inspect) return;
    e.preventDefault(); e.stopPropagation();
    const el = dsInfoFor(e.target)[0]?.node || e.target;
    mark(sel, 'insp-sel', el);
    setDetails(describe(el, dsInfoFor(el), k));
  };
  const onMouseOver = (e) => { if (inspect || comment) mark(hit, 'insp-hover', e.target); };
  useEffect(() => { if (!inspect && !comment) mark(hit, 'insp-hover', null); }, [inspect, comment]);
  useEffect(() => { if (!comment) { setDraft(null); setOpenId(null); } }, [comment]);
  useEffect(() => { setDraft(null); setOpenId(null); }, [top.id]);
  useEffect(() => { if (!inspect) { mark(hit, 'insp-hover', null); mark(sel, 'insp-sel', null); setDetails(null); } }, [inspect]);
  useEffect(() => { mark(sel, 'insp-sel', null); setDetails(null); }, [top.id]); // trocou de tela: o elemento selecionado saiu do ar

  return (
    <div className={`proto${inspect ? ' has-insp' : ''}`}>
      <aside className="flow" aria-label={t('Fluxo de telas')}>
        {/* telas largas: uma lista só, a categoria aberta mostra as telas dela logo abaixo */}
        <div className="field flow-tree">
          <span className="st-label-md muted">{t('FLUXOS')}</span>
          <div className="snav">
            {CATS.map((c) => {
              const isOpen = open.has(c);
              return (
                <Fragment key={c}>
                  <div className="flow-row">
                    <NavItem active={cat === c} label={t(c)} onClick={() => pickCat(c)} />
                    <button type="button" className="flow-tog" aria-expanded={isOpen} aria-label={`${isOpen ? t('Recolher') : t('Expandir')} ${c}`} onClick={() => toggle(c)}>
                      <svg className="snav-chev" width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M2 3.5 5 6.5 8 3.5" /></svg>
                    </button>
                  </div>
                  <div className="sub" data-open={isOpen}>
                    <div className="sub-in" {...(isOpen ? {} : { inert: '' })}>
                      <div className="snav-group flow-sub" role="group" aria-label={t('Telas de {c}', { c })}>
                        {SCREENS.filter((s) => s.group === c).map((s) => <NavItem key={s.id} active={top.id === s.id} onClick={() => nav.reset(s.id, 'tab')} label={t(s.label)} />)}
                      </div>
                    </div>
                  </div>
                </Fragment>
              );
            })}
          </div>
        </div>
        {/* telas estreitas: tags em cima e as telas da categoria numa fileira rolável */}
        <div className="field flow-tags">
          <span className="st-label-md muted">{t('CATEGORIA')}</span>
          <FilterTags label={t('Categoria de telas')} value={cat} onChange={pickCat} items={CATS.map((c) => ({ id: c, label: t(c) }))} />
        </div>
        <div className="field flow-screens">
          <span className="st-label-md muted">{t('TELAS')}</span>
          <div className="snav">
            <div className="snav-group" role="group" aria-label={t('Telas')}>
              {SCREENS.filter((s) => s.group === cat).map((s) => <NavItem key={s.id} active={top.id === s.id} onClick={() => nav.reset(s.id, 'tab')} label={t(s.label)} />)}
            </div>
          </div>
        </div>
        <div className="field">
          <span className="st-label-md muted">{t('FERRAMENTAS')}</span>
          <span className="st-body-xs muted">
            {inspect && t('Modo dev ligado: clicar em um elemento mostra o código, as medidas e os tokens dele no painel ao lado. Os cliques não navegam.')}
            {comment && `${t('Comentar ligado: clicar na tela põe um pino com o seu comentário.')} ${disk ? t('Eles ficam em .studio/comments.json, na pasta do projeto.') : t('Sem o servidor local (npm run dev), ficam só neste navegador.')}`}
            {!inspect && !comment && t('Modo dev e Comentar ficam nos botões do cabeçalho.')}
            {!DESKTOP && ` ${t('No celular: arraste a partir da borda esquerda para voltar.')}`}
          </span>
          {comment && (
            <div className="cmt-list">
              <span className="st-label-md muted">{t('COMENTÁRIOS DESTA TELA ({n})', { n: mine.length })}</span>
              {mine.map((c) => (
                <button key={c.id} type="button" className={`cmt-item${c.resolved ? ' is-done' : ''}`} onClick={() => { setDraft(null); setOpenId(c.id); }}>
                  <b className="cmt-n">{comments.indexOf(c) + 1}</b><span className="st-body-sm">{c.text}</span>
                </button>
              ))}
            </div>
          )}
          {ref && (
            <>
              <CheckboxField id="compare" label={t('Comparar com a referência do Figma')} checked={compare} onCheckedChange={(v) => setCompare(v === true)} />
              {compare && (
                <div className="cmp">
                  <FilterTags label={t('Modo de comparação')} value={cmpMode} onChange={setCmpMode} items={[{ id: 'sobrepor', label: t('Sobrepor') }, { id: 'diferenca', label: t('Diferença') }]} />
                  {cmpMode === 'sobrepor' && (
                    <label className="cmp-range st-body-xs muted">{t('Opacidade da referência: {n}%', { n: cmpOpacity })}
                      <input type="range" min="0" max="100" step="5" value={cmpOpacity} onChange={(e) => setCmpOpacity(Number(e.target.value))} />
                    </label>
                  )}
                  <span className="st-body-xs muted">{cmpMode === 'diferenca' ? t('Preto = igual ao Figma. Qualquer cor mostra o desvio.') : t('Arraste a opacidade para alternar entre o protótipo e o Figma.')}</span>
                </div>
              )}
            </>
          )}
        </div>
      </aside>
      <div className="work" ref={stageRef}>
      <div className="stage">
        {v && <div className="verbar"><span className="pill mono">{t('versão {v}', { v: v.short || v.sha })}</span><Button variant="outline" onClick={resetVersion}>{t('Voltar para a atual')}</Button></div>}
        <div className="phone-wrap" style={{ width: W * k, height: H * k }}>
          {comment && mine.map((c) => <button key={c.id} type="button" className={`cmt-pin${c.resolved ? ' is-done' : ''}`} style={{ left: c.x * k, top: c.y * k }} aria-label={t('Comentário {n}: {text}', { n: comments.indexOf(c) + 1, text: c.text })} onClick={() => { setDraft(null); setOpenId(c.id); }}>{comments.indexOf(c) + 1}</button>)}
          {comment && draft && <span className="cmt-pin is-draft" style={{ left: draft.x * k, top: draft.y * k }} aria-hidden="true">+</span>}
          {comment && pop && (
            <div className={`cmt-pop${pop.x * k > (W * k) / 2 ? ' is-left' : ''}`} style={{ left: pop.x * k, top: pop.y * k }} role="dialog" aria-label={t('Comentário')} onKeyDown={(e) => { if (e.key === 'Escape') { setDraft(null); setOpenId(null); } }}>
              <span className="st-label-md muted">{pop.target}</span>
              {draft ? (
                <>
                  <textarea autoFocus className="cmt-text st-body-sm" rows={3} value={draftText} onChange={(e) => setDraftText(e.target.value)} placeholder={t('O que precisa mudar aqui?')} aria-label={t('Texto do comentário')} />
                  <div className="cmt-actions"><Button variant="outline" onClick={() => setDraft(null)}>{t('Cancelar')}</Button><Button onClick={save} disabled={!draftText.trim()}>{t('Salvar')}</Button></div>
                </>
              ) : (
                <>
                  <p className="st-body-sm cmt-body">{openC.text}</p>
                  <div className="cmt-actions">
                    <Button variant="outline" onClick={() => persist(comments.filter((c) => c.id !== openC.id))}>{t('Excluir')}</Button>
                    <Button variant="subtle" onClick={() => persist(comments.map((c) => (c.id === openC.id ? { ...c, resolved: !c.resolved } : c)))}>{openC.resolved ? t('Reabrir') : t('Resolver')}</Button>
                  </div>
                </>
              )}
            </div>
          )}
          <div ref={setPhoneEl} className={`phone${DESKTOP ? ' is-desktop' : ''}${inspect || comment ? ' is-inspect' : ''}`} style={{ transform: `scale(${k})` }} {...(DESKTOP ? {} : nav.gesture)} onClickCapture={onClickCapture} onMouseOver={onMouseOver}>
            <PortalContainer value={phoneEl}>
              <div className="phone-nav" data-busy={nav.phase !== 'idle'}>
                {nav.stack.map((e, i) => {
                  const cfg = SCREENS.find((s) => s.id === e.id);
                  const Screen = cfg.Component;
                  const isTop = i === nav.stack.length - 1;
                  const visible = isTop || (i === nav.stack.length - 2 && nav.phase !== 'idle'); // a de baixo aparece enquanto anima
                  return (
                    <div key={e.key} ref={nav.register(e.key)} className={`nav-layer${DESKTOP || cfg.bare || cfg.notab ? '' : ' has-tabbar'}`} style={{ visibility: visible ? 'visible' : 'hidden' }} aria-hidden={!isTop} {...(isTop ? {} : { inert: '' })}>
                      {!cfg.bare && <div className="status-spacer" />}
                      <div className={`phone-body${cfg.bare ? ' is-bare' : ''}`}>
                        <Screen go={go} back={nav.back} notify={notify} ctx={ctx} patchCtx={(p) => setCtx((c) => ({ ...c, ...p }))} />
                      </div>
                      <div className="nav-dim" />
                    </div>
                  );
                })}
              </div>
              {!DESKTOP && !cur.bare && !cur.notab && <TabBar current={top.id === 'detalhe' ? 'home' : top.id === 'mapa' ? 'roteiros' : top.id} go={go} />}
              {toast && <div className="phone-toast"><Toast {...toast} onClose={() => setToast(null)} /></div>}
              {DESKTOP ? <DesktopChrome path={`app.local/${top.id}`} /> : <IOSChrome />}
              {ref && compare && <img className="phone-ref" src={ref} alt="" aria-hidden="true" style={cmpMode === 'diferenca' ? { mixBlendMode: 'difference' } : { opacity: cmpOpacity / 100 }} />}
            </PortalContainer>
          </div>
        </div>
        <p className="st-body-xs muted">{DESKTOP ? t('Navegador 1280 × 800.') : `iPhone 393 × 852${SCREENS.some((s) => s.figma) ? t(' do Figma') : ''}.`} {t('Imagens são marcadores.')}</p>
      </div>
      {inspect && <Inspector data={details} onWiki={openComp} />}
      </div>
    </div>
  );
}
