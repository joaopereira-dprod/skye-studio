// Comentários do Protótipo. A página só conhece estas funções.
//   - `npm run dev`: o servidor local lê e grava .studio/comments.json (endpoint /__comments, mesmo token do agente);
//   - artefato publicado ou página sem o servidor: ficam no localStorage do navegador (só nesta máquina).
// Um comentário: { id, screen, x, y, target, text, created, resolved }. x e y são pixels da moldura, sem zoom.

const KEY = 'studio-comments';
const cfg = () => (typeof window !== 'undefined' ? window.__STUDIO_AGENT__ : null);
const headers = () => ({ 'Content-Type': 'application/json', 'x-studio-token': cfg().token });

const readLocal = () => { try { const l = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(l) ? l : []; } catch { return []; } };
const writeLocal = (list) => { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* armazenamento bloqueado */ } };

/** Resolve { comments, disk }: disk é true quando a lista vem do arquivo do projeto. */
export async function loadComments() {
  if (cfg()?.token) {
    try {
      const r = await fetch('/__comments', { headers: headers() });
      if (r.ok) return { comments: (await r.json()).comments, disk: true };
    } catch { /* cai no navegador */ }
  }
  return { comments: readLocal(), disk: false };
}

/** Grava a lista inteira. Resolve true se gravou onde pretendia; false se o servidor recusou (a lista fica ao menos no navegador). */
export async function saveComments(list, disk) {
  writeLocal(list);
  if (!disk) return true;
  try {
    const r = await fetch('/__comments', { method: 'PUT', headers: headers(), body: JSON.stringify({ comments: list }) });
    return r.ok;
  } catch { return false; }
}

export const newId = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));
