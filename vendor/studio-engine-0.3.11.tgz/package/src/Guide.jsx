// Passo a passo do zero ao primeiro projeto (dados em guide.js). Cada passo mostra ONDE fazer (terminal, navegador ou chat),
// o porquê, os comandos com botão Copiar e como saber que deu certo. "Feito" fica salvo no navegador. Nada aqui executa comandos:
// o Studio só mostra e copia; quem cola e envia é você.
import { useEffect, useRef, useState } from 'react';
import { GUIDE_STEPS, WHERE } from './guide.js';
import { Button } from './ui/kit.jsx';
import { copyText } from './copy.js';
import { probeAgent } from './agent.js';
import { t } from './i18n.js';

const KEY = 'studio-guide';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; } };
const save = (ids) => { try { localStorage.setItem(KEY, JSON.stringify(ids)); } catch { /* sem armazenamento: o guia funciona, só não lembra */ } };
const ask = (draft) => window.dispatchEvent(new CustomEvent('studio:chat', { detail: { draft } }));

// O que estiver entre < > é o que a pessoa troca pelo dela: destacado na tela, intacto no Copiar.
function Command({ text }) {
  const [state, setState] = useState(null); // true | 'manual'
  const ref = useRef(null);
  const copy = () => copyText(text, ref.current).then((ok) => { setState(ok ? true : 'manual'); setTimeout(() => setState(null), 2400); });
  return (
    <div className="cmd">
      <code ref={ref} className="cmd__text mono">{text.split(/(<[^>]+>)/).map((s, i) => (/^<[^>]+>$/.test(s) ? <mark key={i}>{s}</mark> : s))}</code>
      <Button variant="outline" className="cmd__copy" onClick={copy}>{state === true ? t('Copiado') : state === 'manual' ? t('Selecionado') : t('Copiar')}</Button>
    </div>
  );
}

export function Guide() {
  const [done, setDone] = useState(load);
  const [agent, setAgent] = useState({ ready: false }); // o botão de ajuda só faz sentido quando há um agente ligado ao Studio
  useEffect(() => { probeAgent().then(setAgent); }, []);
  const firstTodo = GUIDE_STEPS.find((s) => !done.includes(s.id));
  const [open, setOpen] = useState(firstTodo ? firstTodo.id : null);
  const toggleDone = (id) => setDone((d) => { const n = d.includes(id) ? d.filter((x) => x !== id) : [...d, id]; save(n); return n; });
  const n = GUIDE_STEPS.filter((s) => done.includes(s.id)).length;
  return (
    <div className="guide">
      <p className="st-body-xs muted">{t('{n} de {total} passos feitos', { n, total: GUIDE_STEPS.length })}</p>
      <ol className="guide__list">
        {GUIDE_STEPS.map((s, i) => {
          const isOpen = open === s.id;
          const isDone = done.includes(s.id);
          const where = WHERE[s.where];
          return (
            <li key={s.id} className={`guide__step${isDone ? ' is-done' : ''}`}>
              <button type="button" className="guide__head" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : s.id)}>
                <span className="guide__num mono" aria-hidden="true">{isDone ? '✓' : i + 1}</span>
                <span className="guide__title st-body-md">{t(s.title)}</span>
                <span className="how-pill st-label-md">{t(where.label)}</span>
              </button>
              {isOpen && (
                <div className="guide__body">
                  <p className="st-body-xs muted">{t(!s.cmds && where.hintSemComando ? where.hintSemComando : where.hint)}</p>
                  <p className="st-body-sm"><b>{t('Por quê')}:</b> {t(s.why)}</p>
                  {s.site && <p className="st-body-sm"><b>{t('Endereço')}:</b> <a href={s.site} target="_blank" rel="noreferrer">{s.site}</a></p>}
                  <ol className="guide__how st-body-sm">{s.how.map((h) => <li key={h}>{t(h)}</li>)}</ol>
                  {s.cmds && <div className="guide__cmds">{s.cmds.map((c) => <Command key={c} text={c} />)}</div>}
                  {s.cmds && s.cmds.some((c) => /<[^>]+>/.test(c)) && <p className="st-body-xs muted">{t('O que está destacado entre < > é o que você troca pelo seu.')}</p>}
                  <p className="st-body-sm"><b>{t('Deu certo quando')}:</b> {t(s.check)}</p>
                  <div className="guide__actions">
                    <Button variant={isDone ? 'outline' : 'primary'} onClick={() => { toggleDone(s.id); if (!isDone) { const next = GUIDE_STEPS[i + 1]; setOpen(next ? next.id : null); } }}>{isDone ? t('Desmarcar') : t('Marcar como feito')}</Button>
                    {agent.ready && <Button variant="ghost" onClick={() => ask(t('Estou no passo {n} do guia (“{titulo}”) e travei. Me ajude, explicando como se eu nunca tivesse usado GitHub nem terminal.', { n: i + 1, titulo: t(s.title) }))}>{t('Travei, pedir ajuda')}</Button>}
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
