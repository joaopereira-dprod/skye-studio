// Página "Processo" padrão da Wiki: como o trabalho acontece num projeto com o Studio, sem nada específico de um projeto.
// Aparece em todo projeto, logo após "Como usar". O projeto a substitui declarando uma página com id 'processo' em WIKI_PAGES
// (studio.project.js). Usa as classes de layout do Studio (steps, cards, card pad, how-grid, how-card, how-pill, mono).
import { t } from './i18n.js';

const PAPEIS = [
  ['Você', 'Pede e confere', 'Descreve a mudança, olha o resultado no Protótipo e aprova.'],
  ['Claude', 'Implementa', 'Altera os arquivos, roda as verificações e abre o Pull Request.'],
  ['Equipe', 'Revisa', 'Vê o diff linha por linha no Pull Request e aprova o merge.'],
];

export function Processo() {
  return (
    <>
      <h2 className="st-headline-bold-40">{t('Processo')}</h2>
      <p className="st-display-md" style={{ fontWeight: 500, maxWidth: '60ch' }}>{t('Como o trabalho acontece neste projeto: quem faz o quê e como uma mudança chega à versão oficial.')}</p>
      <h3 className="st-display-md">{t('Quem faz o quê')}</h3>
      <div className="how-grid">
        {PAPEIS.map(([quem, papel, texto]) => (
          <div className="card how-card" key={quem}><span className="how-pill st-label-md">{t(papel).toUpperCase()}</span><b className="st-display-md">{t(quem)}</b><p className="st-body-sm muted">{t(texto)}</p></div>
        ))}
      </div>
      <h3 className="st-display-md">{t('Como contribuir')}</h3>
      <ol className="steps">
        <li>{t('Crie uma branch por assunto:')} <span className="mono">feat/{t('nome')}</span> {t('para telas e')} <span className="mono">fix/{t('nome')}</span> {t('para correções.')}</li>
        <li>{t('Peça a mudança no chat do Studio (Ctrl ou Cmd + K) ou direto ao Claude Code.')}</li>
        <li>{t('Rode')} <span className="mono">npm run check</span> {t('e confira o resultado no Protótipo.')}</li>
        <li>{t('Abra o Pull Request e descreva o que mudou e por quê.')}</li>
        <li>{t('Depois da aprovação, faça o merge na')} <span className="mono">main</span>.</li>
      </ol>
      <h3 className="st-display-md">{t('Regras')}</h3>
      <div className="cards">
        <div className="card pad"><b>{t('Uma branch por assunto')}</b><p className="st-body-sm muted">{t('Mudanças pequenas e focadas são mais fáceis de revisar e de desfazer.')}</p></div>
        <div className="card pad"><b>{t('Nada direto na main')}</b><p className="st-body-sm muted">{t('Tudo entra por Pull Request, para alguém ver o diff antes.')}</p></div>
        <div className="card pad"><b>{t('Verifique antes de pedir revisão')}</b><p className="st-body-sm muted"><span className="mono">npm run check</span> {t('precisa passar.')}</p></div>
      </div>
      <p className="st-body-sm muted" style={{ maxWidth: '60ch' }}>{t('Esta página é o padrão do Studio. Para escrever o processo do seu projeto, declare uma página com id “processo” em WIKI_PAGES (studio.project.js): ela substitui esta.')}</p>
    </>
  );
}
