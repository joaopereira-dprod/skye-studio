// Painel de detalhes do Protótipo, no estilo Dev Mode do Figma: clicou em um elemento, vê o código e os tokens dele.
// Tudo é lido do que está renderizado (props do React, estilo calculado) e ligado a tokens/tokens.json, então nunca fica desatualizado.
import { useState } from 'react';
import { TOKENS } from 'studio-project';
import { DOCS, FIGMA_FILE } from 'studio-project';
import { Button } from './ui/kit.jsx';
import { t } from './i18n.js';

const slug = (k) => k.replace(/\//g, '-');
const byValue = (obj, prefix) => new Map(Object.entries(obj).map(([k, v]) => [typeof v === 'object' ? v.value : v, `--${prefix}-${slug(k)}`]));
const SPACE = byValue(TOKENS.space, 's');
const RADIUS = byValue(TOKENS.radius, 'r');
// Vários tokens podem ter o mesmo hex (branco é brand/white, text/inverse e icon/inverse): guarda todos e escolhe pelo papel
const COLOR = new Map();
Object.entries(TOKENS.color).filter(([, v]) => /^#[0-9a-f]{6}$/i.test(v.value)).forEach(([k, v]) => {
  const h = v.value.toUpperCase();
  COLOR.set(h, [...(COLOR.get(h) || []), `--c-${slug(k)}`]);
});
const ROLE = { Texto: ['text', 'brand', 'neutral'], Fundo: ['surface', 'background', 'brand', 'neutral'], Borda: ['border', 'neutral'] };
const tokenFor = (hexValue, role) => {
  const all = COLOR.get(hexValue) || [];
  for (const p of ROLE[role]) { const t = all.find((n) => n.startsWith(`--c-${p}-`)); if (t) return t; }
  return all[0] || null;
};
const TYPE = new Set(Object.keys(TOKENS.type).map((k) => `t-${slug(k)}`));
const hex = (n) => Math.round(n).toString(16).padStart(2, '0').toUpperCase();

/** "rgb(18, 20, 22)" vira { hex, token }; transparente vira null; com transparência parcial fica sem token. */
function colorOf(css, role) {
  const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(css || '');
  if (!m || (m[4] !== undefined && Number(m[4]) === 0)) return null;
  const h = `#${hex(m[1])}${hex(m[2])}${hex(m[3])}`;
  return m[4] !== undefined && Number(m[4]) < 1 ? { hex: css, token: null } : { hex: h, token: tokenFor(h, role) };
}
const px = (v) => Math.round(parseFloat(v) * 100) / 100;
const quad = (cs, side) => ['Top', 'Right', 'Bottom', 'Left'].map((s) => px(cs[`${side}${s}`]));
/** Reduz como o CSS: 16 16 16 16 vira 16; 8 16 8 16 vira 8 16. */
const short = (a) => (a.every((n) => n === a[0]) ? [a[0]] : a[0] === a[2] && a[1] === a[3] ? [a[0], a[1]] : a);
const withTokens = (list, map) => ({ text: list.map((n) => `${n}px`).join(' '), tokens: [...new Set(list.map((n) => map.get(n)).filter(Boolean))] });

function firstTextEl(root) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  for (let n = root; n; n = w.nextNode()) if ([...n.childNodes].some((c) => c.nodeType === 3 && c.textContent.trim())) return n;
  return null;
}
function typeOf(el) {
  const cls = [];
  for (let n = el; n && !n.classList?.contains('phone'); n = n.parentElement) cls.push(...(n.classList || []));
  const cs = getComputedStyle(el);
  // 1º a classe t-* aplicada; 2º um estilo do sistema com a mesma fonte, tamanho, linha e peso (marcado com ≈: o código usa valores soltos)
  const fam = cs.fontFamily.split(',')[0].replace(/["']/g, '');
  const famKey = Object.entries(TOKENS.font).find(([, v]) => v.value.split(',')[0].replace(/["']/g, '') === fam)?.[0];
  const near = Object.entries(TOKENS.type).find(([, v]) => v.font === famKey && v.size === px(cs.fontSize) && v.weight === Number(cs.fontWeight) && Math.abs(v.line - px(cs.lineHeight)) <= 1);
  const style = cls.find((c) => TYPE.has(c)) || (near ? `≈ t-${slug(near[0])}` : null);
  const metrics = `${px(cs.fontSize)} / ${px(cs.lineHeight) || 'normal'} · ${cs.fontWeight}`;
  return { style: style || null, metrics, family: cs.fontFamily.split(',')[0].replace(/["']/g, '') };
}

/** Lê o elemento e devolve o que o painel mostra. `k` é a escala do celular no Studio. */
export function describe(el, infos, k) {
  const cs = getComputedStyle(el);
  const r = el.getBoundingClientRect();
  const ds = infos[0] || null;
  const textEl = firstTextEl(el);
  const rows = [['Largura', { text: `${px(r.width / k)}px`, tokens: [] }], ['Altura', { text: `${px(r.height / k)}px`, tokens: [] }]];
  const pad = short(quad(cs, 'padding'));
  if (pad.some(Boolean)) rows.push(['Padding', withTokens(pad, SPACE)]);
  const gap = px(cs.rowGap);
  if (gap && /flex|grid/.test(cs.display)) rows.push(['Gap', withTokens([gap], SPACE)]);
  const rad = short(['TopLeft', 'TopRight', 'BottomRight', 'BottomLeft'].map((c) => px(cs[`border${c}Radius`])));
  if (rad.some(Boolean)) rows.push(['Raio', withTokens(rad, RADIUS)]);
  const colors = [];
  const fg = textEl && colorOf(getComputedStyle(textEl).color, 'Texto');
  if (fg) colors.push(['Texto', fg]);
  const bg = colorOf(cs.backgroundColor, 'Fundo');
  if (bg) colors.push(['Fundo', bg]);
  if (px(cs.borderTopWidth) > 0) { const b = colorOf(cs.borderTopColor, 'Borda'); if (b) colors.push(['Borda', b]); }
  // As classes insp-* são só a marcação do próprio inspetor: não fazem parte do código do elemento
  const classes = typeof el.className === 'string' ? el.className.split(/\s+/).filter((c) => c && !c.startsWith('insp-')).join(' ') : '';
  return { tag: el.tagName.toLowerCase(), ds, chain: infos.slice(1).map((i) => i.name), rows, colors, type: textEl ? typeOf(textEl) : null, text: el.textContent.trim(), classes };
}

const fmtProp = ([k, v]) => (v === true ? k : typeof v === 'string' ? `${k}="${v}"` : `${k}={${v}}`);
function jsx(d) {
  if (!d.ds) return `<${d.tag}${d.classes ? ` className="${d.classes}"` : ''}>${d.text.length > 24 ? '…' : d.text}</${d.tag}>`;
  const props = Object.entries(d.ds.props).filter(([, v]) => v !== false && v !== '' && v !== undefined).map(fmtProp);
  const open = [d.ds.name, ...props].join(' ');
  const kids = d.ds.text; // só o texto que foi passado como filho, não o que o componente desenha por dentro
  return kids ? `<${open}>${kids.length > 32 ? `${kids.slice(0, 32)}…` : kids}</${d.ds.name}>` : `<${open} />`;
}

const Tok = ({ names }) => names.length ? <span className="insp-tok mono">{names.join(' · ')}</span> : null;

export function Inspector({ data, onWiki }) {
  const [copied, setCopied] = useState(false);
  if (!data) {
    return (
      <aside className="insp" aria-label={t('Detalhes do elemento')}>
        <b className="st-display-md">{t('Detalhes')}</b>
        <p className="st-body-sm muted">{t('Clique em um elemento do celular para ver o código, as medidas e os tokens dele. Os cliques não navegam enquanto isso.')}</p>
      </aside>
    );
  }
  const doc = data.ds && DOCS.find((x) => x.name === data.ds.name);
  const code = jsx(data);
  const copy = () => { try { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* sem permissão */ } };
  return (
    <aside className="insp" aria-label="Detalhes do elemento">
      <div className="insp-head">
        <span className="st-label-md muted">{data.ds ? t('COMPONENTE') : t('ELEMENTO')}</span>
        <b className="st-display-md">{data.ds ? data.ds.name : `<${data.tag}>`}</b>
        {data.chain.length > 0 && <span className="st-body-xs muted">{t('dentro de {x}', { x: data.chain.join(' › ') })}</span>}
      </div>
      <section>
        <span className="st-label-md muted">{t('CÓDIGO')}</span>
        <pre className="code">{code}</pre>
        <Button variant="subtle" onClick={copy}>{copied ? t('Copiado') : t('Copiar código')}</Button>
      </section>
      <section>
        <span className="st-label-md muted">{t('MEDIDAS')}</span>
        <dl className="insp-list">{data.rows.map(([l, v]) => <div key={l}><dt className="st-body-sm muted">{t(l)}</dt><dd className="st-body-sm">{v.text}<Tok names={v.tokens} /></dd></div>)}</dl>
      </section>
      {data.type && (
        <section>
          <span className="st-label-md muted">{t('TEXTO')}</span>
          <dl className="insp-list">
            <div><dt className="st-body-sm muted">{t('Estilo')}</dt><dd className="st-body-sm">{data.type.style ? <span className="mono">{data.type.style}</span> : t('sem estilo do sistema')}</dd></div>
            <div><dt className="st-body-sm muted">{t('Tamanho / linha')}</dt><dd className="st-body-sm">{data.type.metrics}</dd></div>
            <div><dt className="st-body-sm muted">{t('Fonte')}</dt><dd className="st-body-sm">{data.type.family}</dd></div>
          </dl>
        </section>
      )}
      {data.colors.length > 0 && (
        <section>
          <span className="st-label-md muted">{t('CORES')}</span>
          <dl className="insp-list">{data.colors.map(([l, c]) => <div key={l}><dt className="st-body-sm muted">{t(l)}</dt><dd className="st-body-sm"><i className="insp-sw" style={{ background: c.hex }} />{c.token ? <span className="mono">{c.token}</span> : <span className="mono">{c.hex}</span>}</dd></div>)}</dl>
        </section>
      )}
      {doc && (
        <section>
          <span className="st-label-md muted">{t('LINKS')}</span>
          <div className="insp-links">
            <Button variant="link" onClick={() => onWiki(data.ds.name)}>{t('Abrir na Wiki')}</Button>
            {doc.figma && <Button variant="link" asChild><a href={`${FIGMA_FILE}?node-id=${doc.figma}`} target="_blank" rel="noreferrer">{t('Abrir no Figma')}</a></Button>}
          </div>
        </section>
      )}
    </aside>
  );
}
