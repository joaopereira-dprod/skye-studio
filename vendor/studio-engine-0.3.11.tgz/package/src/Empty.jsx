// Estado vazio das três abas, para quando a pasta ainda não tem projeto. Cada aba explica o que vai aparecer ali e mostra, só como
// ilustração (sem botão), os dois tipos de projeto; quem conduz o começo é o guia passo a passo. Os textos são chaves de tradução (t()).
import { t } from './i18n.js';
import { Guide } from './Guide.jsx';

const COPY = {
  prototipo: ['Nenhuma tela ainda', 'O Protótipo mostra as telas do projeto dentro de uma moldura de celular ou de navegador, e você navega, comenta e inspeciona cada elemento.'],
  historico: ['Sem histórico ainda', 'Cada commit e cada Pull Request do projeto aparece aqui, com a descrição, e você volta a qualquer versão para comparar.'],
  wiki: ['Wiki vazia', 'Aqui ficam as cores, os estilos de texto e os componentes do design system do projeto, com exemplos interativos.'],
};

const OPTIONS = [
  ['mobile', 'Mobile', 'App para celular, moldura de aparelho'],
  ['desktop', 'Web', 'Produto para navegador, tela larga'],
];

export function Empty({ area }) {
  const [title, text] = COPY[area].map((s) => t(s));
  return (
    <section className="sempty" aria-labelledby="empty-title">
      <span className="st-label-md muted">{t('NOVO PROJETO')}</span>
      <h1 id="empty-title" className="sempty__title">{title}</h1>
      <p className="st-body-sm muted sempty__text">{text}</p>
      <div className="sempty__grid">
        {OPTIONS.map(([id, label, hint]) => (
          <div className="card pad sempty__card" key={id}>
            <div className={`sempty__sketch sempty__sketch--${id}`} aria-hidden="true"><i /><i /><i /></div>
            <div className="sempty__meta">
              <strong className="st-body-md">{t(label)}</strong>
              <span className="st-body-xs muted">{t(hint)}</span>
            </div>
          </div>
        ))}
      </div>
      <h2 className="st-display-md sempty__sub">{t('Primeira vez? Do zero ao primeiro projeto')}</h2>
      <p className="st-body-sm muted sempty__text">{t('Cada passo diz onde fazer: no Terminal, no navegador ou aqui no chat. Pule o que você já tem.')}</p>
      <Guide />
      <p className="st-body-xs muted">{t('Ou abra a barra de chat (Ctrl ou Cmd + K) e conte, com as suas palavras, o que quer construir.')}</p>
    </section>
  );
}
