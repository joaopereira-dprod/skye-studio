---
name: design-governance
description: Revisa qualquer tela, componente ou token do projeto contra WCAG 2.2 AA, princípios da Gestalt, heurísticas de usabilidade da NN/g e as regras de governança do design system (só tokens, átomos reaproveitados, nomes consistentes). Use sempre que criar ou alterar tela, componente ou token, antes de commitar, e quando a pessoa pedir revisão, auditoria, acessibilidade ou consistência.
---

# design-governance: manter tudo consistente e acessível

Responda no idioma da pessoa e **explique o porquê de cada achado** (é regra dela). Seja específico: arquivo, tela ou token, o que está errado, a regra quebrada e a correção proposta. Nunca aprove "no olho": cada item abaixo tem um critério verificável.

## Quando rodar
1. **Ao criar ou alterar** tela, componente ou token: rode a Parte A antes de dizer que terminou.
2. **Antes de cada commit** de UI: Partes A e B nos arquivos alterados.
3. **Quando a pessoa pedir** revisão, auditoria ou "está consistente?": todas as partes, no projeto inteiro.

## Parte A: o que se mede (automático)
Rode `npx studio governance` (ou `npm run governance` se o projeto tiver o atalho). Ele confere:
- contraste dos tokens de cor (texto 4,5:1, ícones e foco 3:1: WCAG 1.4.3 e 1.4.11);
- tamanho e entrelinha dos tokens de tipografia;
- código das telas: imagem sem `alt`, `div` clicável sem teclado, botão só com ícone sem `aria-label`, `outline-none` sem foco alternativo, campo sem rótulo.

**Erro reprova** e deve ser corrigido. **Aviso** exige decisão: corrigir ou registrar a justificativa (ex.: texto desabilitado é isento de contraste pela WCAG). Se o projeto usa um Figma como fonte de verdade, não mude o token no código: avise a pessoa para ajustar no Figma e sincronizar.

## Parte B: o que exige julgamento (você revisa)
Marque cada item como ✓, ✗ ou n/a, e cite a evidência dos ✗.

**WCAG 2.2 AA (além do que a Parte A mede)**
- Tudo funciona só com teclado, na ordem visual; o foco é sempre visível e não fica escondido atrás de barras fixas (2.4.7, 2.4.11).
- Alvos de toque/clique com pelo menos 24×24 px, e 44×44 px nos principais no mobile (2.5.8).
- A informação não depende só de cor (ícone, texto ou forma junto) (1.4.1).
- Textos de erro dizem o que houve e como corrigir; rótulos ficam visíveis, sem depender de placeholder (3.3.1, 3.3.2).
- Zoom de 200% e reflow em 320 px sem perder conteúdo nem rolar nos dois eixos (1.4.4, 1.4.10).
- Movimento respeita `prefers-reduced-motion`; nada pisca mais de 3 vezes por segundo (2.3.1, 2.2.2).
- Ações por arrastar têm alternativa de toque simples (2.5.7). Ajuda e confirmação não pedem repetir dados já informados (3.2.6, 3.3.7).

**Gestalt**
- *Proximidade*: o espaço entre itens do mesmo grupo é menor que o espaço entre grupos.
- *Similaridade*: o que faz a mesma coisa tem a mesma aparência; o que é diferente parece diferente.
- *Continuidade e alinhamento*: bordas e grades alinhadas; leitura em linha clara.
- *Fechamento e região comum*: grupos delimitados por fundo ou borda só quando precisa separar; sem caixas dentro de caixas.
- *Figura e fundo*: um único ponto focal por tela; a ação principal destaca-se das secundárias.
- *Hierarquia*: no máximo 3 a 4 níveis tipográficos por tela, com contraste de tamanho/peso evidente.

**Heurísticas de usabilidade da NN/g (Nielsen)**
1. Visibilidade do estado do sistema (carregando, salvo, erro, vazio).
2. Correspondência com o mundo real (linguagem do usuário, não do sistema).
3. Controle e liberdade (desfazer, cancelar, voltar sem perda).
4. Consistência e padrões (mesma ação, mesmo nome e lugar em todas as telas; convenções da plataforma).
5. Prevenção de erros (confirmar o destrutivo, restringir entradas inválidas).
6. Reconhecer em vez de lembrar (opções visíveis, sem exigir memória).
7. Flexibilidade e eficiência (atalhos e padrões para quem usa muito).
8. Design estético e minimalista (nada que não sirva à tarefa).
9. Ajudar a reconhecer, diagnosticar e corrigir erros (mensagem clara e construtiva).
10. Ajuda e documentação (curta, buscável, no ponto de uso).
Para cada tela confira também: todos os estados existem (padrão, foco, ativo, desabilitado, carregando, vazio, erro).

## Parte C: governança do design system
- **Só tokens**: nenhuma cor, espaçamento, raio, sombra ou fonte solta no código. Valor novo vira token primeiro.
- **Átomos primeiro**: antes de criar um componente, procure um existente. Se faltar variante, **atualize o átomo**, não duplique.
- **Nomes**: segue a convenção do projeto (`categoria/papel`, camada do componente). Nome descreve função, não aparência (`text/secondary`, não `cinza-medio`).
- **Fonte de verdade**: token e componente mudam no Figma e no código juntos; divergência é bug, registre.
- **Documentação**: componente novo ou alterado tem entrada na Wiki (para que serve, variantes, estados, quando não usar).
- **Dívida**: o que não puder ser corrigido agora entra numa linha de base com justificativa; ela só pode diminuir.

## Como responder
1. Resultado da Parte A (cole o resumo do comando).
2. Parte B e C: só os ✗ e os pontos de dúvida, cada um com **arquivo/tela, regra quebrada, porquê importa, correção**.
3. Veredito: **Aprovado**, **Aprovado com ressalvas** (liste) ou **Reprovado** (liste o que bloqueia).
4. Pergunte antes de aplicar correções que mudem a aparência; aplique direto as mecânicas (alt, aria-label, rótulo).
