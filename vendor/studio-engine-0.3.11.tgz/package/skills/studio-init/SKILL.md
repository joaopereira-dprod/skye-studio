---
name: studio-init
description: Começa um projeto novo do zero com o Studio (protótipo mobile ou web, histórico de commits e PRs, wiki do design system, inspetor e chat com o agente). Cria o repositório no GitHub, instala o motor, escreve a configuração e as primeiras telas, e sobe o Studio. Use quando a pessoa disser que quer começar, criar ou iniciar um projeto, app ou produto novo com o Studio.
---

# studio-init: começar um projeto novo com o Studio

Quem fala é uma designer, não precisa abrir o terminal: responda no mesmo idioma em que ela escrever (português do Brasil se for ambíguo), curto e direto, e **explique o porquê de cada decisão** (é regra dela). Se ela trocar de idioma no meio da conversa, acompanhe. Faça uma pergunta de cada vez quando faltar informação.

## Onde está o motor

O motor do Studio é o pacote `studio-engine`. Descubra de onde instalá-lo antes de começar e guarde em `MOTOR`, nesta ordem:

1. **Um arquivo** `studio-engine-<versão>.tgz` (na pasta do projeto, em `vendor/`, ou no caminho que a pessoa indicar): `MOTOR=file:<caminho do arquivo>`. Instala sem GitHub nem login. `npm pack` dentro do pacote do motor gera esse arquivo.
2. **Um repositório do GitHub**: `MOTOR=github:<usuario>/<repositorio-do-motor>` (o npm usa o login do git se o repositório for privado).
3. **Uma pasta local do motor** (só para quem desenvolve o motor): `MOTOR=file:<caminho da pasta>`, com `package.json` existente.

Se não achar o arquivo e a pessoa não disser qual é a origem, **pergunte uma vez**. Não procure o motor por conta própria em outras pastas do computador (podem ter versões antigas). Sem motor nada do resto funciona: se não achar, pare e avise.

**Atalho:** se a pasta já veio do modelo do Studio (tem `.claude/skills/studio-init` e `studio-engine` no `package.json`), use a skill daquele modelo em vez deste roteiro.

## Passo 1: conversar antes de criar

Pergunte, e só avance com as respostas:

1. **Nome do projeto** (vira o nome do repositório e o logo; use letras minúsculas, números, `-` e `_`).
2. **Plataforma:** `mobile` (app para celular) ou `desktop` (produto web, tela larga). É uma escolha por projeto, não por tela.
3. **O que o produto faz e quem usa** (2 ou 3 frases; guia as primeiras telas).
4. **Repositório no GitHub:** privado (padrão) ou público, e o nome (padrão: o nome do projeto).

Antes de criar qualquer coisa, repita o resumo e peça um "pode criar". Criar repositório é uma ação externa, então **nunca crie sem esse sim**.

## Passo 2: conferir o ambiente

- `node -v` (precisa 18 ou mais novo) e `gh auth status` (precisa estar logado). Se o `gh` não estiver logado, peça que ela rode `gh auth login` e espere.
- Use **a pasta atual**: não crie outra pasta nem mude de diretório. Ela deve estar vazia ou ser a pasta do projeto; se já houver outro projeto nela, pare e pergunte.

## Passo 3: criar o projeto

Na pasta atual, nesta ordem:

1. `git init -b main`
2. `gh repo create <nome> --private --source=. --remote=origin` (use `--public` só se ela pediu público).
3. `npm init -y` e acrescente `"type": "module"` e `"private": true` no `package.json`.
4. `npm i react@18 react-dom@18` e `npm i -D --install-links "<origem>"`, em que a origem é o próprio `$MOTOR` (`file:...` ou `github:...`). Com `file:`, o `--install-links` copia o motor e instala as dependências dele; sem ele o npm só faz um atalho e o build falha fora da pasta do motor. O motor usa o React do projeto, então só existe uma cópia. Para atualizar o motor depois: `npm rm studio-engine` e instale de novo com o mesmo comando (o npm não recopia um arquivo ou pasta local de mesma versão, então suba a `version` do motor a cada mudança, e o Studio ficaria com o código antigo).
5. `.gitignore` com: `node_modules`, `dist`, `data/history.json`, `data/design.json`, `.env.local`, `.DS_Store`.
6. Scripts no `package.json`:
   ```json
   "dev": "studio dev",
   "build": "studio build",
   "check": "studio check",
   "history": "studio history",
   "studio": "studio history && studio build"
   ```
7. `studio.config.json`:
   ```json
   {
     "name": "<nome>",
     "platform": "<mobile|desktop>",
     "project": "studio.project.js",
     "tokens": "tokens/tokens.json",
     "components": "src/components",
     "watch": ["src", "tokens", "design"]
   }
   ```
8. `studio.project.js` (a ponte entre o motor e o projeto; o motor só importa daqui):
   ```js
   export { default as HISTORY } from './data/history.json';
   export { SCREENS, STUBS } from './src/screens/index.jsx';
   export const TOKENS = { version: '0', color: {}, font: {}, type: {}, space: {}, radius: {}, shadow: {} }; // sem tokens próprios ainda
   export const DESIGN = { audit: null, screens: {} };
   export const DOCS = [];
   export const FIGMA_FILE = null;
   export const TabBar = () => null;
   export const PortalContainer = ({ children }) => children;
   // opcionais: WIKI_PAGES = [{ id, label, Component, after? }] (páginas extras na Wiki; after: 'como' as põe logo após Como usar)
   ```
   Opcional: `studio.project.css` na raiz (CSS das telas do projeto, carregado depois do CSS do Studio) e `studio.i18n.json` (`{ "en": { "texto": "text" } }`, traduz o conteúdo do projeto para o modo EN).
9. `src/screens/index.jsx` com as primeiras telas, e uma por arquivo em `src/screens/`:
   ```jsx
   import { Home } from './Home.jsx';
   // group: categoria na lista lateral do Studio. figma: id do quadro no Figma, ou null.
   export const SCREENS = [
     { id: 'home', label: 'Início', group: 'App', Component: Home, figma: null },
   ];
   export const STUBS = []; // destinos citados que ainda não existem
   ```
   Cada tela é um componente React, estilizado com classes Tailwind (o Studio já as gera a partir de `src/`). O `id` pode ser qualquer um, e **a primeira tela da lista é a que abre**. A tela recebe as props `go(id)` (abre outra tela), `back(idDeReserva)` (volta), `notify(tipo, título, texto)` e `ctx`. Use `go` nos botões e links para o fluxo ficar navegável no Protótipo.

## Regras para as telas

- **Mobile:** a moldura é de 393 × 852 (iPhone). Desenhe para essa largura, com área de toque de pelo menos 44 px.
- **Desktop:** a moldura é um navegador de 1280 × 800 (barra de endereço de 40 px no topo; sobram 1280 × 760 para a tela). Desenhe para essa largura, com menu lateral ou topo e conteúdo, ocupando a altura toda (`h-full`). Não há barra de abas nem gesto de voltar: a navegação é por `go` e `back`.
- Se ela passar um link do Figma, tente ler. Se o acesso falhar, diga o motivo e ofereça: (a) ela pedir acesso ao dono do arquivo, ou (b) seguir sem o Figma, com ela descrevendo o fluxo. Não invente o conteúdo dos quadros que você não leu: diga que os textos são exemplos.
- Comece com **3 a 5 telas** do fluxo principal (as que ela descreveu no passo 1), simples, em escala de cinza, sem inventar marca ou cor. Espaçamentos em múltiplos de 4, contraste AA, texto real em português (não "lorem ipsum").
- Um projeto novo **não tem design system ainda**: a Wiki e a aba de tokens ficam vazias até existirem. Não crie tokens por conta própria; ofereça fazer isso depois, se ela quiser (Figma ou arquivo `tokens/tokens.json`).

## Passo 4: verificar e subir

0. **Governança:** copie a skill de revisão para o projeto, para valer em toda tela futura: `mkdir -p .claude/skills && cp -R node_modules/studio-engine/skills/design-governance .claude/skills/` (ela confere WCAG, Gestalt, heurísticas da NN/g e consistência do design system). Rode `npx studio governance` e corrija os erros antes de seguir.
1. `npm run check`. Se o build quebrar, leia o erro, corrija e rode de novo.
   **Só diga que está pronto depois de abrir o Studio no navegador** (o painel de navegador do app, se houver) e conferir que a primeira tela aparece e que o console não tem erro. HTTP 200 não prova nada: uma página em branco também responde 200.
2. `git add -A`, commit `feat: projeto inicial no Studio` e `git push -u origin main`. O repositório já foi autorizado no passo 1.
3. Rode `npm run dev` **em segundo plano** e diga a ela para abrir http://localhost:5173 (o Studio recarrega sozinho ao salvar arquivos). Se a porta estiver ocupada, use `PORT=5174`.
4. Conte o que foi criado (repositório, telas) e o que **não** foi verificado, sem rodeio.

## Passo 5: publicar como artefato (opcional, pergunte antes)

Ao terminar o passo 4, ofereça: "Quer que eu publique o Studio como artefato aqui no Claude, para você ver e testar pelo navegador ou pelo tablet?" Só publique com o sim dela.

1. Rode `npm run studio` (gera `dist/index.html`, um arquivo único).
2. Publique `dist/index.html` com a ferramenta de artefatos. Depois de publicar, abra o artefato e confira que a tela aparece antes de dar o link; se não conseguir abrir, diga que não verificou (Artifact). Título: `<nome> Studio`. O artefato nasce privado: não compartilhe nada por conta própria.
3. Para mudanças depois, republique **o mesmo artefato** (passe a `url` dele), em vez de criar outro. Se ela quiser aprovar antes, publique primeiro numa **prévia** (outro artefato, título `<nome> Studio · prévia`) e só atualize o oficial depois do "pode subir".
4. Diga a ela o que muda no artefato: a barra de chat só mostra um aviso (o agente roda na máquina dela, via `npm run dev`), o conteúdo é o da hora da publicação e não atualiza sozinho, e os comentários por clique funcionam.

## O que o Studio oferece depois

- **Protótipo:** navegar pelas telas, **Modo dev** (clicar num elemento mostra código, medidas e tokens), comentar numa área.
- **Histórico:** commits e descrições de PR, para voltar a uma versão.
- **Wiki:** tokens e componentes, quando o projeto tiver design system.
- **Barra de chat** (Ctrl ou Cmd + K): pede mudanças ao agente sem sair do Studio. Ele edita arquivos, sem terminal.

## Não faça

- Criar repositório, publicar ou dar push sem o "pode criar" do passo 1.
- Pedir ou digitar senhas e chaves. Se faltar login, ela faz o login.
- Mexer em arquivos fora da pasta do projeto, com a exceção da leitura do motor (`$MOTOR`, quando for uma pasta local de desenvolvimento).
