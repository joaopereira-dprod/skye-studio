// Configuração compartilhada pelos scripts do motor. O projeto que usa o Studio é a pasta onde o comando roda (cwd);
// as escolhas dele ficam em studio.config.json, e o que falta cai nos padrões abaixo.
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const engine = join(dirname(fileURLToPath(import.meta.url)), '..');
export const root = process.cwd();

const DEFAULTS = {
  name: 'studio',
  platform: 'mobile', // mobile | desktop: decide a moldura do Protótipo
  project: 'studio.project.js', // ponte entre o motor e o código do projeto (telas, componentes, tokens)
  tokens: 'tokens/tokens.json',
  components: 'src/components',
  watch: ['src', 'tokens', 'design'],
  css: 'studio.project.css', // opcional: CSS das telas e componentes do projeto, carregado depois do CSS do Studio
  i18n: 'studio.i18n.json', // opcional: { "en": { "texto em português": "English text" } } traduz o conteúdo do projeto (descrições de componentes, tokens, telas)
  scripts: { design: null }, // passos opcionais do projeto antes do build (ex.: scripts/gen-design.mjs)
};

const file = join(root, 'studio.config.json');
const user = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : {};
export const config = { ...DEFAULTS, ...user, scripts: { ...DEFAULTS.scripts, ...user.scripts } };
if (!['mobile', 'desktop'].includes(config.platform)) throw new Error(`studio.config.json: platform "${config.platform}" inválida (use mobile ou desktop)`);
