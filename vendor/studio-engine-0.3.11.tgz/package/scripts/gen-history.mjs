// Gera data/history.json a partir do `git log`: commits, arquivos alterados,
// linhas adicionadas/removidas, tipo (feat, fix...), diff de tokens, componentes novos e snapshot de tokens por commit.
// Também inclui as alterações ainda não commitadas (working tree).
// Uso: node scripts/gen-history.mjs [--limit 30]
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { root, engine, config } from './config.mjs';

const git = (...a) => execFileSync('git', a, { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
const tryGit = (...a) => { try { return git(...a); } catch { return null; } };
const limitIdx = process.argv.indexOf('--limit');
const limit = limitIdx > -1 ? process.argv[limitIdx + 1] : '30';

const parseTokens = (txt) => { try { return JSON.parse(txt); } catch { return null; } };
// Componentes = pastas da pasta de componentes do projeto (config.components, padrão src/components)
const compsAt = (ref) => (tryGit('ls-tree', '-d', '--name-only', ref, `${config.components.replace(/\/+$/, '')}/`) || '').split('\n').filter(Boolean).map((p) => p.split('/').pop());
const compsNow = () => (existsSync(join(root, config.components)) ? readdirSync(join(root, config.components), { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name) : []);

// Aceita também tokens no formato { light, dark } (commits antigos de projetos que mudaram de formato)
const val = (c) => c.value ?? c.light;
function diffTokens(prev, next) {
  const a = (prev && prev.color) || {}, b = (next && next.color) || {};
  const out = { added: [], changed: [], removed: [] };
  for (const k of Object.keys(b)) {
    if (!a[k]) out.added.push({ name: k, to: val(b[k]) });
    else if (val(a[k]) !== val(b[k])) out.changed.push({ name: k, from: val(a[k]), to: val(b[k]) });
  }
  for (const k of Object.keys(a)) if (!b[k]) out.removed.push({ name: k, from: val(a[k]) });
  return out;
}
const snap = (t) => (t && Object.values(t.color)[0]?.value ? { color: t.color } : null);
const fileAt = (ref, p) => tryGit('show', `${ref}:${p}`);

// -m --first-parent: num merge mostra o que o PR trouxe, em vez de uma lista vazia
const stat = (sha) => {
  const rows = git('show', '-m', '--first-parent', '--numstat', '--format=', sha).trim().split('\n').filter(Boolean).map((l) => l.split('\t'));
  return rows.reduce((t, [a, d]) => ({ add: t.add + (Number(a) || 0), del: t.del + (Number(d) || 0) }), { add: 0, del: 0 }); // binários vêm como "-"
};
// Tipo no padrão Conventional Commits; "Merge pull request" vira merge
const typeOf = (msg) => (/^Merge /.test(msg) ? 'merge' : (msg.match(/^(feat|fix|refactor|chore|docs|style|test|perf|ci|build)(\(.*?\))?!?:/) || [])[1] || 'outro');
// https://github.com/dono/repo, a partir do remote origin (aceita ssh e https)
const repo = (tryGit('remote', 'get-url', 'origin') || '').trim().replace(/^git@([^:]+):/, 'https://$1/').replace(/\.git$/, '') || null;

const branch = (tryGit('rev-parse', '--abbrev-ref', 'HEAD') || 'main').trim();
const log = (tryGit('log', `--max-count=${limit}`, '--format=%H|%h|%an|%aI|%s') || '').trim().split('\n').filter(Boolean);
const commits = log.map((line) => {
  const [sha, short, author, date, ...msg] = line.split('|');
  const files = git('show', '-m', '--first-parent', '--name-status', '--format=', sha).trim().split('\n').filter(Boolean)
    .map((l) => { const [s, ...p] = l.split('\t'); return { s: s[0], p: p.join(' → ') }; });
  const tok = parseTokens(fileAt(sha, config.tokens));
  const prevTok = parseTokens(fileAt(`${sha}^`, config.tokens));
  const before = compsAt(`${sha}^`);
  const added = compsAt(sha).filter((n) => !before.includes(n) && n !== 'Icon');
  const m = msg.join('|');
  return { sha, short, msg: m, type: typeOf(m), ...stat(sha), author, date, status: 'commit', files, tokens: diffTokens(prevTok, tok), components: { added }, snapshot: snap(tok) };
});

const porcelain = (tryGit('status', '--porcelain', '--untracked-files=all') || '').trim().split('\n').filter(Boolean);
if (porcelain.length) {
  const files = porcelain.map((l) => ({ s: l.startsWith('??') || l[0] === 'A' ? 'A' : l.includes('D') ? 'D' : 'M', p: l.slice(3) }))
    .filter((f) => !f.p.startsWith('dist/') || true);
  const cur = parseTokens(existsSync(join(root, config.tokens)) ? readFileSync(join(root, config.tokens), 'utf8') : null);
  const head = parseTokens(fileAt('HEAD', config.tokens));
  const headComps = compsAt('HEAD');
  const nowComps = compsNow().filter((n) => !headComps.includes(n) && n !== 'Icon');
  const wt = (tryGit('diff', '--numstat', 'HEAD') || '').trim().split('\n').filter(Boolean).map((l) => l.split('\t')).reduce((t, [a, d]) => ({ add: t.add + (Number(a) || 0), del: t.del + (Number(d) || 0) }), { add: 0, del: 0 });
  commits.unshift({ sha: '', short: 'working', msg: 'Alterações ainda não commitadas', type: 'wip', ...wt, author: (tryGit('config', 'user.name') || 'local').trim(), date: new Date().toISOString(), status: 'working', files, tokens: diffTokens(head, cur), components: { added: nowComps }, snapshot: snap(cur) });
}

mkdirSync(join(root, 'data'), { recursive: true });
writeFileSync(join(root, 'data/history.json'), JSON.stringify({ branch, repo, generatedAt: new Date().toISOString(), commits }, null, 2) + '\n');
console.log(`history.json: ${commits.length} entradas na branch ${branch}`);
