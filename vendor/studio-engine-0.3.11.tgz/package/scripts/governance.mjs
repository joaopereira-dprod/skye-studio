// Verificação automática de acessibilidade e governança do projeto (comando: studio governance).
// Cobre o que dá para medir sem olho humano: contraste WCAG 2.2 dos tokens de cor, tamanho de texto e problemas
// comuns no código das telas. O que depende de julgamento (Gestalt, heurísticas da NN/g, fluxo) fica na skill design-governance.
// Por que existe: regra só em texto é esquecida; o número que reprova o build não é.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { extname, join, relative } from 'node:path';
import { config, root } from './config.mjs';

const errors = [];
const warns = [];
const ok = [];

// ---------- Contraste (WCAG 1.4.3 texto 4.5:1, 1.4.11 elementos de interface 3:1) ----------
const lum = (hex) => {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
    .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const ratio = (a, b) => {
  const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p);
  return (x + 0.05) / (y + 0.05);
};
const HEX = /^#[0-9a-f]{6}$/i;

const tokensFile = join(root, config.tokens);
let tokens = null;
if (existsSync(tokensFile)) tokens = JSON.parse(readFileSync(tokensFile, 'utf8'));
else warns.push(`tokens: ${config.tokens} não existe, contraste e tipografia não foram verificados`);

if (tokens) {
  const color = Object.fromEntries(Object.entries(tokens.color || {}).map(([k, v]) => [k, v?.value ?? v]));
  const names = Object.keys(color);
  const has = (n) => names.includes(n) && HEX.test(color[n]);
  const grounds = ['background/default', 'surface/default', 'background/elevated'].filter(has);
  // Pares próprios do projeto (studio.config.json → governance.contrast: [["text/primary","background/default",4.5]]) ou os padrões por convenção de nome.
  let pairs = config.governance?.contrast;
  if (!pairs) {
    pairs = [];
    for (const n of names.filter((n) => n.startsWith('text/') && !n.endsWith('/disabled') && n !== 'text/inverse')) for (const g of grounds) pairs.push([n, g, 4.5]);
    if (has('text/inverse') && has('surface/inverse')) pairs.push(['text/inverse', 'surface/inverse', 4.5]);
    for (const n of names.filter((n) => n === 'border/focus' || n.startsWith('icon/') && !n.endsWith('/muted') && !n.endsWith('/inverse'))) for (const g of grounds) pairs.push([n, g, 3]);
  }
  let checked = 0;
  for (const [fg, bg, min = 4.5] of pairs) {
    if (!has(fg) || !has(bg)) continue;
    checked++;
    const r = ratio(color[fg], color[bg]);
    if (r < min) errors.push(`contraste ${r.toFixed(2)}:1 em ${fg} sobre ${bg} (mínimo ${min}:1, WCAG 2.2 ${min === 3 ? '1.4.11' : '1.4.3'})`);
  }
  if (checked) ok.push(`contraste: ${checked} pares de cor conferidos`);
  else warns.push('contraste: nenhum par encontrado. Use tokens text/*, background/default, surface/default ou declare governance.contrast em studio.config.json');

  // ---------- Tipografia ----------
  const type = tokens.type || {};
  for (const [name, t] of Object.entries(type)) {
    if (t.size < 12) warns.push(`tipografia: ${name} tem ${t.size}px (abaixo de 12px é difícil de ler; NN/g recomenda corpo de texto a partir de 16px na web e 14px no mobile)`);
    if (/^body/.test(name) && t.line && t.line / t.size < 1.4) warns.push(`tipografia: ${name} com entrelinha ${(t.line / t.size).toFixed(2)}× (WCAG 1.4.12 pede suportar 1,5×; abaixo de 1,4× cansa a leitura)`);
  }
}

// ---------- Código das telas ----------
const SCAN = [...new Set(['src', config.components])].map((d) => join(root, d)).filter(existsSync);
const walk = (dir, out = []) => {
  for (const n of readdirSync(dir)) {
    const p = join(dir, n);
    if (statSync(p).isDirectory()) { if (n !== 'node_modules' && n !== 'assets') walk(p, out); } else if (['.jsx', '.tsx'].includes(extname(n))) out.push(p);
  }
  return out;
};
const files = [...new Set(SCAN.flatMap((d) => walk(d)))];
const rules = [
  [/<img\b(?![^>]*\balt=)[^>]*>/g, 'imagem sem alt (WCAG 1.1.1)'],
  [/<(div|span)\b[^>]*\bonClick=(?![^>]*\brole=)[^>]*>/g, 'div/span clicável sem role e teclado (WCAG 2.1.1, 4.1.2). Use <button>'],
  [/<(button)\b[^>]*>\s*<(svg|Icon\w*)\b[^>]*\/?>\s*(<\/\2>)?\s*<\/button>/g, 'botão só com ícone sem aria-label (WCAG 4.1.2)'],
  [/\boutline-none\b(?![^"'`]*focus)/g, 'outline-none sem estilo de foco alternativo (WCAG 2.4.7)'],
  [/<input\b(?![^>]*\b(aria-label|aria-labelledby|id)=)[^>]*>/g, 'campo sem rótulo associado (WCAG 1.3.1, 3.3.2)'],
];
let hits = 0;
for (const f of files) {
  const src = readFileSync(f, 'utf8');
  for (const [re, msg] of rules) for (const m of src.matchAll(re)) {
    hits++;
    const line = src.slice(0, m.index).split('\n').length;
    warns.push(`${relative(root, f)}:${line}  ${msg}`);
  }
}
if (!hits) ok.push(`código: ${files.length} arquivos sem os problemas comuns de acessibilidade`);

// ---------- Relatório ----------
for (const m of ok) console.log(`✓ ${m}`);
for (const m of warns) console.log(`! ${m}`);
for (const m of errors) console.log(`✗ ${m}`);
console.log(`\n${errors.length} erro(s), ${warns.length} aviso(s). Erros reprovam; avisos pedem decisão (corrigir ou justificar).`);
console.log('Lembrete: isto cobre só o que se mede. Gestalt, heurísticas da NN/g e fluxo pedem a skill design-governance.');
process.exit(errors.length ? 1 : 0);
