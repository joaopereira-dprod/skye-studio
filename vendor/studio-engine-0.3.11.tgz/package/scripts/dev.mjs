// Servidor local do Studio, fora do Claude: npm run dev  ->  http://localhost:5173
// Gera o histórico e os dados de design, constrói com a chave do Google Maps (.env.local, se existir),
// serve o dist/index.html e recarrega a página sozinho quando algo em src/, tokens/ ou design/ muda. Sem dependências.
// Também liga a barra de chat ao Claude Code da sua máquina (claude -p) pelo endpoint /__agent: veja a seção "Agente local" no CONTRIBUTING.md.
import http from 'node:http';
import { spawn, spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, watch, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { root, engine, config } from './config.mjs';

// Projeto novo: o agente precisa saber o contrato com o Studio, que não está em nenhum arquivo da pasta
const NEW_PROJECT = existsSync(join(root, config.project)) ? '' : ' Esta pasta ainda não é um projeto do Studio. Para criar: escreva studio.config.json ({ "name", "platform": "mobile" ou "desktop" }) e studio.project.js, que exporta HISTORY (import de ./data/history.json), TOKENS, DESIGN, SCREENS (lista de { id, label, group, Component }), STUBS, DOCS, FIGMA_FILE, TabBar e PortalContainer; as telas ficam em src/screens. O modelo está em packages/studio/default/studio.project.js. Pergunte o que faltar antes de criar.';
const PORT = Number(process.env.PORT) || 5173;
const run = (script, ...args) => spawnSync('node', [script, ...args], { cwd: root, stdio: 'inherit' }).status === 0;

// ---- Agente local -------------------------------------------------------------------------------------------------
// Um clique na barra roda o Claude Code desta máquina dentro do repositório. Como isso mexe nos seus arquivos, o endpoint só aceita a
// própria página do Studio: o servidor escuta só em 127.0.0.1, confere Host e Origin e exige um token aleatório que muda a cada
// npm run dev e só vai embutido na página servida por ele. Outro site aberto no navegador não consegue chamá-lo.
//   STUDIO_AGENT_MODE=edit (padrão: lê e edita arquivos, sem terminal) | read (só lê e responde)
//   STUDIO_AGENT_MAX_USD=1   teto de gasto por comando (opcional; sem ele não há teto)
//   STUDIO_CLAUDE_BIN=...    outro executável no lugar do claude (usado nos testes)
// Não há modo sem permissões: o que precisar de terminal (git, npm) o agente pede e você roda, ou usa o claude direto no terminal.
const TOKEN = randomUUID();
const MODE = process.env.STUDIO_AGENT_MODE === 'read' ? 'read' : 'edit';
const PERMISSION = { edit: 'acceptEdits', read: 'plan' }[MODE];
const MAX_USD = Number(process.env.STUDIO_AGENT_MAX_USD) > 0 ? String(Number(process.env.STUDIO_AGENT_MAX_USD)) : null;
const CLAUDE_BIN = process.env.STUDIO_CLAUDE_BIN || 'claude';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
let agentBusy = false;

const trusted = (req) => {
  const hosts = [`localhost:${PORT}`, `127.0.0.1:${PORT}`];
  const origin = req.headers.origin;
  return hosts.includes(req.headers.host) && (!origin || hosts.some((h) => origin === `http://${h}`)) && req.headers['x-studio-token'] === TOKEN;
};
const json = (res, code, body) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
const brief = (input = {}) => String(input.file_path || input.command || input.pattern || input.path || input.description || input.url || '').replace(/\s+/g, ' ').slice(0, 90);

/** Uma linha do stream-json do claude vira zero ou mais eventos simples para a página: delta, tool, done. */
function translate(line, state) {
  let j;
  try { j = JSON.parse(line); } catch { return []; }
  if (j.type === 'stream_event') {
    const e = j.event || {};
    if (e.type === 'message_start' && state.started) return [{ t: 'delta', text: '\n\n' }]; // nova mensagem depois de uma ferramenta
    if (e.type === 'message_start') { state.started = true; return []; }
    if (e.type === 'content_block_delta' && e.delta?.type === 'text_delta') { state.streamed = true; return [{ t: 'delta', text: e.delta.text }]; }
    return [];
  }
  if (j.type === 'assistant') {
    const out = [];
    for (const b of j.message?.content || []) {
      if (b.type === 'tool_use') out.push({ t: 'tool', name: b.name, detail: brief(b.input) });
      if (b.type === 'text' && !state.streamed) { out.push({ t: 'delta', text: (state.any ? '\n\n' : '') + b.text }); state.any = true; }
    }
    state.streamed = false;
    return out;
  }
  if (j.type === 'result') return [{ t: 'done', text: j.result || '', error: !!j.is_error, cost: j.total_cost_usd ?? null, session: j.session_id || null }];
  return [];
}

function runAgent(req, res) {
  let body = '';
  req.on('data', (c) => { body += c; if (body.length > 64_000) req.destroy(); });
  req.on('end', () => {
    let m;
    try { m = JSON.parse(body); } catch { return json(res, 400, { error: 'JSON inválido' }); }
    const prompt = typeof m.prompt === 'string' ? m.prompt.trim() : '';
    if (!prompt || !UUID.test(m.session || '')) return json(res, 400, { error: 'prompt e session são obrigatórios' });
    if (agentBusy) return json(res, 409, { error: 'O agente já está rodando outro comando.' });
    const ctx = typeof m.context === 'string' ? m.context.replace(/[^\p{L}\p{N} ·-]/gu, '').slice(0, 40) : '';
    const system = `Você foi chamado pela barra de chat do Studio de ${config.name}${ctx ? ` (aba atual: ${ctx})` : ''}. Quem fala é uma designer, não precisa abrir o terminal: responda no mesmo idioma em que a pessoa escreveu a mensagem (português do Brasil se a mensagem for ambígua ou só um comando), curto e direto, e siga as regras do projeto.${NEW_PROJECT}`;
    const args = ['-p', '--output-format', 'stream-json', '--verbose', '--include-partial-messages', '--permission-mode', PERMISSION,
      ...(m.first ? ['--session-id', m.session] : ['--resume', m.session]), '--append-system-prompt', system, ...(MAX_USD ? ['--max-budget-usd', MAX_USD] : [])];
    agentBusy = true;
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store' });
    const child = spawn(CLAUDE_BIN, args, { cwd: root, stdio: ['pipe', 'pipe', 'pipe'] });
    const send = (ev) => { if (!res.writableEnded) res.write(JSON.stringify(ev) + '\n'); };
    const state = {};
    let buf = '', err = '', finished = false;
    child.stdin.end(prompt); // o prompt vai por stdin, nunca como argumento: um texto começando com "-" não vira opção
    child.stdout.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        translate(line, state).forEach((ev) => { if (ev.t === 'done') finished = true; send(ev); });
      }
    });
    child.stderr.on('data', (d) => { err = (err + d).slice(-2000); });
    child.on('error', (e) => { send({ t: 'done', text: e.code === 'ENOENT' ? `Não achei o comando ${CLAUDE_BIN} nesta máquina.` : e.message, error: true }); finished = true; });
    child.on('close', (code) => {
      if (!finished) send({ t: 'done', text: err.trim() || `O agente terminou sem resposta (código ${code}).`, error: true });
      agentBusy = false;
      res.end();
    });
    res.on('close', () => { if (!child.killed && child.exitCode === null) child.kill('SIGTERM'); }); // parar na página interrompe o agente
  });
}

// ---- Comentários --------------------------------------------------------------------------------------------------
// Os comentários do Protótipo ficam em .studio/comments.json, na pasta do projeto: sobrevivem a limpar o navegador, vão para o git se a
// pessoa quiser e o agente consegue ler o arquivo. A página lê e grava a lista inteira (GET / PUT), com o mesmo token do agente.
// A lista é validada aqui: o arquivo só guarda os campos conhecidos, com tamanho limitado.
const COMMENTS_FILE = join(root, '.studio/comments.json');
const str = (v, n) => (typeof v === 'string' ? v.slice(0, n) : '');
const num = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : 0);
const cleanComments = (list) => (Array.isArray(list) ? list.slice(0, 500) : []).map((c) => ({
  id: str(c?.id, 64), screen: str(c?.screen, 80), x: num(c?.x), y: num(c?.y), target: str(c?.target, 120),
  text: str(c?.text, 2000), created: str(c?.created, 40), resolved: c?.resolved === true,
})).filter((c) => c.id && c.text.trim());
function handleComments(req, res) {
  if (req.method === 'GET') {
    let comments = [];
    try { comments = cleanComments(JSON.parse(readFileSync(COMMENTS_FILE, 'utf8')).comments); } catch { /* sem arquivo ainda, ou ilegível */ }
    return json(res, 200, { comments });
  }
  if (req.method !== 'PUT') return json(res, 405, { error: 'método não permitido' });
  let body = '';
  req.on('data', (c) => { body += c; if (body.length > 512_000) req.destroy(); });
  req.on('end', () => {
    let m;
    try { m = JSON.parse(body); } catch { return json(res, 400, { error: 'JSON inválido' }); }
    const comments = cleanComments(m.comments);
    try {
      mkdirSync(join(root, '.studio'), { recursive: true });
      writeFileSync(`${COMMENTS_FILE}.tmp`, JSON.stringify({ comments }, null, 2) + '\n');
      renameSync(`${COMMENTS_FILE}.tmp`, COMMENTS_FILE); // troca de uma vez: um erro no meio não deixa o arquivo pela metade
    } catch (e) { return json(res, 500, { error: e.message }); }
    json(res, 200, { ok: true, comments });
  });
}

const clients = new Set();
let timer, building = false, again = false, designDirty = true;

function rebuild() {
  if (building) { again = true; return; }
  building = true;
  if (designDirty) { config.scripts.design && run(join(root, config.scripts.design)); designDirty = false; }
  const ok = run(join(engine, 'scripts/build.mjs'), '--with-maps');
  building = false;
  if (ok) clients.forEach((c) => c.write('data: reload\n\n'));
  if (again) { again = false; rebuild(); }
}

run(join(engine, 'scripts/gen-history.mjs'));
rebuild();
// Pastas do projeto (e o motor) a vigiar. Num projeto novo elas ainda não existem: a raiz também é vigiada (sem descer nas pastas),
// e cada pasta passa a ser vigiada assim que aparece, por exemplo quando o agente cria src/.
const watched = new Set();
const trigger = (dir) => (_, f) => {
  if (!f || /\.(DS_Store)$|tokens\.css$/.test(f)) return; // tokens.css é gerado pelo próprio build: evita laço
  if (dir === 'design') designDirty = true;
  clearTimeout(timer);
  timer = setTimeout(() => { watchDirs(); rebuild(); }, 250);
};
function watchDirs() {
  for (const dir of [...config.watch, engine]) {
    const abs = dir === engine ? engine : join(root, dir);
    if (watched.has(abs) || !existsSync(abs)) continue;
    watched.add(abs);
    watch(abs, { recursive: true }, trigger(dir));
  }
}
watchDirs();
watch(root, (_, f) => { if (f && /^(studio\.config\.json|studio\.project\.(js|css)|studio\.i18n\.json|tailwind\.config\.mjs)$/.test(f)) trigger('root')(_, f); else if (f && config.watch.includes(f)) watchDirs(); });

const LIVE = '<script>new EventSource("/__reload").onmessage=function(){location.reload()}</script>';
const AGENT_CFG = `<script>window.__STUDIO_AGENT__=${JSON.stringify({ token: TOKEN })}</script>`; // no início: tem de existir antes do app carregar
http.createServer((req, res) => {
  if (req.url.startsWith('/__agent')) {
    if (!trusted(req)) return json(res, 403, { error: 'Só a página do Studio pode falar com o agente.' });
    if (req.method === 'GET' && req.url === '/__agent/status') return json(res, 200, { ok: true, mode: MODE, busy: agentBusy });
    if (req.method === 'POST' && req.url === '/__agent') return runAgent(req, res);
    return json(res, 404, { error: 'não encontrado' });
  }
  if (req.url === '/__comments') {
    if (!trusted(req)) return json(res, 403, { error: 'Só a página do Studio pode ler os comentários.' });
    return handleComments(req, res);
  }
  if (req.url === '/__reload') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write('\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }
  const file = join(root, 'dist/index.html');
  if (!existsSync(file)) { res.writeHead(503); res.end('Construindo… recarregue em instantes.'); return; }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  const html = readFileSync(file, 'utf8');
  res.end(AGENT_CFG + (html.includes('</body>') ? html.replace('</body>', `${LIVE}</body>`) : html + LIVE)); // o shell não fecha o body: o recarregamento vai ao fim
}).listen(PORT, '127.0.0.1', () => {
  const key = existsSync(join(root, '.env.local')) && /GOOGLE_MAPS_API_KEY=\S+/.test(readFileSync(join(root, '.env.local'), 'utf8'));
  console.log(`\nStudio em http://localhost:${PORT}  (${key ? 'com Google Maps' : 'sem chave do Google Maps: mapa de imagem'})\nAgente local: ${MODE === 'read' ? 'só lê e responde' : 'lê e edita arquivos, sem terminal'}${MAX_USD ? `, teto de US$ ${MAX_USD} por comando` : ', sem teto de gasto'}.\nCtrl+C para parar.`);
});
