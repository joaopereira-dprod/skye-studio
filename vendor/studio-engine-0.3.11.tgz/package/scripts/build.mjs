// Gera tokens/tokens.css e dist/index.html (artefato único) a partir de:
//   tokens/tokens.json + data/history.json + src/**/*.jsx (React, empacotado com esbuild) + Tailwind
// Uso: node scripts/build.mjs [--check]   (--check falha se o build quebrar ou se tokens.css estiver desatualizado)
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { root, engine, config } from './config.mjs';
import { build } from 'esbuild';
import postcss from 'postcss';
import tailwind from 'tailwindcss';
// Sem projeto (ou sem um desses arquivos), o motor usa os próprios padrões em packages/studio/default
const pick = (rel, fallback) => (existsSync(join(root, rel)) ? join(root, rel) : join(engine, 'default', fallback));
const projectFile = pick(config.project, 'studio.project.js');
// Exports opcionais do projeto ganham um padrão aqui, para um projeto antigo não quebrar quando o motor ganha um nome novo.
const OPTIONAL = { WIKI_PAGES: '[]' }; // páginas extras da Wiki: [{ id, label, Component }]
const projectSrc = readFileSync(projectFile, 'utf8');
const missing = Object.entries(OPTIONAL).filter(([name]) => !new RegExp(`\\b${name}\\b`).test(projectSrc));
mkdirSync(join(root, 'dist'), { recursive: true });
const projectEntry = join(root, 'dist/.studio-project.js');
writeFileSync(projectEntry, `export * from ${JSON.stringify(projectFile)};\n${missing.map(([n, v]) => `export const ${n} = ${v};`).join('\n')}\n`);
const tokensFile = pick(config.tokens, 'tokens.json');
const { default: userTailwind } = await import(pathToFileURL(pick('tailwind.config.mjs', 'tailwind.config.mjs')).href);
const engineSrc = join(engine, 'src/**/*.{js,jsx}'); // o Tailwind precisa ver as classes do próprio Studio
const tailwindConfig = { ...userTailwind, content: [...new Set([...[].concat(userTailwind.content), engineSrc])] };

const read = (p) => readFileSync(join(root, p), 'utf8');
const tokens = JSON.parse(readFileSync(tokensFile, 'utf8'));
const slug = (k) => k.replace(/\//g, '-');

// hex -> "H S% L%" (canais HSL, convenção shadcn usada pelo atoms.jsx)
const hsl = (hex) => {
  const n = parseInt(hex.slice(1), 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => v / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
  let h = 0, sat = 0;
  if (d) {
    sat = d / (1 - Math.abs(2 * l - 1));
    h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = (h * 60 + 360) % 360;
  }
  return `${Math.round(h)} ${Math.round(sat * 100)}% ${Math.round(l * 100)}%`;
};

// ---------- tokens.css ----------
const vars = [
  ...Object.entries(tokens.color).map(([k, v]) => `--c-${slug(k)}:${v.value}`),
  ...Object.entries(tokens.font).map(([k, v]) => `--f-${k}:${v.value}`),
  ...Object.entries(tokens.space).map(([k, v]) => `--s-${k}:${v}px`),
  ...Object.entries(tokens.radius).map(([k, v]) => `--r-${k}:${v}px`),
  ...Object.entries(tokens.shadow).map(([k, v]) => `--sh-${k}:${v.value}`),
].join(';');
const shadcn = Object.entries(tokens.shadcn)
  .filter(([k]) => !k.startsWith('$'))
  .map(([k, ref]) => {
    if (!tokens.color[ref]) throw new Error(`tokens.shadcn.${k} aponta para "${ref}", que não existe em tokens.color`);
    return `--${k}:${hsl(tokens.color[ref].value)}`;
  })
  .join(';');
const elevation = `--shadow-elevation-1:${tokens.shadow['100'].value};--shadow-elevation-2:${tokens.shadow['300'].value}`;
const typeClasses = Object.entries(tokens.type)
  .map(([k, t]) => `.t-${slug(k)}{font-family:var(--f-${t.font});font-size:${t.size}px;line-height:${t.line}px;font-weight:${t.weight};letter-spacing:${+(t.tracking / 100).toFixed(4)}em}`) // tracking do Figma é em %
  .join('\n');
const tokensCss = `/* GERADO por scripts/build.mjs. Não edite: altere tokens/tokens.json */\n:root{${vars};${shadcn};${elevation}}\n${typeClasses}\n`;

// O chrome do Studio tem paleta própria (src/theme.css, no <html>). O que mostra o projeto (moldura do Protótipo e exemplos da Wiki) volta
// aos tokens do projeto (inclusive a cor do texto herdado): esta regra os redeclara nesses elementos, depois do :root do projeto, e eles ficam sempre claros, como o produto real.
const PROJECT_SCOPE = '.phone,.preview';
const scopeCss = `${PROJECT_SCOPE}{color-scheme:light;color:var(--c-text-primary);${vars};${shadcn};${elevation}}\n`;

// CSS do projeto (opcional): vem depois do CSS do Studio, para o projeto poder ajustar o que quiser
const projectCss = existsSync(join(root, config.css)) ? read(config.css) : '';

// Traduções do conteúdo do projeto (opcional): studio.i18n.json -> { en: { "texto em português": "English text" } }. Entra no HTML como dado.
let projectI18n = {};
if (existsSync(join(root, config.i18n))) {
  try { projectI18n = JSON.parse(read(config.i18n)); } catch (e) { throw new Error(`${config.i18n}: JSON inválido (${e.message})`); }
}

const isCheck = process.argv.includes('--check');
const ownTokens = existsSync(join(root, config.tokens)); // sem tokens próprios, os do motor só vestem a interface e não viram arquivo no projeto
if (ownTokens) mkdirSync(join(root, 'tokens'), { recursive: true });
mkdirSync(join(root, 'dist'), { recursive: true });
if (ownTokens && !isCheck) writeFileSync(join(root, 'tokens/tokens.css'), tokensCss);

// ---------- Tailwind (só as classes usadas em src/**) ----------
const tw = await postcss([tailwind(tailwindConfig)]).process('@tailwind base;\n@tailwind components;\n@tailwind utilities;', { from: undefined });

// ---------- app (JSX → JS/CSS) ----------
if (!existsSync(join(root, 'data/history.json'))) {
  mkdirSync(join(root, 'data'), { recursive: true });
  writeFileSync(join(root, 'data/history.json'), JSON.stringify({ branch: 'main', commits: [] }));
}
if (!existsSync(join(root, 'data/design.json'))) writeFileSync(join(root, 'data/design.json'), JSON.stringify({ audit: null, screens: {} }));
// Chave do Google Maps: só entra no HTML com --with-maps (npm run dev), lida de .env.local (fora do git).
// O npm run studio e os artefatos publicados nunca a levam: o Studio cai no mapa de imagem.
const env = {};
if (process.argv.includes('--with-maps') && existsSync(join(root, '.env.local'))) {
  for (const l of read('.env.local').split('\n')) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
// Um React só: o do projeto. Com o motor instalado por link, ele acharia outra cópia ao lado dele, e dois Reacts quebram os hooks.
const fromProject = createRequire(join(root, 'package.json'));
const reactAlias = {};
for (const pkg of ['react', 'react-dom']) {
  try { reactAlias[pkg] = dirname(fromProject.resolve(`${pkg}/package.json`)); } catch { /* projeto sem React: vale o do motor */ }
}
const result = await build({
  entryPoints: [join(engine, 'src/main.jsx')],
  alias: { ...reactAlias, 'studio-project': projectEntry, '@studio/history': join(root, 'data/history.json') }, nodePaths: [join(root, 'node_modules')],
  bundle: true, write: false, outdir: join(root, 'out'), format: 'iife', minify: true, keepNames: true,
  jsx: 'automatic', target: 'es2020', logLevel: 'warning',
  loader: { '.svg': 'dataurl', '.gif': 'dataurl', '.jpg': 'dataurl' }, // ícones e ilustrações baixados do Figma entram no HTML único
  define: {
    'process.env.NODE_ENV': '"production"',
    __STUDIO_NAME__: JSON.stringify(config.name),
    __STUDIO_VERSION__: JSON.stringify(JSON.parse(readFileSync(join(engine, 'package.json'), 'utf8')).version),
    __STUDIO_PLATFORM__: JSON.stringify(config.platform),
    __STUDIO_PROJECT_SCOPE__: JSON.stringify(PROJECT_SCOPE),
    __STUDIO_I18N_EN__: JSON.stringify(projectI18n.en || {}),
    __GMAPS_KEY__: JSON.stringify(env.GOOGLE_MAPS_API_KEY || ''),
    __GMAPS_MAP_ID__: JSON.stringify(env.GOOGLE_MAPS_MAP_ID || 'DEMO_MAP_ID'),
  },
});
const file = (ext) => result.outputFiles.find((f) => f.path.endsWith(ext))?.text ?? '';
// "</script" dentro de uma string quebraria o <script> inline; "<\/script" é equivalente em JS.
const js = file('.js').replace(/<\/script/gi, '<\\/script');
const html = readFileSync(join(engine, 'shell.html'), 'utf8')
  .replace(/__STUDIO_TITLE__/g, () => (config.name === 'studio' ? 'Studio' : `${config.name} Studio`))
  .replace('/*__TOKENS_CSS__*/', () => tokensCss + scopeCss)
  .replace('/*__APP_CSS__*/', () => tw.css + '\n' + file('.css') + '\n' + projectCss)
  .replace('/*__APP_JS__*/', () => js);

const target = join(root, 'dist/index.html');
if (isCheck) {
  // dist/ e data/history.json não são versionados; chegar até aqui já prova que tudo compila.
  // O que é versionado e gerado (tokens.css) precisa refletir tokens.json.
  const cssFile = join(root, 'tokens/tokens.css');
  if (ownTokens && (!existsSync(cssFile) || readFileSync(cssFile, 'utf8') !== tokensCss)) {
    console.error('tokens/tokens.css está desatualizado. Rode `npm run studio` e inclua no commit.');
    process.exit(1);
  }
  console.log('ok: tokens.css em dia e o build compila.');
} else {
  writeFileSync(target, html);
  console.log(`ok: dist/index.html (${(html.length / 1024).toFixed(0)} KB)`);
}
