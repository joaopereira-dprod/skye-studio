// Tailwind padrão do motor, usado quando o projeto não tem o seu (tailwind.config.mjs na raiz). Mapeia as cores e os raios para as variáveis CSS dos tokens.
// Cores vêm das variáveis CSS geradas em tokens/tokens.css (convenção shadcn: canais HSL).
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const tokens = JSON.parse(readFileSync(join(root, 'tokens.json'), 'utf8'));
const r = (name) => `var(--r-${tokens.$tailwind.radius[name]})`;

export default {
  content: [join(root, '../src/**/*.{js,jsx}'), join(process.cwd(), 'src/**/*.{js,jsx}')], // o Studio e as telas do projeto
  corePlugins: { preflight: false }, // o Studio tem a própria base; o app dos devs pode ligar
  theme: {
    extend: {
      fontFamily: { sans: 'var(--f-sans)', mono: 'var(--f-mono)', headline: 'var(--f-headline)' },
      // Alturas do Figma (60, 120, 140, 184) que são múltiplos de 4 mas não existem na escala padrão do Tailwind
      spacing: { 15: '3.75rem', 30: '7.5rem', 35: '8.75rem', 46: '11.5rem' },
      borderRadius: Object.fromEntries(Object.keys(tokens.$tailwind.radius).map((k) => [k, r(k)])),
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'fade-out': { from: { opacity: '1' }, to: { opacity: '0' } },
        shake: { '0%, 100%': { transform: 'translateX(0)' }, '50%': { transform: 'translateX(-3px)' } },
      },
      animation: { 'fade-in': 'fade-in .15s ease-out', 'fade-out': 'fade-out .15s ease-in', shake: 'shake .15s linear 2' },
    },
  },
};
