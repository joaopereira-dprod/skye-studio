// Projeto padrão: o que o Studio usa quando a pasta ainda não tem studio.project.js. Tudo vazio, de propósito:
// as abas mostram o estado vazio e convidam a começar um projeto. Os tokens do motor (default/tokens.json) só vestem a interface do Studio;
// TOKENS aqui são os do projeto, e ainda não existem.
import HISTORY from '@studio/history';

export { HISTORY };
export const TOKENS = { version: '0', color: {}, font: {}, type: {}, space: {}, radius: {}, shadow: {} };
export const DESIGN = { audit: null, screens: {} };
export const SCREENS = [];
export const STUBS = [];
export const DOCS = [];
export const FIGMA_FILE = null;
export const WIKI_PAGES = []; // páginas extras da Wiki: [{ id, label, Component }]; o Component recebe { t } para traduzir
export const TabBar = () => null;
export const PortalContainer = ({ children }) => children;
