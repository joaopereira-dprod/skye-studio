import { Fragment, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { TOKENS } from 'studio-project';
import { t } from './i18n.js';
import { Guide } from './Guide.jsx';
import { Processo } from './ProcessoPage.jsx';
import { DOCS, FIGMA_FILE, WIKI_PAGES } from 'studio-project'; // WIKI_PAGES: páginas extras do projeto (o build entrega [] se o projeto não exporta)
import { Chip } from './ui/kit.jsx';
import { SCREENS } from 'studio-project';
import { dsNamesFor } from './fiber.js';
import { SideNav } from './SideNav.jsx';
import { mapOf, gapsOf, verifyOf, deviationsOf, health, screenData } from './design.js';

const slug = (k) => k.replace(/\//g, '-');
// Ordem deliberada: do mais básico ao mais complexo
const CATS = ['Ações', 'Formulário', 'Estrutura', 'Navegação', 'Sobreposição', 'Feedback', 'Conteúdo'].filter((c) => DOCS.some((d) => d.category === c));
const TOKEN_ITEMS = [
  { id: 'cores', label: 'Cores' },
  { id: 'tipo', label: 'Tipografia' },
  { id: 'espaco', label: 'Espaçamento' },
  { id: 'raio', label: 'Raio e sombra' },
];
// Cada página com filhos mostra a mesma lista lateral; `key` é onde o alvo da Wiki guarda a escolha
const SUBNAV = {
  tokens: { key: 'tok', label: 'Tipo de token', def: TOKEN_ITEMS[0].id, groups: [{ id: 'tokens', items: TOKEN_ITEMS }] },
  componentes: { key: 'comp', label: 'Componente', def: DOCS[0]?.name, groups: CATS.map((c) => ({ id: c, label: c, items: DOCS.filter((d) => d.category === c).map((d) => ({ id: d.name, label: d.name })) })) },
  telas: { key: 'scr', label: 'Tela', def: SCREENS[0]?.id, groups: [...new Set(SCREENS.map((s) => s.group))].map((g) => ({ id: g, label: g, items: SCREENS.filter((s) => s.group === g).map((s) => ({ id: s.id, label: s.label })) })) },
};
const figmaUrl = (node) => `${FIGMA_FILE}?node-id=${node}`;
const copy = (v) => { try { navigator.clipboard.writeText(v); } catch { /* sem permissão */ } };

/** Monta cada tela fora da página e lê os data-c: assim "usado em" nunca fica desatualizado. */
function useUsage() {
  const [usage, setUsage] = useState({});
  useEffect(() => {
    let alive = true;
    (async () => {
      const out = {};
      for (const s of SCREENS) {
        const host = document.createElement('div');
        const root = createRoot(host);
        root.render(<s.Component go={() => {}} back={() => {}} notify={() => {}} />);
        await new Promise((r) => setTimeout(r, 200)); // React 18 e Radix renderizam de forma assíncrona
        host.querySelectorAll('*').forEach((n) => dsNamesFor(n).forEach((name) => { (out[name] ||= new Set()).add(s.id); }));
        root.unmount();
      }
      if (alive) setUsage(out);
    })();
    return () => { alive = false; };
  }, []);
  return usage;
}

const GROUPS = [
  ['Marca e neutros', (k) => k.startsWith('brand/') || k.startsWith('neutral/')],
  ['Texto', (k) => k.startsWith('text/')],
  ['Fundo e superfície', (k) => k.startsWith('background/') || k.startsWith('surface/')],
  ['Borda e ícone', (k) => k.startsWith('border/') || k.startsWith('icon/')],
  ['Semântica e feedback', (k) => k.startsWith('semantic/') || k.startsWith('feedback/') || k.startsWith('red/')],
];

const PROJECT = __STUDIO_NAME__ === 'studio' ? 'Studio' : __STUDIO_NAME__;
// Páginas extras: a padrão (Processo) entra em todo projeto, e uma página do projeto com o mesmo id a substitui.
const BUILTIN_PAGES = [{ id: 'processo', label: 'Processo', after: 'como', Component: Processo }];
const EXTRA_PAGES = [...BUILTIN_PAGES.filter((b) => !WIKI_PAGES.some((p) => p.id === b.id)), ...WIKI_PAGES];
const count = (o) => Object.keys(o || {}).length;

function Visao() {
  const stats = [
    ['Cores', count(TOKENS.color), t('{n} famílias de fonte', { n: count(TOKENS.font) })],
    ['Estilos de texto', count(TOKENS.type), t('tokens de texto')],
    ['Componentes', DOCS.length, t('documentados na Wiki')],
    ['Telas', SCREENS.length, t('no protótipo')],
  ].filter(([, v]) => v > 0);
  return (
    <>
      <h2 className="st-headline-bold-40">{PROJECT}</h2>
      <p className="st-display-md" style={{ fontWeight: 500, maxWidth: '60ch' }}>{t('Documentação viva do projeto: tokens, componentes e telas lidos do próprio código, sempre atualizada.')}</p>
      {stats.length > 0 && <div className="stats">{stats.map(([l, v, h]) => <div className="card pad" key={l}><span className="st-label-md muted">{t(l).toUpperCase()}</span><b className="big">{v}</b><span className="st-body-sm muted">{h}</span></div>)}</div>}
      <p className="st-body-xs muted">{t('Motor do Studio')} v{__STUDIO_VERSION__}</p>
      <p className="st-body-sm muted">{t('Veja “Como usar” para entender as três abas do Studio.')}{FIGMA_FILE ? <> {t('Arquivo no Figma')}: <a href={FIGMA_FILE} target="_blank" rel="noreferrer">Figma</a>.</> : null}</p>
    </>
  );
}

const ABAS = [
  ['Protótipo', 'Ver e testar', 'As telas do projeto, navegáveis como no aparelho. Clique, volte, abra o menu. Quando a tela tem uma referência do Figma, “Comparar com a referência do Figma” sobrepõe a tela ao quadro original ou mostra só a diferença: preto é igual, qualquer cor é desvio.'],
  ['Histórico', 'Ver o que mudou', 'Cada mudança já feita no projeto, em ordem, com data, autor e as áreas tocadas (tokens, componentes, telas). “Abrir protótipo nesta versão” mostra como o projeto estava naquele momento.'],
  ['Wiki', 'Entender e consultar', 'A documentação viva: tokens, componentes e telas. Nasce do próprio código, então não fica desatualizada. “Usado em” mostra em quais telas cada componente aparece.'],
];
const CAMINHO = [
  ['Você pede', 'Em linguagem normal, na barra de chat: “crie a tela de perfil”, “ajuste o espaço do card”.'],
  ['O agente abre uma branch', 'Ele trabalha numa cópia paralela, então a versão oficial nunca quebra no meio do caminho.'],
  ['Ele confere sozinho', 'Roda as verificações do projeto antes de mostrar qualquer coisa.'],
  ['Você vê no Protótipo', 'Abra a prévia e navegue pelas telas.'],
  ['Pull request', 'O agente abre o PR. Você e a equipe veem exatamente o que mudou, linha por linha.'],
  ['Merge', 'Aprovado, a mudança entra na main e o Studio oficial é atualizado.'],
];
const PEDIDOS = [
  ['Criar uma tela', 'crie a tela de cadastro', 'O agente reaproveita os componentes que já existem, propõe os que faltam e só então monta a tela.'],
  ['Ajustar um componente', 'o botão está com pouco espaço interno', 'O agente atualiza o componente existente em vez de criar um paralelo.'],
  ['Mudar um token', 'troque a cor primária', 'O agente altera o token, e tudo que o usa muda junto. O Histórico mostra o antes e o depois.'],
  ['Entender uma mudança', 'o que mudou no último commit?', 'O agente lê o histórico e explica em linguagem simples.'],
];
const GLOSSARIO = [
  ['Repositório', 'A pasta do projeto no GitHub, com o código e todo o histórico.'],
  ['Branch', 'Uma cópia paralela para trabalhar sem mexer no que já está pronto. Uma branch por assunto.'],
  ['Commit', 'Uma foto gravada do projeto, com uma mensagem dizendo o que mudou e por quê.'],
  ['Push', 'Enviar os commits da sua máquina para o GitHub.'],
  ['Pull request (PR)', 'O pedido para juntar uma branch ao projeto. É aqui que a equipe vê o diff e aprova.'],
  ['Merge', 'Juntar a branch aprovada na main. A partir daí a mudança faz parte do produto.'],
  ['main', 'A versão oficial do projeto.'],
  ['CI', 'Verificações automáticas que rodam no PR e barram erros antes de entrar na main.'],
];

function Como() {
  return (
    <>
      <h2 className="st-headline-bold-40">{t('Como usar')}</h2>
      <p className="st-display-md" style={{ fontWeight: 500, maxWidth: '60ch' }}>{t('O Studio mostra o projeto como ele é hoje e o que mudou. Você conversa com o agente na barra de chat, ele altera o projeto e o Studio mostra o resultado.')}</p>
      <h3 className="st-display-md">{t('Começando do zero')}</h3>
      <p className="st-body-sm muted" style={{ maxWidth: '60ch' }}>{t('Nunca usou GitHub nem terminal? Siga os passos. Cada um diz onde fazer: no Terminal, no navegador ou no chat.')}</p>
      <Guide />
      <h3 className="st-display-md">{t('As três abas')}</h3>
      <div className="how-grid">{ABAS.map(([nome, papel, texto]) => <div className="card how-card" key={nome}><span className="how-pill st-label-md">{t(papel).toUpperCase()}</span><b className="st-display-md">{t(nome)}</b><p className="st-body-sm muted">{t(texto)}</p></div>)}</div>
      <h3 className="st-display-md">{t('O caminho de uma mudança')}</h3>
      <ol className="how-flow">{CAMINHO.map(([ti, d]) => <li key={ti}><b>{t(ti)}</b><p className="st-body-sm muted">{t(d)}</p></li>)}</ol>
      <h3 className="st-display-md">{t('O que pedir ao agente')}</h3>
      <div className="how-grid how-grid--2">{PEDIDOS.map(([q, fala, c]) => <div className="card how-card" key={q}><b>{t(q)}</b><span className="how-say mono">“{t(fala)}”</span><p className="st-body-sm muted">{t(c)}</p></div>)}</div>
      <h3 className="st-display-md">{t('Vocabulário do GitHub')}</h3>
      <dl className="how-gloss">{GLOSSARIO.map(([ti, d]) => <div key={ti}><dt className="mono">{t(ti)}</dt><dd className="st-body-sm muted">{t(d)}</dd></div>)}</dl>
    </>
  );
}

function Tokens({ target }) {
  const tab = target.tok || SUBNAV.tokens.def;
  const cur = TOKEN_ITEMS.find((t) => t.id === tab);
  return (
    <div className="component">
      <header className="chead">
        <span className="st-label-md muted">TOKENS</span>
        <h2 className="st-headline-bold-40">{t(cur.label)}</h2>
        <p className="muted">{t('Definidos em')} <span className="mono">tokens/tokens.json</span>.{tab === 'cores' ? ` ${t('Clique em uma cor para copiar o valor.')}` : ''}</p>
      </header>
      {tab === 'cores' && GROUPS.map(([g, test]) => (
        <section key={g}>
          <h4 className="st-label-md muted">{t(g).toUpperCase()}</h4>
          <div className="swatches">
            {Object.entries(TOKENS.color).filter(([k]) => test(k)).map(([k, v]) => (
              <button key={k} type="button" className="swatch" onClick={() => copy(v.value)} title={t('Copiar {v}', { v: v.value })}>
                <span className="c" style={{ background: `var(--c-${slug(k)})` }} />
                <span className="t"><b className="st-label-md">{k}</b><span className="mono muted">--c-{slug(k)}</span><span className="mono">{v.value}</span><span className="st-body-xs muted">{t(v.desc)}</span></span>
              </button>
            ))}
          </div>
        </section>
      ))}
      {tab === 'tipo' && Object.entries(TOKENS.type).map(([k, ty]) => (
        <div className="card pad spec" key={k}>
          <span className={`t-${slug(k)}`}>{t('Aa Bb Cc, texto de exemplo 0123')}</span>
          <span className="mono muted">.t-{slug(k)} · {ty.font} · {ty.size}/{ty.line} · {t('peso')} {ty.weight} · {t(ty.desc)}</span>
        </div>
      ))}
      {tab === 'espaco' && <div className="card pad" style={{ display: 'grid', gap: 10 }}>{Object.entries(TOKENS.space).map(([k, v]) => <div className="sp" key={k}><span className="mono">--s-{k}</span><i style={{ width: v || 2 }} /><span className="mono muted">{v}px</span></div>)}</div>}
      {tab === 'raio' && (
        <>
          <section>
            <h4 className="st-label-md muted">{t('RAIO')}</h4>
            <div className="preview preview--top">
              {Object.entries(TOKENS.radius).map(([k, v]) => <div className="tile" key={k}><div className="tile__box" style={{ border: '2px solid var(--c-surface-inverse)', background: 'var(--c-neutral-100)', borderRadius: Math.min(v, 28) }} /><span className="mono">--r-{k}</span><span className="mono muted">{v >= 9999 ? t('pílula') : `${v}px`}</span></div>)}
            </div>
          </section>
          <section>
            <h4 className="st-label-md muted">{t('SOMBRA')}</h4>
            <div className="preview preview--top">
              {Object.entries(TOKENS.shadow).map(([k, v]) => <div className="tile" key={k}><div className="tile__box" style={{ background: 'var(--c-surface-default)', borderRadius: 12, boxShadow: `var(--sh-${k})` }} /><span className="mono">--sh-{k}</span><span className="mono muted">{t(v.desc.replace(/ \(.*\)/, ''))}</span></div>)}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function Componentes({ target, usage }) {
  const d = DOCS.find((x) => x.name === target.comp) || DOCS[0];
  if (!d) return <p className="st-body-sm muted">{t('Nenhum componente documentado ainda. Descreva os componentes em')} <span className="mono">DOCS</span> {t('no')} <span className="mono">studio.project.js</span>.</p>;
  const used = [...(usage[d.name] || [])].map((id) => SCREENS.find((s) => s.id === id)?.label).filter(Boolean);
  return (
    <>
      <article className="component" aria-labelledby="comp-title">
        <header className="chead">
          <div className="row"><span className="st-label-md muted">{t('COMPONENTES')} / {t(d.category).toUpperCase()}</span><span className={`status status--${d.status === 'estável' ? 'ok' : 'wait'}`}>{t(d.status)}</span>{d.figma ? <a className="st-body-sm" href={figmaUrl(d.figma)} target="_blank" rel="noreferrer">{t('Abrir no Figma ↗')}</a> : <span className="st-body-sm muted">Sem componente no Figma ainda</span>}</div>
          <h2 id="comp-title" className="st-headline-bold-40">{d.name}</h2>
          <p className="st-body-md">{t(d.description)}</p>
        </header>
        <div className="example"><div className="preview">{d.demos()}</div><pre className="code">{d.code}</pre></div>
        <section><h4>Props</h4><div className="tablewrap"><table className="props"><thead><tr><th>{t('Nome')}</th><th>{t('Tipo')}</th><th>{t('Padrão')}</th><th>{t('Descrição')}</th></tr></thead><tbody>{d.props.map((p) => <tr key={p[0]}><td className="mono">{p[0]}</td><td className="mono">{p[1]}</td><td className="mono">{p[2]}</td><td>{t(p[3])}</td></tr>)}</tbody></table></div></section>
        <div className="dd"><div className="do"><b className="plus">{t('Faça')}</b><p className="st-body-sm">{t(d.do)}</p></div><div className="dont"><b className="minus">{t('Evite')}</b><p className="st-body-sm">{t(d.dont)}</p></div></div>
        <p className="st-body-sm muted">Tokens: <span className="mono">{d.tokens.join(', ')}</span><br />{t('Usado em')}: {used.length ? used.map((l) => t(l)).join(', ') : t('nenhuma tela ainda')}</p>
      </article>
    </>
  );
}

const STATUS_OK = new Set(['exact']);
const pct = (n) => `${(n * 100).toFixed(1).replace('.', ',')}%`;

/** Tabela vinda dos .md da skill; a coluna Status vira selo e a de Nó Figma vira link. */
function DesignTable({ t: tb }) {
  const si = tb.head.indexOf('Status'), ni = tb.head.indexOf('Nó Figma'), di = tb.head.indexOf('Decisão');
  return (
    <div className="tablewrap"><table className="props"><thead><tr>{tb.head.map((h) => <th key={h}>{h}</th>)}</tr></thead>
      <tbody>{tb.rows.map((r, i) => (
        <tr key={i}>{r.map((c, j) => (
          <td key={j} className={j === 0 ? 'mono' : undefined}>
            {j === si ? <span className={`status status--${STATUS_OK.has(c) ? 'ok' : 'wait'}`}>{c}</span>
              : j === ni && c ? <a href={figmaUrl(c.replace(':', '-'))} target="_blank" rel="noreferrer">{c} ↗</a> : c || <span className="muted">{j === di ? t('aberto') : '–'}</span>}
          </td>
        ))}</tr>
      ))}</tbody></table></div>
  );
}

function Mapeamento({ s }) {
  const m = mapOf(s.figma), gaps = gapsOf(s.figma), v = verifyOf(s.figma);
  if (!s.figma) {
    return <section><h4>{t('Mapeamento ao design system')}</h4><p className="st-body-sm muted">{t('Esta tela é uma proposta e não tem quadro no Figma. Quando o desenho existir, ele entra aqui pelo id do nó.')}</p></section>;
  }
  if (!m) {
    return (
      <section>
        <h4>{t('Mapeamento ao design system')}</h4>
        <p className="st-body-sm muted">{t('Esta tela ainda não foi mapeada. Peça ao Claude: “replique o nó {n} com a skill design-replicate”. O resultado vira', { n: s.figma.replace('-', ':') })} <span className="mono">design/{s.figma}.map.md</span> {t('e aparece aqui.')}</p>
      </section>
    );
  }
  const summary = m.doc.sections.find((x) => /^Resumo/.test(x.title));
  const vt = deviationsOf(s.figma);
  const vres = v?.sections.find((x) => /^Resultado/.test(x.title));
  return (
    <>
      <section>
        <h4>{t('Mapeamento ao design system ({n} elementos)', { n: m.total })}</h4>
        <p className="st-body-sm muted">{Object.entries(m.counts).map(([k, n]) => `${n} ${k}`).join(' · ')}. {t('Origem')}: <span className="mono">design/{s.figma}.map.md</span>.</p>
        <DesignTable t={m.table} />
        {summary && <ul className="st-body-sm muted">{summary.bullets.map((b) => <li key={b}>{b}</li>)}</ul>}
      </section>
      {gaps && <section><h4>{t('Órfãos e lacunas ({n})', { n: gaps.rows.length })}</h4><DesignTable t={gaps} /></section>}
      <section>
        <h4>{t('Verificação visual')}</h4>
        {v && <ul className="st-body-sm muted">{(vres?.bullets || []).map((b) => <li key={b}>{b}</li>)}</ul>}
        {vt ? <DesignTable t={vt} /> : <p className="st-body-sm muted">{t('Ainda não executada. No Protótipo, ligue “Comparar com a referência” para ver a diferença com o Figma; a skill grava o resultado em')} <span className="mono">design/{s.figma}.verify.md</span>.</p>}
        {screenData(s.figma)?.ref && <p className="st-body-sm muted">{t('Há imagem de referência do Figma para esta tela.')}</p>}
      </section>
    </>
  );
}

function Telas({ target, usage, setTarget }) {
  const s = SCREENS.find((x) => x.id === target.scr) || SCREENS[0];
  if (!s) return <p className="st-body-sm muted">{t('Nenhuma tela ainda. Crie as telas em')} <span className="mono">SCREENS</span> {t('no')} <span className="mono">studio.project.js</span>.</p>;
  const names = DOCS.map((x) => x.name).filter((n) => usage[n]?.has(s.id));
  return (
    <article className="component" aria-labelledby="scr-title">
      <header className="chead">
        <div className="row"><span className="st-label-md muted">{t('TELAS')} / {t(s.group).toUpperCase()}</span>{s.figma ? <a className="st-body-sm" href={figmaUrl(s.figma)} target="_blank" rel="noreferrer">{t('Frame no Figma ↗')}</a> : <span className="st-body-sm muted">{t('Sem quadro no Figma (proposta)')}</span>}</div>
        <h2 id="scr-title" className="st-headline-bold-40">{t(s.label)}</h2>
        <p className="muted">{t('Os componentes que a tela usa são lidos do protótipo.')}</p>
      </header>
      <section>
        <h4>{t('Componentes usados ({n})', { n: names.length })}</h4>
        <div className="chip-row chip-row--wrap">{names.length ? names.map((n) => <button key={n} type="button" className="chip-btn" onClick={() => setTarget({ page: 'componentes', comp: n })}><Chip size="sm">{n}</Chip></button>) : <span className="st-body-sm muted">{Object.keys(usage).length ? t('Nenhum componente do design system nesta tela.') : t('Lendo o protótipo…')}</span>}</div>
      </section>
      <Mapeamento s={s} />
    </article>
  );
}

function Saude() {
  const h = health();
  const a = h.audit;
  if (!a) return <p className="st-body-sm muted">{t('Sem dados de auditoria. Rode')} <span className="mono">npm run studio</span>.</p>;
  const debt = Object.fromEntries(a.rules.map((r) => [r.id, r.total]));
  const cards = [
    [t('Valores ligados a token'), pct(a.adoption), t('{a} usos de token contra {b} cores soltas', { a: a.tokenRefs, b: a.literals })],
    [t('Violações novas'), a.newViolations, a.ok ? t('nada acima da linha de base') : t('a auditoria reprova o PR')],
    [t('Dívida aceita'), debt['hex-literal'] + debt['rgb-literal'] + debt['arbitrary-size'], t('{a} hex · {b} rgb · {c} tamanhos arbitrários', { a: debt['hex-literal'], b: debt['rgb-literal'], c: debt['arbitrary-size'] })],
    [t('Telas mapeadas'), `${h.mapped}/${h.screens}`, t('com design/<tela>.map.md')],
    [t('Instâncias do DS'), h.rows ? pct(h.exact / h.rows) : '–', h.rows ? t('{a} de {b} elementos mapeados', { a: h.exact, b: h.rows }) : t('nenhuma tela mapeada ainda')],
    [t('Órfãos abertos'), h.open, t('sem decisão registrada')],
    [t('Desvios abertos'), h.deviations, h.verified ? t('{n} tela(s) verificada(s), sem decisão registrada', { n: h.verified }) : t('nenhuma tela verificada ainda')],
  ];
  return (
    <>
      <h3 className="st-display-md">{t('Saúde do design system')}</h3>
      <div className="stats">{cards.map(([l, v, hint]) => <div className="card pad" key={l}><span className="st-label-md muted">{l.toUpperCase()}</span><b className="big">{v}</b><span className="st-body-sm muted">{hint}</span></div>)}</div>
      <p className="st-body-sm muted">{t('Calculado por')} <span className="mono">npm run audit</span> {t('a cada')} <span className="mono">npm run studio</span>. {t('A dívida fica em')} <span className="mono">design/audit-baseline.json</span>: {t('pode diminuir, nunca crescer.')}</p>
    </>
  );
}

/** Só existe quando o projeto tem o que mostrar: dados de auditoria (design/) ou a versão dos tokens. */
const hasGovernance = () => !!health().audit || (TOKENS.version && TOKENS.version !== '0');

function Governanca() {
  const versioned = TOKENS.version && TOKENS.version !== '0';
  return (
    <>
      <h2 className="st-headline-bold-40">{t('Governança')}</h2>
      {health().audit && <Saude />}
      {versioned && (
        <>
          <h3 className="st-display-md">{t('Versionamento')}</h3>
          <div className="tablewrap"><table className="props"><thead><tr><th>{t('Mudança')}</th><th>{t('Versão')}</th></tr></thead><tbody><tr><td>{t('Novo token ou componente')}</td><td className="mono">minor</td></tr><tr><td>{t('Ajuste de valor sem mudar o uso')}</td><td className="mono">patch</td></tr><tr><td>{t('Renomear ou remover token, prop ou componente')}</td><td className="mono">major</td></tr></tbody></table></div>
          <p className="st-body-sm muted">{t('Versão atual dos tokens:')} <span className="mono">{TOKENS.version}</span>.</p>
        </>
      )}
    </>
  );
}

export function Wiki({ target, setTarget }) {
  const usage = useUsage();
  // O menu se adapta ao conteúdo: só aparece página que tem o que mostrar. Páginas do projeto (WIKI_PAGES) entram no fim, ou logo após “Como usar” com after: 'como'.
  const PAGES = [
    ['visao', 'Visão geral'], ['como', 'Como usar'],
    ...EXTRA_PAGES.filter((p) => p.after === 'como').map((p) => [p.id, p.label]),
    ...(count(TOKENS.color) ? [['tokens', 'Tokens']] : []),
    ...(DOCS.length ? [['componentes', 'Componentes']] : []),
    ...(SCREENS.length ? [['telas', 'Telas e fluxos']] : []),
    ...(hasGovernance() ? [['governanca', 'Governança']] : []),
    ...EXTRA_PAGES.filter((p) => p.after !== 'como').map((p) => [p.id, p.label]),
  ];
  const page = PAGES.some(([k]) => k === target.page) ? target.page : 'visao';
  // Tokens, Componentes e Telas são seções-mãe: cada uma abre e fecha sozinha. Abre a da página atual
  const [open, setOpen] = useState(() => new Set(SUBNAV[page] ? [page] : []));
  useEffect(() => { if (SUBNAV[page]) setOpen((o) => (o.has(page) ? o : new Set(o).add(page))); }, [page]);
  const toggle = (k) => setOpen((o) => { const n = new Set(o); if (!n.delete(k)) n.add(k); return n; });
  return (
    <div className="wiki">
      <nav className="wnav" aria-label="Wiki">
        {PAGES.map(([k, l]) => {
          const sub = SUBNAV[k];
          const isOpen = open.has(k);
          return (
            <Fragment key={k}>
              <div className="wnav-row">
                <button type="button" className="wnav-page" aria-current={page === k} onClick={() => { setTarget({ ...target, page: k }); window.scrollTo(0, 0); }}>{t(l)}</button>
                {sub && (
                  <button type="button" className="wnav-tog" aria-expanded={isOpen} aria-label={`${isOpen ? t('Recolher') : t('Expandir')} ${t(l)}`} onClick={() => toggle(k)}>
                    <svg className="snav-chev" width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M2 3.5 5 6.5 8 3.5" /></svg>
                  </button>
                )}
              </div>
              {sub && (
                <div className="sub" data-open={isOpen} data-current={page === k}>
                  <div className="sub-in" {...(isOpen ? {} : { inert: '' })}>
                    <SideNav label={sub.label} groups={sub.groups} value={page === k ? (target[sub.key] || sub.def) : null} onPick={(id) => setTarget({ ...target, page: k, [sub.key]: id })} />
                  </div>
                </div>
              )}
            </Fragment>
          );
        })}
      </nav>
      <article className="doc">
        {page === 'visao' && <Visao />}
        {page === 'como' && <Como />}
        {page === 'tokens' && <Tokens target={target} />}
        {page === 'componentes' && <Componentes target={target} usage={usage} />}
        {page === 'telas' && <Telas target={target} usage={usage} setTarget={setTarget} />}
        {page === 'governanca' && <Governanca />}
        {EXTRA_PAGES.map((p) => page === p.id && <p.Component key={p.id} t={t} />)}
      </article>
    </div>
  );
}
