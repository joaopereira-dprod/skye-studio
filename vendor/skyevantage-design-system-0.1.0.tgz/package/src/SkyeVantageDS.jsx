/**
 * SkyeVantage Design System — React (JSX), single file.
 *
 * Extracted from the Figma library "SkyeVantage ERP — v2" (🧩 Components page).
 * Only dependency: React 17+. Font: Inter (load it in your HTML, see README).
 *
 * Usage:
 *   import { DSStyles, Button, Input, Table } from './SkyeVantageDS';
 *   <DSStyles />   // mount once at the app root: injects tokens + component CSS
 *
 * Rules carried over from the Figma file:
 *  - Icons are outline only, never filled (all icons below are stroke-only).
 *  - No hard-coded values in components: everything reads the CSS variables below.
 *  - Focus ring = white 2px + primary-700 ring (Focus/Ring effect style).
 */
import React from 'react';

/* ------------------------------------------------------------------ */
/* 1. TOKENS                                                           */
/* ------------------------------------------------------------------ */

/** Primitive palette (Figma collection "Color Primitives"). */
export const primitives = {
  'primary-50': '#f9fbfc', 'primary-100': '#e6eff6', 'primary-200': '#bdd4e6', 'primary-300': '#82add0',
  'primary-400': '#3f79a7', 'primary-500': '#213f57', 'primary-600': '#193144', 'primary-700': '#142634',
  'primary-800': '#0f1b25', 'primary-900': '#091219',
  'secondary-50': '#fefbf6', 'secondary-100': '#fdf9f1', 'secondary-200': '#f9eacd', 'secondary-300': '#f3d69a',
  'secondary-400': '#eec572', 'secondary-500': '#e9b64e', 'secondary-600': '#e4a525', 'secondary-700': '#c38b18',
  'secondary-800': '#9a6e13', 'secondary-900': '#75540f',
  'neutral-50': '#fafafa', 'neutral-100': '#f2f2f3', 'neutral-200': '#e4e6e7', 'neutral-300': '#c9cccf',
  'neutral-400': '#a0a6ab', 'neutral-500': '#7d848c', 'neutral-600': '#60666c', 'neutral-700': '#484c51',
  'neutral-800': '#35383b', 'neutral-900': '#26292b',
  'success-100': '#e6f4ec', 'success-300': '#7fcba3', 'success-500': '#1b8a5a', 'success-700': '#146643',
  'success-800': '#11563a', 'success-900': '#0d4530',
  'warning-100': '#fcf1d8', 'warning-300': '#f0c36d', 'warning-500': '#c68a1b', 'warning-700': '#8f6212',
  'warning-900': '#5c3f0c',
  'critical-100': '#fbe7e7', 'critical-300': '#ef9a9a', 'critical-500': '#d64545', 'critical-700': '#a62d2d',
  'critical-800': '#8a2525', 'critical-900': '#6e1d1d',
  'info-100': '#e5f0fb', 'info-300': '#90c2ee', 'info-500': '#2e7fc1', 'info-700': '#205c8d', 'info-900': '#15405f',
  'white': '#ffffff', 'black': '#000000',
  'shadow-5': 'rgba(12,12,13,0.05)', 'shadow-10': 'rgba(12,12,13,0.10)',
};

/** Semantic tokens (Figma collection "Color", mode Light). Values reference primitives. */
export const semantic = {
  'bg-surface': 'white', 'bg-surface-secondary': 'neutral-50', 'bg-surface-subdued': 'neutral-100',
  'bg-surface-active': 'neutral-200', 'bg-inverse': 'neutral-900',
  'bg-action-primary': 'primary-500', 'bg-action-primary-hover': 'primary-600', 'bg-action-primary-pressed': 'primary-700',
  'bg-action-primary-disabled': 'neutral-200', 'bg-action-secondary': 'secondary-500',
  'bg-action-secondary-disabled': 'neutral-200', 'bg-action-outline-hover': 'primary-50',
  'bg-action-outline-pressed': 'primary-100', 'bg-action-critical': 'critical-700',
  'bg-action-critical-hover': 'critical-800', 'bg-action-critical-pressed': 'critical-900',
  'bg-action-success': 'success-700', 'bg-action-success-hover': 'success-800', 'bg-action-success-pressed': 'success-900',
  'bg-critical-subdued': 'critical-100', 'bg-warning-subdued': 'warning-100', 'bg-success-subdued': 'success-100',
  'bg-info-subdued': 'info-100', 'bg-success-strong': 'success-300', 'bg-warning-strong': 'warning-300',
  'bg-info-strong': 'info-300', 'bg-critical-strong': 'critical-300', 'bg-success': 'success-500',
  'bg-warning': 'warning-500', 'bg-critical': 'critical-500',
  'text-primary': 'neutral-900', 'text-secondary': 'neutral-600', 'text-disabled': 'neutral-300',
  'text-on-action': 'white', 'text-on-warning': 'neutral-900', 'text-brand': 'primary-500',
  'text-link': 'secondary-800', 'text-link-hover': 'secondary-900',
  'text-critical': 'critical-700', 'text-warning': 'warning-700', 'text-success': 'success-700', 'text-info': 'info-700',
  'text-success-strong': 'success-900', 'text-warning-strong': 'warning-900', 'text-info-strong': 'info-900',
  'text-critical-strong': 'critical-900', 'text-action-outline': 'primary-700',
  'text-action-outline-hover': 'primary-800', 'text-action-outline-pressed': 'primary-900',
  'border-default': 'neutral-300', 'border-subdued': 'neutral-200', 'border-strong': 'neutral-500',
  'border-input': 'neutral-500', 'border-focus': 'primary-700', 'border-focus-subtle': 'primary-500',
  'border-critical': 'critical-500', 'border-success': 'success-500', 'border-info': 'info-500',
  'border-action-outline': 'primary-500', 'border-action-outline-hover': 'primary-800',
  'border-action-outline-pressed': 'primary-900',
  'icon-default': 'neutral-600', 'icon-subdued': 'neutral-500', 'icon-strong': 'neutral-900', 'icon-on-action': 'white',
};

export const space = { 2: 2, 4: 4, 6: 6, 8: 8, 10: 10, 12: 12, 16: 16, 20: 20, 24: 24, 32: 32, 40: 40, 48: 48, 64: 64, 80: 80, 96: 96 };
export const radius = { sm: 4, md: 8, lg: 12, xl: 16, full: 999 };

/** Text styles (Figma text styles, family Inter). [size, line-height, weight, letter-spacing, uppercase] */
export const textStyles = {
  'title-2xl': [32, 40, 600], 'title-xl': [28, 36, 600], 'title-lg': [24, 32, 600], 'title-md': [20, 28, 600],
  'title-sm': [18, 24, 600], 'title-xs': [16, 22, 600],
  'body-2xl': [20, 32, 400], 'body-xl': [18, 28, 400], 'body-lg': [16, 24, 400], 'body-md': [14, 20, 400],
  'body-sm': [13, 18, 400], 'body-xs': [12, 16, 400],
  'label-2xl': [16, 20, 500], 'label-xl': [15, 20, 500], 'label-lg': [14, 18, 500], 'label-md': [13, 16, 500],
  'label-sm': [12, 16, 500], 'label-xs': [11, 14, 500],
  'caption-lg': [12, 16, 400, '0.02em'], 'caption-md': [11, 16, 400, '0.02em'], 'caption-sm': [10, 14, 500, '0.02em', true],
  'display-lg': [48, 56, 600, '-0.01em'], 'display-sm': [30, 38, 400],
};

export const shadows = {
  100: '0 1px 4px rgba(12,12,13,0.05)',
  200: '0 1px 4px rgba(12,12,13,0.05), 0 1px 4px rgba(12,12,13,0.10)',
  300: '0 2px 10px rgba(12,12,13,0.10)',
  400: '0 4px 12px rgba(0,0,0,0.12)',
  500: '0 8px 24px rgba(0,0,0,0.12)',
  600: '0 12px 32px rgba(0,0,0,0.18)',
  focusRing: '0 0 0 2px #fff, 0 0 0 5px #142634',
  pressed: 'inset 0 1px 2px rgba(0,0,0,0.25)',
};

const tokenCss = () => {
  const lines = [':root{'];
  for (const [k, v] of Object.entries(primitives)) lines.push(`--${k}:${v};`);
  for (const [k, v] of Object.entries(semantic)) lines.push(`--${k}:var(--${v});`);
  for (const [k, v] of Object.entries(space)) lines.push(`--space-${k}:${v}px;`);
  for (const [k, v] of Object.entries(radius)) lines.push(`--radius-${k}:${v}px;`);
  for (const [k, v] of Object.entries(shadows)) lines.push(`--shadow-${k}:${v};`);
  lines.push('--font:Inter,system-ui,-apple-system,"Segoe UI",sans-serif;}');
  for (const [k, [size, lh, weight, ls, upper]] of Object.entries(textStyles)) {
    lines.push(`.t-${k}{font:${weight} ${size}px/${lh}px var(--font);${ls ? `letter-spacing:${ls};` : ''}${upper ? 'text-transform:uppercase;' : ''}}`);
  }
  return lines.join('\n');
};

/* ------------------------------------------------------------------ */
/* 2. COMPONENT CSS                                                    */
/* ------------------------------------------------------------------ */

const componentCss = `
.sv, .sv *{box-sizing:border-box}
.sv{font-family:var(--font);color:var(--text-primary)}
.sv-icon{display:inline-block;flex:none;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.sv-spin{animation:sv-spin .9s linear infinite}@keyframes sv-spin{to{transform:rotate(360deg)}}

/* Button */
.sv-btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-8);border:1px solid transparent;border-radius:var(--radius-full);cursor:pointer;white-space:nowrap;font-family:var(--font);font-weight:500;transition:background .12s,border-color .12s,color .12s}
.sv-btn:focus-visible{outline:none;box-shadow:var(--shadow-focusRing)}
.sv-btn:active:not(:disabled){box-shadow:var(--shadow-pressed)}
.sv-btn:disabled,.sv-btn[aria-busy=true]{cursor:not-allowed}
.sv-btn--sm{height:32px;padding:0 var(--space-12);font-size:12px}.sv-btn--md{height:40px;padding:0 var(--space-16);font-size:14px}.sv-btn--lg{height:48px;padding:0 var(--space-24);font-size:16px}
.sv-btn--primary{background:var(--bg-action-primary);color:var(--text-on-action)}
.sv-btn--primary:hover:not(:disabled){background:var(--bg-action-primary-hover)}.sv-btn--primary:active:not(:disabled){background:var(--bg-action-primary-pressed)}
.sv-btn--secondary{background:var(--bg-surface);color:var(--text-brand);border-color:var(--border-action-outline)}
.sv-btn--secondary:hover:not(:disabled){background:var(--bg-action-outline-hover);border-color:var(--border-action-outline-hover);color:var(--text-action-outline-hover)}
.sv-btn--secondary:active:not(:disabled){background:var(--bg-action-outline-pressed);border-color:var(--border-action-outline-pressed);color:var(--text-action-outline-pressed)}
.sv-btn--ghost{background:transparent;color:var(--text-secondary);border-color:var(--border-default)}
.sv-btn--ghost:hover:not(:disabled){background:var(--bg-surface-subdued);border-color:var(--border-strong);color:var(--text-primary)}
.sv-btn--ghost:active:not(:disabled){background:var(--bg-surface-active);border-color:var(--border-strong);color:var(--text-primary)}
.sv-btn--link{background:transparent;color:var(--text-link);padding-left:0;padding-right:0}
.sv-btn--link:hover:not(:disabled),.sv-btn--link:active:not(:disabled){color:var(--text-link-hover)}
.sv-btn--critical{background:var(--bg-action-critical);color:var(--text-on-action)}
.sv-btn--critical:hover:not(:disabled){background:var(--bg-action-critical-hover)}.sv-btn--critical:active:not(:disabled){background:var(--bg-action-critical-pressed)}
.sv-btn--success{background:var(--bg-action-success);color:var(--text-on-action)}
.sv-btn--success:hover:not(:disabled){background:var(--bg-action-success-hover)}.sv-btn--success:active:not(:disabled){background:var(--bg-action-success-pressed)}
.sv-btn--primary:disabled,.sv-btn--critical:disabled,.sv-btn--success:disabled{background:var(--bg-action-primary-disabled);color:var(--text-disabled)}
.sv-btn--secondary:disabled{background:var(--bg-surface);border-color:var(--border-subdued);color:var(--text-disabled)}
.sv-btn--ghost:disabled{background:transparent;border-color:var(--border-subdued);color:var(--text-disabled)}
.sv-btn--link:disabled{color:var(--text-disabled)}
.sv-iconbtn{padding:0;aspect-ratio:1/1}
.sv-iconbtn.sv-btn--sm{width:32px}.sv-iconbtn.sv-btn--md{width:40px}.sv-iconbtn.sv-btn--lg{width:48px}

/* Fields (Input / Select / Textarea) */
.sv-field{display:flex;flex-direction:column;gap:var(--space-6);width:100%}
.sv-field__label{font:500 14px/18px var(--font);color:var(--text-primary)}
.sv-field__helper{font:400 12px/16px var(--font);color:var(--text-secondary)}
.sv-field--error .sv-field__helper{color:var(--text-critical)}
.sv-field--disabled .sv-field__helper{color:var(--text-disabled)}
.sv-box{display:flex;align-items:center;gap:var(--space-8);background:var(--bg-surface);border:1px solid var(--border-input);border-radius:var(--radius-md);overflow:hidden;position:relative}
.sv-box:focus-within{border:2px solid var(--border-focus-subtle)}
.sv-field--error .sv-box{border:2px solid var(--border-critical)}
.sv-field--disabled .sv-box{background:var(--bg-surface-subdued);border:1px solid var(--border-subdued)}
.sv-box--sm{min-height:34px;font-size:13px}.sv-box--md{min-height:40px;font-size:14px}.sv-box--lg{min-height:48px;font-size:16px}
.sv-box__input{flex:1;min-width:0;border:0;outline:0;background:transparent;font:inherit;color:var(--text-primary);padding:var(--space-8) var(--space-12)}
.sv-box__input::placeholder{color:var(--text-secondary)}
.sv-box__input:disabled{color:var(--text-disabled);cursor:not-allowed}
.sv-box__addon{display:flex;align-items:center;align-self:stretch;background:var(--bg-surface-subdued);color:var(--text-secondary);padding:0 var(--space-16)}
.sv-box--sm .sv-box__addon{padding:0 var(--space-12)}.sv-box--lg .sv-box__addon{padding:0 var(--space-24)}
.sv-box__icon{color:var(--icon-default);margin-left:var(--space-12);display:flex}
.sv-box__icon--right{margin-left:0;margin-right:var(--space-12)}
.sv-select{appearance:none;-webkit-appearance:none;cursor:pointer;padding-right:var(--space-40)}
.sv-select:invalid{color:var(--text-secondary)}
.sv-select__chevron{position:absolute;right:var(--space-12);pointer-events:none;color:var(--icon-default)}
.sv-textarea{min-height:96px;resize:vertical;width:100%;border:0;outline:0;background:transparent;font:400 14px/20px var(--font);color:var(--text-primary);padding:var(--space-8) var(--space-12)}

/* Checkbox / Radio */
.sv-check{display:inline-flex;align-items:center;gap:var(--space-8);font:400 14px/20px var(--font);color:var(--text-primary);cursor:pointer}
.sv-check input{position:absolute;opacity:0;width:0;height:0}
.sv-check__box{width:18px;height:18px;display:flex;align-items:center;justify-content:center;background:var(--bg-surface);border:1px solid var(--border-input);border-radius:var(--radius-sm);color:var(--text-on-action)}
.sv-check--radio .sv-check__box{border-radius:var(--radius-full)}
.sv-check input:checked+.sv-check__box,.sv-check input:indeterminate+.sv-check__box{background:var(--bg-action-primary);border-color:transparent}
.sv-check input:indeterminate+.sv-check__box{background:var(--bg-action-secondary)}
.sv-check input:focus-visible+.sv-check__box{box-shadow:var(--shadow-focusRing)}
.sv-check input:disabled+.sv-check__box{background:var(--bg-surface-subdued);border-color:var(--border-subdued)}
.sv-check input:disabled:checked+.sv-check__box{background:var(--bg-action-primary-disabled)}
.sv-check input:disabled~.sv-check__label{color:var(--text-disabled)}
.sv-check__dot{width:6px;height:6px;border-radius:50%;background:var(--bg-surface)}
.sv-radiocard{display:flex;gap:var(--space-16);padding:var(--space-24);background:var(--bg-surface);border:1px solid var(--border-subdued);border-radius:var(--radius-lg);cursor:pointer;width:100%}
.sv-radiocard[aria-checked=true]{border-color:var(--border-focus-subtle)}
.sv-radiocard[aria-disabled=true]{background:var(--bg-surface-subdued);cursor:not-allowed}
.sv-radiocard__text{display:flex;flex-direction:column;gap:var(--space-8)}

/* Tag / Badge / FilterTag */
.sv-tag{display:inline-flex;align-items:center;gap:var(--space-4);padding:var(--space-4) var(--space-8);border-radius:var(--radius-full);font:500 10px/14px var(--font);letter-spacing:.02em;text-transform:uppercase;white-space:nowrap}
.sv-tag--subtle-success{background:var(--bg-success-subdued);color:var(--text-success)}.sv-tag--subtle-warning{background:var(--bg-warning-subdued);color:var(--text-warning)}
.sv-tag--subtle-info{background:var(--bg-info-subdued);color:var(--text-info)}.sv-tag--subtle-error{background:var(--bg-critical-subdued);color:var(--text-critical)}
.sv-tag--solid-success{background:var(--bg-action-success);color:var(--text-on-action)}.sv-tag--solid-warning{background:var(--bg-warning-strong);color:var(--text-warning-strong)}
.sv-tag--solid-info{background:var(--info-700);color:var(--text-on-action)}.sv-tag--solid-error{background:var(--bg-action-critical);color:var(--text-on-action)}
.sv-badge{display:inline-flex;align-items:center;gap:var(--space-4);padding:var(--space-4) var(--space-8);border-radius:var(--radius-full);font:500 12px/16px var(--font)}
.sv-badge--primary{background:var(--bg-action-primary);color:var(--text-on-action)}
.sv-badge--neutral{border:1px solid var(--border-default);color:var(--text-secondary)}
.sv-badge--disabled{background:var(--bg-action-primary-disabled);color:var(--text-secondary)}
.sv-filtertag{display:inline-flex;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-16);border-radius:var(--radius-full);background:var(--bg-surface);border:1px solid var(--border-default);font:500 12px/16px var(--font);color:var(--text-primary);cursor:pointer;height:32px}
.sv-filtertag[aria-pressed=true]{background:var(--bg-action-outline-hover);border-color:var(--border-focus-subtle)}
.sv-filtertag:focus-visible{outline:none;box-shadow:var(--shadow-focusRing)}

/* Banner / Toast */
.sv-alert{display:flex;align-items:flex-start;gap:var(--space-12);padding:var(--space-12) var(--space-12) var(--space-12) var(--space-16);border-radius:var(--radius-md)}
.sv-alert--toast{box-shadow:var(--shadow-100);width:360px}
.sv-alert__content{display:flex;flex-direction:column;gap:var(--space-4);flex:1}
.sv-alert__title{font:600 14px/18px var(--font)}.sv-alert__desc{font:400 14px/20px var(--font)}
.sv-alert--success{background:var(--bg-success-strong);color:var(--text-success-strong)}.sv-alert--warning{background:var(--bg-warning-strong);color:var(--text-warning-strong)}
.sv-alert--info{background:var(--bg-info-strong);color:var(--text-info-strong)}.sv-alert--error{background:var(--bg-critical-strong);color:var(--text-critical-strong)}
.sv-alert__close{background:none;border:0;color:inherit;cursor:pointer;padding:0;display:flex}

/* Tabs / Segmented */
.sv-tabs{display:flex}
.sv-tab{padding:10px var(--space-16);height:40px;background:transparent;border:1px solid var(--border-subdued);border-bottom-color:var(--border-subdued);font:500 14px/18px var(--font);color:var(--text-primary);cursor:pointer;margin-right:-1px}
.sv-tab[aria-selected=true]{background:var(--bg-surface);color:var(--text-link);border-bottom-color:var(--bg-surface)}
.sv-tab:focus-visible{outline:none;box-shadow:var(--shadow-focusRing);position:relative}
.sv-segmented{display:inline-flex;gap:var(--space-4);padding:var(--space-4);background:var(--bg-surface-secondary);border-radius:var(--radius-full)}
.sv-segmented button{border:0;background:transparent;padding:var(--space-8) var(--space-16);border-radius:var(--radius-full);font:500 14px/18px var(--font);color:var(--text-primary);cursor:pointer}
.sv-segmented button[aria-pressed=true]{background:var(--bg-action-primary);color:var(--text-on-action)}

/* Dropdown menu */
.sv-menu{display:flex;flex-direction:column;gap:var(--space-4);padding:var(--space-4);background:var(--bg-surface);border:1px solid var(--border-subdued);border-radius:var(--radius-md);box-shadow:var(--shadow-200);min-width:200px}
.sv-option{display:flex;align-items:center;gap:var(--space-8);padding:var(--space-8) var(--space-12);border:0;background:transparent;border-radius:var(--radius-sm);font:400 14px/20px var(--font);color:var(--text-primary);cursor:pointer;text-align:left;width:100%}
.sv-option span{flex:1}
.sv-option:hover,.sv-option:focus-visible{background:var(--bg-info-subdued);outline:none}
.sv-option[aria-selected=true]{background:var(--bg-action-primary);color:var(--text-on-action);font-weight:500}
.sv-option--critical{color:var(--text-critical)}

/* Metric card */
.sv-metric{display:flex;flex-direction:column;gap:var(--space-8);padding:var(--space-12) var(--space-16);background:var(--bg-surface);border:1px solid var(--border-default);border-radius:var(--radius-md)}
.sv-metric__label{font:400 14px/18px var(--font);color:var(--text-secondary)}.sv-metric__value{font:600 32px/40px var(--font);color:var(--text-primary)}

/* Table */
.sv-tablewrap{border:1px solid var(--border-default);border-radius:var(--radius-md);overflow:hidden;background:var(--bg-surface);width:100%}
.sv-table{width:100%;border-collapse:collapse;font:400 14px/20px var(--font)}
.sv-th{background:var(--bg-surface-secondary);padding:var(--space-8) var(--space-12);height:40px;text-align:left;font:500 10px/14px var(--font);letter-spacing:.02em;text-transform:uppercase;color:var(--text-primary);white-space:nowrap}
.sv-th__inner{display:inline-flex;align-items:center;gap:var(--space-8)}
.sv-th button{border:0;background:none;padding:0;cursor:pointer;color:var(--icon-default);display:flex}
.sv-td{background:var(--bg-surface);padding:var(--space-8) var(--space-12);height:56px;border-bottom:1px solid var(--border-subdued);color:var(--text-primary)}
.sv-table tr:last-child .sv-td{border-bottom:0}
.sv-td--kv-label{background:var(--bg-surface-secondary);width:220px;font:500 10px/14px var(--font);letter-spacing:.02em;text-transform:uppercase}
.sv-td--actions{text-align:right;width:56px}
.sv-tr--current .sv-td{background:var(--bg-surface-subdued)}
.sv-cell{display:inline-flex;align-items:center;gap:var(--space-8)}
.sv-pagination{display:flex;justify-content:space-between;align-items:center;padding:var(--space-8);font:400 13px/18px var(--font);color:var(--text-secondary)}
.sv-pagination__rows{display:flex;align-items:center;gap:var(--space-8)}.sv-pagination__nav{display:flex;align-items:center;gap:var(--space-12)}

/* Modal */
.sv-overlay{position:fixed;inset:0;background:rgba(9,18,25,.5);display:flex;align-items:center;justify-content:center;padding:var(--space-24);z-index:1000}
.sv-modal{background:var(--bg-surface);border-radius:var(--radius-lg);box-shadow:var(--shadow-600);width:100%;display:flex;flex-direction:column;max-height:calc(100vh - 48px)}
.sv-modal--sm{max-width:400px}.sv-modal--md{max-width:560px}.sv-modal--lg{max-width:800px}
.sv-modal__head{display:flex;justify-content:space-between;align-items:flex-start;gap:var(--space-16);padding:var(--space-24) var(--space-24) var(--space-16)}
.sv-modal__title{font:600 18px/24px var(--font);margin:0}.sv-modal__body{padding:0 var(--space-24) var(--space-24);overflow:auto;font:400 14px/20px var(--font);color:var(--text-secondary)}
.sv-modal__foot{display:flex;justify-content:flex-end;gap:var(--space-12);padding:var(--space-16) var(--space-24);border-top:1px solid var(--border-subdued)}

/* Breadcrumb */
.sv-breadcrumb{display:flex;align-items:center;gap:var(--space-8);font:400 14px/20px var(--font);color:var(--text-secondary)}
.sv-breadcrumb a{color:inherit;text-decoration:none}.sv-breadcrumb a:hover{text-decoration:underline}
.sv-breadcrumb [aria-current=page]{color:var(--text-link);font-weight:500}
`;

/** Mount once at the root. Injects tokens (CSS variables) + component CSS. */
export function DSStyles() {
  return <style data-skyevantage-ds>{tokenCss() + componentCss}</style>;
}

/* ------------------------------------------------------------------ */
/* 3. ICONS (outline only — never filled)                              */
/* ------------------------------------------------------------------ */

const ICON_PATHS = {
  check: <path d="M20 6 9 17l-5-5" />,
  minus: <path d="M5 12h14" />,
  plus: <path d="M5 12h14M12 5v14" />,
  x: <path d="M18 6 6 18M6 6l12 12" />,
  'chevron-down': <path d="m6 9 6 6 6-6" />,
  'chevron-up': <path d="m18 15-6-6-6 6" />,
  'chevron-left': <path d="m15 18-6-6 6-6" />,
  'chevron-right': <path d="m9 18 6-6-6-6" />,
  'chevrons-up-down': <path d="m7 15 5 5 5-5M7 9l5-5 5 5" />,
  pencil: <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />,
  'ellipsis-vertical': <><circle cx="12" cy="12" r="1" /><circle cx="12" cy="5" r="1" /><circle cx="12" cy="19" r="1" /></>,
  info: <><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></>,
  'circle-check': <><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></>,
  'circle-x': <><circle cx="12" cy="12" r="10" /><path d="m15 9-6 6M9 9l6 6" /></>,
  'triangle-alert': <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3M12 9v4M12 17h.01" />,
  search: <><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></>,
  calendar: <><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></>,
  loader: <path d="M21 12a9 9 0 1 1-6.219-8.56" />,
  'arrow-left': <path d="m12 19-7-7 7-7M19 12H5" />,
  trash: <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />,
  copy: <><rect x="8" y="8" width="14" height="14" rx="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></>,
};

/** Outline icon. Pass `name` (see ICON_PATHS) or `children` with your own stroke paths. */
export function Icon({ name, size = 16, className = '', children, ...rest }) {
  return (
    <svg className={`sv-icon ${className}`} width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" {...rest}>
      {children || ICON_PATHS[name]}
    </svg>
  );
}

const cx = (...a) => a.filter(Boolean).join(' ');
const ICON_BY_BTN = { sm: 16, md: 20, lg: 24 };

/* ------------------------------------------------------------------ */
/* 4. COMPONENTS                                                       */
/* ------------------------------------------------------------------ */

/** Button — variant: primary | secondary | ghost | link | critical | success; size: sm | md | lg */
export const Button = React.forwardRef(function Button(
  { variant = 'primary', size = 'md', iconLeft, iconRight, loading = false, disabled, className, children, ...rest }, ref) {
  const s = ICON_BY_BTN[size];
  return (
    <button ref={ref} type="button" className={cx('sv sv-btn', `sv-btn--${variant}`, `sv-btn--${size}`, className)}
      disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <Icon name="loader" size={s} className="sv-spin" /> : iconLeft && <Icon name={iconLeft} size={s} />}
      {children}
      {iconRight && !loading && <Icon name={iconRight} size={s} />}
    </button>
  );
});

/** IconButton — requires `label` for accessibility. */
export const IconButton = React.forwardRef(function IconButton(
  { icon, label, variant = 'secondary', size = 'md', loading, disabled, className, ...rest }, ref) {
  return (
    <button ref={ref} type="button" aria-label={label} title={label}
      className={cx('sv sv-btn sv-iconbtn', `sv-btn--${variant}`, `sv-btn--${size}`, className)}
      disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      <Icon name={loading ? 'loader' : icon} size={ICON_BY_BTN[size]} className={loading ? 'sv-spin' : ''} />
    </button>
  );
});

let _id = 0;
const useId = (p) => { const r = React.useRef(); if (!r.current) r.current = `${p}-${++_id}`; return r.current; };

function Field({ id, label, helper, error, disabled, children }) {
  const msg = error || helper;
  return (
    <div className={cx('sv sv-field', error && 'sv-field--error', disabled && 'sv-field--disabled')}>
      {label && <label className="sv-field__label" htmlFor={id}>{label}</label>}
      {children}
      {msg && <div className="sv-field__helper" id={`${id}-msg`} role={error ? 'alert' : undefined}>{msg}</div>}
    </div>
  );
}

/** Input — size: sm | md | lg. `error` is a message (string) or true. addonLeft/addonRight: text such as "$" or "ft". */
export const Input = React.forwardRef(function Input(
  { label, helper, error, size = 'md', iconLeft, iconRight, addonLeft, addonRight, disabled, id, className, ...rest }, ref) {
  const uid = useId('in'); const fid = id || uid;
  return (
    <Field id={fid} label={label} helper={helper} error={error} disabled={disabled}>
      <div className={cx('sv-box', `sv-box--${size}`, className)}>
        {addonLeft && <span className="sv-box__addon">{addonLeft}</span>}
        {iconLeft && <span className="sv-box__icon"><Icon name={iconLeft} size={size === 'lg' ? 20 : 16} /></span>}
        <input ref={ref} id={fid} className="sv-box__input" disabled={disabled}
          aria-invalid={!!error || undefined} aria-describedby={(error || helper) ? `${fid}-msg` : undefined} {...rest} />
        {iconRight && <span className="sv-box__icon sv-box__icon--right"><Icon name={iconRight} size={size === 'lg' ? 20 : 16} /></span>}
        {addonRight && <span className="sv-box__addon">{addonRight}</span>}
      </div>
    </Field>
  );
});

/** Select — native <select>. Pass <option> children; use placeholder for the empty option. */
export const Select = React.forwardRef(function Select(
  { label, helper, error, size = 'md', placeholder = 'Select an option', disabled, id, className, children, ...rest }, ref) {
  const uid = useId('sel'); const fid = id || uid;
  return (
    <Field id={fid} label={label} helper={helper} error={error} disabled={disabled}>
      <div className={cx('sv-box', `sv-box--${size}`, className)}>
        <select ref={ref} id={fid} className="sv-box__input sv-select" required disabled={disabled}
          defaultValue={rest.value === undefined && rest.defaultValue === undefined ? '' : undefined}
          aria-invalid={!!error || undefined} {...rest}>
          <option value="" disabled hidden>{placeholder}</option>
          {children}
        </select>
        <Icon name="chevron-down" size={size === 'lg' ? 22 : size === 'sm' ? 14 : 18} className="sv-select__chevron" />
      </div>
    </Field>
  );
});

export const Textarea = React.forwardRef(function Textarea({ label, helper, error, disabled, id, ...rest }, ref) {
  const uid = useId('ta'); const fid = id || uid;
  return (
    <Field id={fid} label={label} helper={helper} error={error} disabled={disabled}>
      <div className="sv-box" style={{ alignItems: 'stretch' }}>
        <textarea ref={ref} id={fid} className="sv-textarea" disabled={disabled} aria-invalid={!!error || undefined} {...rest} />
      </div>
    </Field>
  );
});

/** Checkbox — supports indeterminate. */
export const Checkbox = React.forwardRef(function Checkbox({ label, indeterminate = false, className, ...rest }, ref) {
  const inner = React.useRef(null);
  React.useImperativeHandle(ref, () => inner.current);
  React.useEffect(() => { if (inner.current) inner.current.indeterminate = indeterminate; }, [indeterminate]);
  return (
    <label className={cx('sv sv-check', className)}>
      <input ref={inner} type="checkbox" {...rest} />
      <span className="sv-check__box"><Icon name={indeterminate ? 'minus' : 'check'} size={14} style={{ display: rest.checked || rest.defaultChecked || indeterminate ? 'block' : 'none' }} /></span>
      {label && <span className="sv-check__label">{label}</span>}
    </label>
  );
});

export const Radio = React.forwardRef(function Radio({ label, className, ...rest }, ref) {
  return (
    <label className={cx('sv sv-check sv-check--radio', className)}>
      <input ref={ref} type="radio" {...rest} />
      <span className="sv-check__box"><span className="sv-check__dot" style={{ display: rest.checked ? 'block' : 'none' }} /></span>
      {label && <span className="sv-check__label">{label}</span>}
    </label>
  );
});

/** RadioCard — large selectable card. */
export function RadioCard({ title, description, checked = false, disabled = false, onChange, name, value }) {
  return (
    <div role="radio" tabIndex={disabled ? -1 : 0} aria-checked={checked} aria-disabled={disabled || undefined}
      className="sv sv-radiocard" onClick={() => !disabled && onChange && onChange(value)}
      onKeyDown={(e) => { if (!disabled && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); onChange && onChange(value); } }}>
      <Radio name={name} value={value} checked={checked} disabled={disabled} readOnly tabIndex={-1} />
      <div className="sv-radiocard__text">
        <div className="t-title-xs">{title}</div>
        {description && <div className="t-body-md" style={{ color: 'var(--text-secondary)' }}>{description}</div>}
      </div>
    </div>
  );
}

const TAG_ICON = { success: 'circle-check', warning: 'triangle-alert', info: 'info', error: 'circle-x' };
/** Tag — color: success | warning | info | error; style: subtle | solid (icon shown on subtle only). */
export function Tag({ color = 'info', styleType = 'subtle', showIcon = true, children, className }) {
  return (
    <span className={cx('sv sv-tag', `sv-tag--${styleType}-${color}`, className)}>
      {children}
      {styleType === 'subtle' && showIcon && <Icon name={TAG_ICON[color]} size={14} />}
    </span>
  );
}

/** Badge — color: primary | neutral | disabled */
export function Badge({ color = 'neutral', icon, children, className }) {
  return <span className={cx('sv sv-badge', `sv-badge--${color}`, className)}>{icon && <Icon name={icon} size={14} />}{children}</span>;
}

/** FilterTag — pill used for filters and add-on chips. `applied` + `onRemove` shows the applied state. */
export function FilterTag({ children, applied = false, icon, onClick, onRemove, className }) {
  return (
    <span className="sv" style={{ display: 'inline-flex' }}>
      <button type="button" aria-pressed={applied} className={cx('sv-filtertag', className)} onClick={onClick}>
        {icon && <Icon name={icon} size={16} />}
        {children}
        {applied && onRemove
          ? <Icon name="circle-x" size={16} onClick={(e) => { e.stopPropagation(); onRemove(); }} />
          : <Icon name="chevron-down" size={16} />}
      </button>
    </span>
  );
}

const ALERT_ICON = { success: 'circle-check', warning: 'triangle-alert', info: 'info', error: 'circle-x' };
function Alert({ color = 'info', title, children, onDismiss, toast, className }) {
  return (
    <div role={color === 'error' ? 'alert' : 'status'} className={cx('sv sv-alert', `sv-alert--${color}`, toast && 'sv-alert--toast', className)}>
      <Icon name={ALERT_ICON[color]} size={20} />
      <div className="sv-alert__content">
        {title && <div className="sv-alert__title">{title}</div>}
        {children && <div className="sv-alert__desc">{children}</div>}
      </div>
      {onDismiss && <button type="button" className="sv-alert__close" aria-label="Dismiss" onClick={onDismiss}><Icon name="x" size={24} /></button>}
    </div>
  );
}
/** Banner — inline, full width. color: success | warning | info | error */
export const Banner = (p) => <Alert {...p} />;
/** Toast — floating, 360px, with shadow. */
export const Toast = (p) => <Alert {...p} toast />;

/** BoxedTabs — tabs: [{ id, label }], value / onChange. */
export function BoxedTabs({ tabs, value, onChange, className }) {
  return (
    <div role="tablist" className={cx('sv sv-tabs', className)}>
      {tabs.map((t) => (
        <button key={t.id} role="tab" type="button" className="sv-tab" aria-selected={value === t.id} onClick={() => onChange && onChange(t.id)}>{t.label}</button>
      ))}
    </div>
  );
}

/** SegmentedControl — options: [{ id, label }] */
export function SegmentedControl({ options, value, onChange, className }) {
  return (
    <div role="group" className={cx('sv sv-segmented', className)}>
      {options.map((o) => <button key={o.id} type="button" aria-pressed={value === o.id} onClick={() => onChange && onChange(o.id)}>{o.label}</button>)}
    </div>
  );
}

/** DropdownMenu + DropdownOption — items: [{ id, label, selected?, critical? }]. Same component serves SelectDropdown and ActionMenu. */
export function DropdownMenu({ items, onSelect, className }) {
  return (
    <div role="menu" className={cx('sv sv-menu', className)}>
      {items.map((it) => (
        <button key={it.id} role="menuitem" type="button" aria-selected={it.selected || undefined}
          className={cx('sv-option', it.critical && 'sv-option--critical')} onClick={() => onSelect && onSelect(it.id)}>
          <span>{it.label}</span>{it.selected && <Icon name="check" size={16} />}
        </button>
      ))}
    </div>
  );
}

export function MetricCard({ label, value, className }) {
  return <div className={cx('sv sv-metric', className)}><div className="sv-metric__label">{label}</div><div className="sv-metric__value">{value}</div></div>;
}

/* ---- Table ---------------------------------------------------------- */

/**
 * Table — columns: [{ key, header, width?, sortable?, render?(row) }], rows: array of objects.
 * Cell types: pass `render` to return <Tag/>, <Badge/>, icon+text, <IconButton/>, etc.
 * `currentRow(row)` => true highlights a row (used on Version History).
 */
export function Table({ columns, rows, rowKey = 'id', onSort, currentRow, className }) {
  return (
    <div className={cx('sv sv-tablewrap', className)}>
      <table className="sv-table">
        <thead>
          <tr>{columns.map((c) => (
            <th key={c.key} className="sv-th" style={{ width: c.width }} scope="col">
              <span className="sv-th__inner">{c.header}
                {c.sortable && <button type="button" aria-label={`Sort by ${c.header}`} onClick={() => onSort && onSort(c.key)}><Icon name="chevrons-up-down" size={14} /></button>}
              </span>
            </th>))}</tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r[rowKey] ?? i} className={currentRow && currentRow(r) ? 'sv-tr--current' : undefined}>
              {columns.map((c) => <td key={c.key} className={cx('sv-td', c.align === 'right' && 'sv-td--actions')}>{c.render ? c.render(r) : r[c.key]}</td>)}
            </tr>))}
        </tbody>
      </table>
    </div>
  );
}

/** Convenience cell for text + trailing icon (e.g. provider + video icon). */
export const IconLabelCell = ({ icon, children }) => <span className="sv-cell">{children}{icon && <Icon name={icon} size={16} />}</span>;

/** KeyValueTable — items: [{ label, value, onEdit? }]. Used for lead details and estimate breakdown. */
export function KeyValueTable({ items, className }) {
  return (
    <div className={cx('sv sv-tablewrap', className)}>
      <table className="sv-table"><tbody>
        {items.map((it) => (
          <tr key={it.label}>
            <th scope="row" className="sv-td sv-td--kv-label">{it.label}</th>
            <td className="sv-td">{it.value}</td>
            {it.onEdit && <td className="sv-td sv-td--actions"><IconButton icon="pencil" label={`Edit ${it.label}`} variant="ghost" size="sm" onClick={it.onEdit} /></td>}
          </tr>))}
      </tbody></table>
    </div>
  );
}

export function Pagination({ page, pageCount, rowsPerPage = 10, rowsOptions = [10, 20, 50], onPage, onRowsPerPage, className }) {
  return (
    <div className={cx('sv sv-pagination', className)}>
      <div className="sv-pagination__rows">Show rows per page
        <div style={{ width: 80 }}>
          <Select size="sm" aria-label="Rows per page" value={rowsPerPage} onChange={(e) => onRowsPerPage && onRowsPerPage(Number(e.target.value))}>
            {rowsOptions.map((n) => <option key={n} value={n}>{n}</option>)}
          </Select>
        </div>
      </div>
      <div className="sv-pagination__nav">
        <span>{page} of {pageCount}</span>
        <IconButton icon="chevron-left" label="Previous page" variant="ghost" size="sm" disabled={page <= 1} onClick={() => onPage && onPage(page - 1)} />
        <IconButton icon="chevron-right" label="Next page" variant="ghost" size="sm" disabled={page >= pageCount} onClick={() => onPage && onPage(page + 1)} />
      </div>
    </div>
  );
}

/** Modal — size: sm | md | lg. Footer: pass buttons via `footer`. */
export function Modal({ open, title, size = 'md', onClose, footer, children }) {
  React.useEffect(() => {
    if (!open) return undefined;
    const h = (e) => { if (e.key === 'Escape') onClose && onClose(); };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="sv sv-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget && onClose) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-label={title} className={cx('sv-modal', `sv-modal--${size}`)}>
        <div className="sv-modal__head"><h2 className="sv-modal__title">{title}</h2>
          <IconButton icon="x" label="Close" variant="ghost" size="sm" onClick={onClose} /></div>
        <div className="sv-modal__body">{children}</div>
        {footer && <div className="sv-modal__foot">{footer}</div>}
      </div>
    </div>
  );
}

/** Breadcrumb — items: [{ label, href? }]; the last item is the current page. */
export function Breadcrumb({ items }) {
  return (
    <nav aria-label="Breadcrumb" className="sv sv-breadcrumb">
      {items.map((it, i) => {
        const last = i === items.length - 1;
        return (
          <React.Fragment key={it.label}>
            {i > 0 && <Icon name="chevron-right" size={14} />}
            {last ? <span aria-current="page">{it.label}</span> : <a href={it.href || '#'}>{it.label}</a>}
          </React.Fragment>);
      })}
    </nav>
  );
}
