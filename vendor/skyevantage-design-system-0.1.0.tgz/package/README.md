# SkyeVantage Design System (React / JSX)

Extracted from the Figma library **SkyeVantage ERP — v2** (page `🧩 Components`, file key `SPElEKzaDCu32XXersJofk`).
Everything lives in one file: [`src/SkyeVantageDS.jsx`](src/SkyeVantageDS.jsx). Only dependency is React 17+.

## Quick start

```bash
npm install
npm run dev     # opens the demo (src/Demo.jsx) showing every component
```

Use it in another project: copy `src/SkyeVantageDS.jsx`, load the Inter font, mount `<DSStyles />` once.

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
```

```jsx
import { DSStyles, Button, Input, Table } from './SkyeVantageDS';

<DSStyles />            {/* once, at the app root: injects tokens + component CSS */}
<Button variant="primary" iconLeft="plus">New estimate</Button>
```

## What is inside

| Area | Contents |
|---|---|
| Tokens | `primitives`, `semantic` (colour roles → primitives), `space`, `radius`, `textStyles`, `shadows`. Emitted as CSS variables (`--bg-action-primary`, `--text-secondary`, `--space-16`, `--radius-md`, `--shadow-200`…) and text classes (`.t-title-lg`, `.t-body-md`, `.t-label-md`, `.t-caption-sm`…). |
| Actions | `Button` (primary, secondary, ghost, link, critical, success × sm/md/lg, loading, disabled), `IconButton` |
| Forms | `Input` (addons, icons, error/disabled), `Select`, `Textarea`, `Checkbox` (indeterminate), `Radio`, `RadioCard` |
| Status | `Tag` (subtle/solid × success/warning/info/error), `Badge`, `FilterTag` (default/applied) |
| Feedback | `Banner`, `Toast`, `Modal` |
| Navigation | `BoxedTabs`, `SegmentedControl`, `Breadcrumb` |
| Overlays | `DropdownMenu` (covers the Figma `SelectDropdown` and `ActionMenu`) |
| Data | `MetricCard`, `Table` (+ `IconLabelCell`), `KeyValueTable`, `Pagination` |
| Icons | `Icon` — outline-only set used by the components. Add more by pasting a stroke path into `ICON_PATHS`. |

## Rules carried over from Figma

- Icons are **outline only, never filled**.
- Components read tokens only (no hard-coded colours or spacing in component CSS).
- Focus ring: 2px white + primary-700 ring, shown with `:focus-visible`.
- Light mode only (the Figma `Color` collection has one mode, "Light").

## Not extracted yet

Sidebar, Stepper / StepItem, DatePicker, Accordion/CategoryHeader, Modal/LeadDetail, EmptyState, Avatar and the `Lo-fi` collection are in Figma but not in this file. `Modal` is a simplified version (sm/md/lg, header, body, footer) and does not yet have the Confirm/Critical tone or the LeadDetail layout.

## Known caveats

- Built from the Figma specs (spacing, radius, colour variables, text styles) and checked only by compiling and server-rendering the demo; it has **not** been compared pixel by pixel against the Figma frames.
- `Radio` selected label uses `--text-primary`. In Figma the selected label is white (`text/on-action`), which is a library bug (white on white), so it was not copied.
- `BoxedTabs` hover/active styling and the `Tag` letter-spacing (2%) are approximations.
- No dark mode, and no `Lo-fi` tokens.
